``pkginfo`` README
==================

This package provides an API for querying the distutils metadata written in
the ``PKG-INFO`` file inside a source distriubtion (an ``sdist``), or into
the ``EGG-INFO`` directory of an installed distribution.

Please see the `pkginfo docs <http://packages.python.org/pkginfo>`_
for detailed documentation.
