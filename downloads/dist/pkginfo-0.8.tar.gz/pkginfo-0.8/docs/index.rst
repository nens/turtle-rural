pkginfo documentation
=====================

Contents:

.. toctree::
   :maxdepth: 2

   distributions
   metadata
   indexes
