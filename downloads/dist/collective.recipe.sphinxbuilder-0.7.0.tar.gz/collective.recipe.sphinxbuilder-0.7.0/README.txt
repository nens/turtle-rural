.. contents::

- Code repository: https://svn.plone.org/svn/collective/buildout/collective.recipe.sphinxbuilder
- Documentation: http:/docs.garbas.si/collective.recipe.sphinxbuilder
- Questions and comments to tarek_at_ziade.org, rok_at_garbas.si

