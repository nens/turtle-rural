.. python-nens documentation master file, created by
   sphinx-quickstart on Wed Mar  2 14:44:22 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python-nens's documentation!
=======================================

introduction
------------

.. toctree::
   :maxdepth: 1

   project

main stuff
----------

.. toctree::
   :maxdepth: 1

   main_stuff

other stuff
-----------

.. toctree::
   :maxdepth: 1

   other_stuff

todo
----

.. toctree::
   :maxdepth: 1

   missing

indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

