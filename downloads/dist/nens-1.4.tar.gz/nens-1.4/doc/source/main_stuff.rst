asc
---

grids

.. automodule:: nens.asc
   :members:

geom
----

geometric functions

.. automodule:: nens.geom
   :members:

gp
--

geoprocessor

.. automodule:: nens.gp
   :members:

numeric
-------

.. automodule:: nens.numeric
   :members:

sobek
-----

.. automodule:: nens.sobek
   :members:

turtleurbanclasses
------------------

stuff that should be migrated to turtle

.. automodule:: nens.turtleurbanclasses
   :members:

