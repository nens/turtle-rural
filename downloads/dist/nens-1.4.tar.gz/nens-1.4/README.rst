Nelen & Schuurmans python collection
====================================

Collection of tools for the Nelen & Schuurmans python packages.


Requirements
------------

`Numpy <http://numpy.scipy.org/>`_ is required.  You need to install this
yourself.  On windows, use the windows installer.  On ubuntu, do ``apt-get
install python2.5-numpy``.

On ubuntu, you'll commonly need to ``sudo apt-get install zlib, zlib1g-dev,
libjpeg, libjpeg62-dev, readline, libreadline5-dev, readline-common``.


Isolated development environment
--------------------------------

To develop in isolation without installing the development version in your
system python, use the provided buildout::

   $> python bootstrap.py
   $> bin/buildout

``bin/python`` is now a python interpreter with the nens library on the path.

To run all the tests, run ``bin/python nens/tests.py``.
