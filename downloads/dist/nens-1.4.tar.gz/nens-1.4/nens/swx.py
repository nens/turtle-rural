#!c:/python25/python.exe
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the nens library.
#
# the nens library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# the nens library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2009 Mario Frasca
#*
#***********************************************************************
#* Library    : thought for lazy interface builders
#*
#* Project    : various
#*
#* $Id: gp.py 7710 2009-08-17 08:14:18Z Mario $
#*
#* initial programmer :  Mario Frasca
#* initial date       :  2009-08-20
#**********************************************************************

__revision__ = "$Rev: 7710 $"[6:-2]

import logging
import wx
import threading
# Note: 'wx' is not stated as an install_requires dependency, so this
# module is not tested in the tests.py tests.  Mario says this module
# is hardly ever used anyway.
log = logging.getLogger('nens.swx')
log.setLevel(logging.INFO)


class TextCtrlHandler(logging.Handler):
    '''emits formatted records to a wx.TextCtrl widget

    the widget must be...
    style=wx.TE_MULTILINE|wx.TE_READONLY|wx.HSCROLL|wx.TE_RICH

    logging records will be gray (DEBUG), black (INFO) or red (WARNING/ERROR).

    changing the content of the widget once you have given it to this
    object will crash your program.  you may wipe it clean using the
    ClearWindow method.

    NB: this object can crash your Linux program
    '''

    def __init__(self, widget, **kwargs):
        logging.Handler.__init__(self, **kwargs)
        self.widget = widget
        self.semaphore = threading.Semaphore()

    def emit(self, record):
        if record.levelno >= logging.WARNING:
            styleForLevel = wx.TextAttr("red")
        elif record.levelno >= logging.INFO:
            styleForLevel = wx.TextAttr("black")
        else:
            styleForLevel = wx.TextAttr("grey")
        self.semaphore.acquire()
        self.widget.SetDefaultStyle(styleForLevel)

        self.widget.AppendText(self.format(record))
        self.widget.AppendText('\n')
        self.semaphore.release()

    def ClearWindow(self):
        "empty the owned widget"
        self.semaphore.acquire()
        self.widget.SetValue('')
        self.semaphore.release()


class ProgressThread(threading.Thread):
    '''specialized thread, you write to it as if it was a stream, it
    understands a very easy language for keeping track of progress in
    a wx.Gauge.  the wx.Gauge has to be passed in the constructor.  do
    not forget to close the stream or to send the "end" command.

    the language includes:
    setrange: sets the gauge range
    inc: increments the gauge position
    <number>: sets the gauge position
    pulse <delay>: starts pulsing
    end: ends the thread, disabling the gauge
    '''

    def __init__(self, gauge, *args, **kwargs):
        'create specialized thread.  gauge must be a wx.Gauge.'
        threading.Thread.__init__(self, target=self.__loop, args=[])
        self.__commands = []
        self.__gauge = gauge
        if not isinstance(gauge, wx.Gauge):
            raise ValueError("ProgressThread got a %s instead of a wx.Gauge" % str(type(gauge)))

    def write(self, command):
        '''queue the command'''

        self.__commands.append(command)
        pass

    def close(self):
        'same as write("end")'

        self.__commands.append('end')
        pass

    def __pulse(self, sleep):
        '''keep pulsing until next command.'''

        import time
        while self.__idle:
            time.sleep(sleep)
            self.__gauge.Pulse()

    def __loop(self):
        '''keep executing commands until end of stream.'''

        self.__gauge.Enable()
        import time
        import re
        done = False
        splitter = re.compile(r'[ \t\n\r]+')
        while not done:
            time.sleep(0.1)
            while self.__commands and not done:
                self.__idle = False
                command = self.__commands.pop(0).lower()
                parts = splitter.split(command)
                try:
                    cmd = parts[0]
                    if cmd == 'end':
                        done = True
                    elif cmd == 'inc':
                        value = self.__gauge.GetValue()
                        value += int(parts[1])
                        self.__gauge.SetValue(value)
                    elif cmd == 'setrange':
                        self.__gauge.SetRange(int(parts[1]))
                    elif cmd == 'pulse':
                        sleep = float(parts[1])
                        pulse = threading.Thread(target=self.__pulse, args=(sleep,))
                        self.__idle = True
                        pulse.start()
                    else:
                        value = int(parts[0])
                        self.__gauge.SetValue(value)
                except:
                    pass
        self.__gauge.SetValue(0)
        self.__gauge.Disable()


class MainThread(threading.Thread):
    '''Thread class taking care of disabling/enabling the convert and
    close buttons...

    a dialog box may be given and its OnThreadStart and OnThreadEnd
    methods will be called when the thread is actually run.'''

    def __init__(self, dialog=None, *args, **kwargs):
        self.dialog = dialog
        threading.Thread.__init__(self, *args, **kwargs)

    def run(self, *args, **kwargs):
        try:
            #print "self.dialog.OnThreadStart(self)"
            self.dialog.OnThreadStart(self)
        except Exception:
            pass

        try:
            #print "threading.Thread.run(self, *args, **kwargs)"
            threading.Thread.run(self, *args, **kwargs)
        except:
            import traceback
            log.error("a serious error occurred in the main thread (INFO follows)")
            log.info(traceback.format_exc())

        try:
            #print "self.dialog.OnThreadEnd(self)"
            self.dialog.OnThreadEnd(self)
        except Exception:
            pass
