#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the nens library.
#
# the nens library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# the nens library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2008, 2009 Mario Frasca
#*
#***********************************************************************
#* Library    : more pythonic approach to the gp library.
#*
#* Project    : various
#*
#* $Id: gp.py 21579 2011-06-03 09:09:37Z mario.frasca $
#*
#* initial programmer :  Mario Frasca
#* initial date       :  2008-07-28
#**********************************************************************

from __future__ import nested_scopes
__revision__ = "$Rev: 21579 $"[6:-2]

import unittest
import logging
log = logging.getLogger('nens.gp')
techlog = logging.getLogger('nens.')
log.debug('loading module')

import operator
import types

# Log level below DEBUG for logging that's even too verbose for the DEBUG level.
VERBOSE_LOGLEVEL = 5


def log_verbose(msg, *args, **kwargs):
    log.log(VERBOSE_LOGLEVEL, msg, *args, **kwargs)


import sys
if sys.version_info < (2, 3):
    False = 0
    True = 1

    types.StringTypes = types.StringType

    def dict(source):
        """avoiding error 'NameError: global name 'dict' is not defined'
        """

        if isinstance(source, types.ListType) or isinstance(source, types.TupleType):
            result = {}
            for key, value in source:
                result[key] = value
            return result
        if isinstance(source, types.DictionaryType):
            return source.copy()

    operator.itemgetter = lambda i: (lambda x: x[i])


class GpHandler(logging.Handler):
    """ Adds an extra handler to the logging class which displays messages in the ArcGIS window
    """

    class Formatter(logging.Formatter):
        def format(self, record):
            if self._fmt.find("%(relativeCreatedSeconds)") >= 0:
                record.relativeCreatedSeconds = record.relativeCreated / 1000.0
            return logging.Formatter.format(self, record)

    def __init__(self, level=logging.INFO, geoprocessor=None, format=None, *args, **kwargs):
        if geoprocessor == None:
            from sys import platform
            if platform == 'win32':
                # if no explicit geoprocessor is given, get the standard one from ArcGIS.
                import arcgisscripting
                geoprocessor = arcgisscripting.create()
            else:
                from nens import mock
                geoprocessor = mock.GpDispatch()
        self.geoproc = geoprocessor
        logging.Handler.__init__(self, level, *args, **kwargs)
        if format == None:
            format = '%(relativeCreatedSeconds)0.3f %(message)s'
        self.setFormatter(self.Formatter(format))

    def emit(self, record):
        try:
            message = self.format(record)
            if record.levelno >= logging.ERROR:
                self.geoproc.AddError(message)
            elif record.levelno >= logging.WARNING:
                self.geoproc.AddWarning(message)
            else:
                self.geoproc.AddMessage(message)
        except:
            self.handleError(record)


class gp_iterator:
    """iterating on anything with reset and next methods
    """
    def __init__(self, obj):
        self.__obj = obj
        self.__obj.reset()
        self.__index = None

    def next(self):
        result = self.__obj.next()
        if not result:
            raise StopIteration
        return result

    def __iter__(self):
        return self

    def __getitem__(self, index):
        if self.__index is None:
            self.__obj.reset()
            self.__index = 0
            result = self.__obj.next()
        for i in range(self.__index, index):
            result = self.__obj.next()
            self.__index = index
        if result is None:
            raise IndexError("list index %d is out of range" % index)
        return result


def check_constraints(obj, field_name, constraints, on_error_fail=False):
    """boolean function, true if all constraints hold for value

    gets value associated to field_name in obj,
    constraints is list describing the constraints

    raises an exception if on_error_fail is True.
    returns False if the check fails on a strong constraint.
    returns True otherwise
    emits a warning if a check (strong or weak) fails.

    constraints is expected to be composed of:
    Integer
    NonNegative
    Positive
    DDMM - Integer holding a day of the year.
    MMDD - Integer holding a day of the year.
    [min, max] - an interval, either values can be a '-', which is ignored.
    W[min, max] - this is a weak constraint: logs a warning, but returns True.
    string(lenght) - string no longer than lenght characters
    (<condition>) - <condition> holds or the input is None
    """

    import re
    interval_pattern = re.compile(r'^([a-z]?)\[[ ]*([-0-9\.]+|[a-z_]+)[ ,]+([-0-9\.]+|[a-z_]+)[ ]*\]$', re.I)
    string_pattern = re.compile(r'string\(([0-9]+)\)', re.I)

    result = True

    log.debug("check_constraints for %s" % field_name)
    # get the string representation of the value from object
    value = obj[field_name]

    # get constraints from settings
    accept_none, constraints = split_constraints(constraints)
    if accept_none and value is None:
        return True

    try:
        fvalue = float(value)
        ivalue = int(fvalue)
    except:
        fvalue = ivalue = None

    log.debug("%s(%s)" % (type(value), value))

    # perform the check
    if fvalue:
        log.debug("checking s/f/i %s %0.6f %d, %s" % (value, fvalue, ivalue, constraints))
    else:
        log.debug("checking %s, %s" % (value, constraints))

    for i in [i.lower().strip() for i in constraints]:
        log.debug(i)
        justWarn = False
        matched_interval_pattern = interval_pattern.match(i)
        matched_string_pattern = string_pattern.match(i)
        ok = fvalue is not None
        if i == 'boolean':
            ok = value.lower() in ['1', '0', 'true', 'false', 'yes', 'no']
        elif i == 'percent':
            ok &= (fvalue >= 0)
            ok &= (fvalue <= 100)
        elif i == 'integer':
            ok &= (ivalue == fvalue)
        elif i == 'nonnegative':
            ok &= (fvalue >= 0)
        elif i == 'positive':
            ok &= (fvalue > 0)
        elif i in ['ddmm', 'mmdd']:
            if i == 'ddmm':
                day, month = ivalue / 100, ivalue % 100
            if i == 'mmdd':
                month, day = ivalue / 100, ivalue % 100
            try:
                import datetime
                datetime.datetime(2000, month, day)
                ok = True
            except ValueError:
                ok = False
            pass
        elif matched_interval_pattern:
            justWarn, min, max = matched_interval_pattern.groups()

            def translate(what):
                if what == '-':
                    return None
                try:
                    return obj[what]
                except:
                    return float(what)

            min = translate(min)
            max = translate(max)
            if min is not None:
                ok &= (fvalue >= min)
            if max is not None:
                ok &= (fvalue <= max)
        elif matched_string_pattern:
            max_lenght, = matched_string_pattern.groups()
            if max_lenght != '-':
                max_lenght = float(max_lenght)
            else:
                max_lenght = None
            ok = isinstance(value, types.StringTypes)
            if ok and max_lenght is not None:
                ok &= (len(value) <= max_lenght)
        else:
            log.warn("unrecognized pattern '%s'" % i)
            ok = True
        if not ok:
            log.warn("value %s in field %s does not respect constraint %s" %
                     (value, field_name, i))
        if justWarn:
            ok = True
        result &= ok

    if not result and on_error_fail:
        raise ValueError("value %s in field %s does not respect constraints %s" %
                         (value, field_name, ' '.join(constraints)))
    return result


def split_constraints(s):
    '''splits the string defining the range into its components

    returns a pair
    first indicates if None is acceptable
    second is list of atomic constraints

    splits on spaces that are separate atomic ranges.
    '''

    if s is None or s.strip() == '':
        return False, []

    if s[0] == '(' and s[-1] == ')':
        s = s[1:-1]
        accept_none = True
    else:
        accept_none = False

    import re
    p = re.compile(r'(?<=[\]a-z]) +(?=[\[a-z])', re.I)
    result = p.split(s)
    return accept_none, result

import re
array_key = re.compile("\[([a-z0-9_%]+)\][ ]*\[([0-9\.,-]+)\]", re.I)


def reverse_dict(forward):
    "returns a dictionary where keys are strings and values are lists"
    result = {}
    if isinstance(forward, types.DictionaryType):
        forward = forward.items()
    for k, v in forward:
        if isinstance(k, types.StringType):
            k = k.lower()
        if isinstance(v, types.StringType):
            if array_key.match(v):
                continue
            values = [i.lower() for i in v.split(',')]
        else:
            values = [v]
        for vi in values:
            result.setdefault(vi, []).append(k)
    return result


def evaluate_dict_fields(d, to_lower=False):
    """wherever possible, transforms fields to float or int.
    """

    result = {}
    for key, repr in dict(d).items():
        value = repr.lower()
        if repr[0] == repr[-1] == "'" or repr[0] == repr[-1] == '"':
            value = repr[1:-1]
        else:
            try:
                value = float(repr)
            except:
                pass
            try:
                value = int(repr)
            except:
                pass
        result[key] = value
    return result


def list_of_array_keys(pattern):
    "give me an 'array key' pattern, you get the corresponding list of tuples"

    match = array_key.match(pattern)
    if match is None:
        return []
    definition = match.group(2)
    if definition.count(',') == 1:
        definition += ",1"
    start, stop, step = [int(i) for i in definition.split(',')]
    stop = stop + 1
    return [(match.group(1) % k, k) for k in range(start, stop, step)]


def gp_as_dict(fields, object, conversion=None, defaults=None, evaluate=False, dictionaries={}, nonevalues=[],
               ranges={}, on_exception_raise=False, primary_key=None, no_shape=False):
    """extracts the values of the fields from the object and returns it as
    a dictionary.  a backward name conversion can be given, from the
    wished representation to the one found in the input data.

    if 'primary_key' is not None, the result is a pair where the first
    element is the value of the primary key and the second element is
    the dictionary representing the row.
    """

    reversed = dict([(k.lower(), [k.lower()]) for k in fields])
    if isinstance(conversion, types.DictionaryType):
        conversion = conversion.items()
    if conversion:
        reversed.update(reverse_dict(conversion))
    fields.sort()
    log_verbose("trying to get these fields out of the object..., %s" % (fields,))
    result = {}
    log_verbose("filling in defaults")
    if defaults is not None:
        defaults = dict(defaults)
        if evaluate:
            defaults = evaluate_dict_fields(defaults)
        result.update(defaults)
    else:
        defaults = {}
    log_verbose("getting values from object")
    for f in fields:
        if f == 'Shape' and no_shape is True:
            continue
        log_verbose("getting '%s' from %s" % (f, object))
        v = object.getvalue(f)
        for k in reversed[f.lower()]:
            result[k] = v
    log_verbose("overwriting None values with defaults.")
    for k, v in result.items():
        if v in nonevalues:
            result[k] = None
        if result[k] is None:
            result[k] = defaults.get(k)
    log_verbose("managed to get these fields out of the object..., %s" % (result.keys(),))

    if no_shape is not True:
        try:
            log_verbose('getting shape__centroid__x and y from shape.centroid')
            x, y = [float(i) for i in object.shape.centroid.split(' ')]
            for k in reversed.get('shape__centroid__x', ['shape__centroid__x']):
                result[k] = x
            for k in reversed.get('shape__centroid__y', ['shape__centroid__y']):
                result[k] = y

            log_verbose('getting shape__area from shape.area')
            for k in reversed.get('shape__area', ['shape__area']):
                result[k] = object.shape.area
            log_verbose('getting shape__length from shape.length')
            for k in reversed.get('shape__length', ['shape__length']):
                result[k] = object.shape.length
        ## I would like to catch KeyError and AttributeError, but
        ## ArcGIS raises a generic RuntimeError.  I leave the two
        ## redundant more specific types for ease of search.
        except (KeyError, AttributeError, RuntimeError), e:
            log_verbose('accessing the shape: %s' % e)

    # now add the array of values, grouping them...
    if conversion:
        for candidate, pattern in conversion:
            if not array_key.match(pattern):
                continue

            # ok, so candidate is associated to an array of database fields
            log_verbose("looking for set of fields %s to decode into array %s" % (pattern, candidate))

            tried = []
            value = {}
            for key, k in list_of_array_keys(pattern):
                try:
                    tried.append(key)
                    value[k] = object.getvalue(key)
                except:
                    pass
            if value:
                result[candidate] = value
                log_verbose("defining %s as %s" % (candidate, value))
            else:
                log_verbose("not setting %s to anything" % (candidate, ))
                pass

    for field_name, translation_rules in dictionaries.items():
        forward = evaluate_dict_fields(translation_rules, to_lower=True)
        reversed = dict([(k, v[0]) for k, v in reverse_dict(forward).items()])
        reversed = evaluate_dict_fields(reversed, to_lower=True)
        if field_name in result:
            old_value = result[field_name]
            try:
                old_value = old_value.lower()
            except:
                pass
            result[field_name] = reversed.get(old_value, old_value)

    if '-' in result:
        del result['-']
    fields = result.keys()
    fields.sort()
    log_verbose("returning result holding these fields..., %s" % (fields,))
    for key in result.keys():
        if not check_constraints(result, key, ranges.get(key), on_error_fail=on_exception_raise):
            return None
    if primary_key is not None:
        return (result[primary_key], result)
    else:
        return result


def named_in_conversion(conversion):
    """which database fields are named in the conversion dictionary.

    this function returns a 'dict' whereas a 'set' would be a more
    modern choice.
    """

    if conversion is None:
        return {}
    if not isinstance(conversion, types.DictionaryType):
        conversion = dict(conversion)
    result = reverse_dict(conversion)
    for pattern in conversion.values():
        result.update(dict(list_of_array_keys(pattern)))
    result = dict([(k, None) for k in result.keys()])
    return result


def get_table_def(gp, datasource):
    '''reads name and type of all fields of a table.

    returns a dictionary associating names to types
    '''

    return dict([(field.Name.lower(), field.Type)
                 for field in gp_iterator(gp.ListFields(datasource))])


def get_table(gp, datasource, conversion=None, defaults=None, evaluate=False, dictionaries={}, nonevalues=[],
              ranges={}, on_exception_raise=False, primary_key=None, no_shape=False):
    """returns a table as a list/dictionary of dictionaries

    give me a geoprocessor gp and a valid name for a data source
    within gp, I will return you the content of the data source

    if 'primary_key' is None the result is a list of dictionaries.

    if 'primary_key' is not None, the result is a dictionary (key: the
    values of the field 'primary_key') of dictionaries.

    in either case, each the inner dictionaries holds the content of a
    database record.
    """

    log.debug("getting %s" % datasource)
    fields = [i.name for i in gp_iterator(gp.ListFields(datasource))]
    log.debug("table %s has fields %s." % (datasource, str(fields)))

    if conversion is None:
        log.debug("not discarding any field.")
    # check which fields from the datasource are not named in the
    # conversion and log all of them in a warning.
    ## unconverted = [item for item in fields if item not in named_in_conversion(conversion)]
    ## if conversion is not None and unconverted:
    ##     log.warn("%s: fields '%s' remain unconverted" % (datasource, unconverted))

    result = [gp_as_dict(fields, row,
                         conversion=conversion, defaults=defaults,
                         evaluate=evaluate, dictionaries=dictionaries,
                         nonevalues=nonevalues, ranges=ranges, on_exception_raise=on_exception_raise,
                         primary_key=primary_key, no_shape=no_shape)
              for row in gp_iterator(gp.SearchCursor(datasource))]
    result = [i for i in result if i is not None]
    if primary_key is not None:
        return dict(result)
    else:
        return result


def join_on_primary_key(gp, partial_result, datasource, primary_key, conversion=None, defaults=None,
                        evaluate=False, dictionaries={}, nonevalues=[], ranges={}, on_exception_raise=False):
    """joins a table to a dictionary of dictionaries

    give me a geoprocessor gp, a dictionary of dictionaries, a valid
    name for a data source within gp and the primary key of the data
    source, I will augment the dictionary of dictionaries with the
    content of the data source and return this augmented data to you.
    """

    right_table = get_table(gp, datasource, conversion=conversion, defaults=defaults,
                            evaluate=evaluate, dictionaries=dictionaries, nonevalues=nonevalues,
                            ranges=ranges, on_exception_raise=on_exception_raise,
                            primary_key=primary_key)
    for pk, item in partial_result.items():
        item.update(right_table.get(pk, {}))

    return partial_result


def join_dicts(dictlist1, dictlist2, key1, key2=None):
    """left outer join between lists of dictionaries

    returns a list of dictionaries where each element is a new
    dictionary holding all dict1 elements augmented with dict2, if any
    dict2 from dictlist2 matches dict1 from dictlist1
    """

    # key2 defaults to be the same as key1
    if key2 is None:
        key2 = key1

    # case insensitive is implemented by going to lower case.
    if isinstance(key1, types.StringType):
        key1 = key1.lower()
    if isinstance(key2, types.StringType):
        key2 = key2.lower()

    # prepare an index on the second list...  for better performance
    index2 = dict([(item[key2], item) for item in dictlist2])

    result = []
    for item in dictlist1:
        item = dict(item)
        item.update(index2.get(item[key1], {}))
        result.append(item)
    return result


def join_on_foreign_key(gp, dictlist, key=None, fields=None, table=None, pk=None, fk=None, conversion=None, sort_on=None, nonevalues=[], defaults=None, evaluate=False, ranges={}):
    """gets objects from the 'table' and joins them to those in 'dictlist'.

    for each object retrieved from the table, construct the list of
    values associated to the list 'fields'.

    the new objects are grouped by 'pk' and these are associated
    to the ones in 'dictlist' having the same value for the 'fk'
    field.

    in the end, in each element of 'dictlist', you have a 'key' value
    associated to the list of lists thus retrieved.
    """

    if fk == None:
        fk = pk
    if pk == None:
        pk = fk
    temp = [(i[pk], [i[k] for k in fields]) for i in get_table(gp, table, conversion, nonevalues=nonevalues, defaults=defaults, evaluate=evaluate, ranges=ranges)]
    pool = {}
    for i in temp:
        pool.setdefault(i[0], []).append(i[1])
    for i in dictlist:
        value = pool.get(i[fk], [])
        if sort_on is not None:
            value.sort(key=operator.itemgetter(sort_on))
        i[key] = value


def replace_notavalue(d, not_a_value):
    """replaces matching entries in dictionary d with None

    if a value in d matches a 'not_a_value' entries, the value in d is
    overwritten with a None.

    modifies and returns the modified dictionary.
    (version for 2.3 and later)
    """

    if isinstance(not_a_value, dict):
        not_a_value = not_a_value.values()
    elif not isinstance(not_a_value, (list, tuple)):
        not_a_value = [not_a_value]
    for k, v in d.items():
        if v in not_a_value:
            d[k] = None
    return d


def loggable_name(geo_name):
    """returns a shortened name

    give me a complete name of a ArcGIS thing, I'll strip the name of
    the ArcGIS database and return the remaining part"""

    import re
    import os
    splitter = re.compile(r"[\\/]")
    split = [i for i in splitter.split(geo_name) if i]
    if os.name == 'posix':
        split.insert(0, '')
    for i in range(1, len(split) + 1):
        try:
            os.listdir(os.sep.join(split[:i] + ['']))
        except:
            break
    return '/'.join(split[i:])


def firstAvailableFilename(gp, filename, ext=".shp"):
    """make unique name

    Deze functie bekijkt of een bepaalde file al bestaat (volgens de
    geoprocessor) en indien ja, dan wordt aan de filenaam een unique
    sequentieel getal toegevoegd.  De input is de filenaam zonder
    extensie.  extensie ext kan worden gespecificeerd en anders is het
    '.shp'

    returns a valid filename that does not yet exist according to the geoprocessor.
    """
    # deze functie is gemaakt omdat arcgis soms een lock op een
    # bestand zet waardoor de file niet gedelete kan worden of
    # overschreven.  indien arcgis 9.3 gebruikt wordt is deze funcite
    # waarschijnlijk overbodig omdat je dan gebruik kan maken van
    # testschemalock.

    log.info("looking for an available filename in the geoprocessor")

    n = 0
    candidate = filename + ext
    while True:
        if not gp.Exists(candidate):
            return candidate
        n += 1
        candidate = filename + "_" + str(n) + ext

if sys.version_info < (2, 3):
    """redefine a few things for older python...
    """

    del replace_notavalue

    def replace_notavalue(d, not_a_value):
        """replaces matching entries in dictionary d with None

        if a value in d matches a 'not_a_value' entries, the value in d is
        overwritten with a None.

        modifies and returns the modified dictionary.
        (version for before 2.3)
        """

        if isinstance(not_a_value, types.DictionaryType):
            not_a_value = not_a_value.values()
        elif not isinstance(not_a_value, types.ListType) and not isinstance(not_a_value, types.TupleType):
            not_a_value = [not_a_value]
        for k, v in d.items():
            if v in not_a_value:
                d[k] = None
        return d


class validfilename_functor:
    def __init__(self):
        import re
        self.symbols = re.compile(r'[!@#\$%\^&\*()\-\+=_{}\[\]:";\'>\?\./,< ]')
        self.leadingdigits = re.compile(r'^[0-9]*')

    def __call__(self, name, maxlen=30):
        result = name
        result = ''.join(self.symbols.split(result))[:maxlen]
        result = ''.join(self.leadingdigits.split(result))[:maxlen]
        return result

validfilename = validfilename_functor()


def testsuite():
    """Return test suite"""

    from nens import mock

    class IteratorTest(unittest.TestCase):
        def test0iterator(self):
            "testing iterator"
            c = mock.GpDispatch.Cursor([{'key1': 'v1', 'key2': 'v2'},
                                        {'key1': 'v1', 'key2': 'v3'},
                                        {'key1': 'v1', 'key2': 'v4'},
                                        ])
            for i in gp_iterator(c):
                self.assertEqual(i.key1, "v1")

    class DictJoinTest(unittest.TestCase):
        def test0dictjoin(self):
            "testing join on dictionary lists"
            pass

        def test1dictjoin(self):
            "simple case"
            dl1 = [{1:1, 2:2}, {1:4, 2:3}]
            dl2 = [{1:1, 3:2}, {1:4, 3:3}]
            key = 1
            result = [{1:1, 2:2, 3:2}, {1:4, 2:3, 3:3}]
            self.assertEqual(join_dicts(dl1, dl2, key), result)

        def test2dictjoin(self):
            "second overwrites first"
            dl1 = [{1:1, 2:2}, {1:4, 2:3}]
            dl2 = [{1:1, 3:2}, {1:4, 3:3, 2:2}]
            key = 1
            result = [{1:1, 2:2, 3:2}, {1:4, 2:2, 3:3}]
            self.assertEqual(join_dicts(dl1, dl2, key), result)

        def test3dictjoin(self):
            "does not force fields"
            dl1 = [{1:1, 2:2}, {1:4, 2:3}]
            dl2 = [{1:1, 3:2}, {1:4}]
            key = 1
            result = [{1:1, 2:2, 3:2}, {1:4, 2:3}]
            self.assertEqual(join_dicts(dl1, dl2, key), result)

        def test4dictjoin(self):
            "silently ignores elements from second list if non matching"
            dl1 = [{1:1, 2:2}, {1:4, 2:3}]
            dl2 = [{1:1, 3:2}, {1:4, 3:3}, {1:5, 3:9}]
            key = 1
            result = [{1:1, 2:2, 3:2}, {1:4, 2:3, 3:3}]
            self.assertEqual(join_dicts(dl1, dl2, key), result)

        def test5dictjoin(self):
            "silently ignores missing elements from second list"
            dl1 = [{1:1, 2:2}, {1:4, 2:3}]
            dl2 = [{1:1, 3:2}, {1:5, 3:9}]
            key = 1
            result = [{1:1, 2:2, 3:2}, {1:4, 2:3, }]
            self.assertEqual(join_dicts(dl1, dl2, key), result)

        def test6dictjoin(self):
            "simple case with different key on second list"
            dl1 = [{1:1, 2:2}, {1:4, 2:3}]
            dl2 = [{5:1, 3:2}, {5:4, 3:9}]
            key1 = 1
            key2 = 5
            result = [{1:1, 5:1, 2:2, 3:2}, {1:4, 5:4, 2:3, 3:9}]
            self.assertEqual(join_dicts(dl1, dl2, key1, key2), result)

        def test7dictjoin(self):
            "join is case insensitive and returns lower case keys"
            dl1 = [{'abc':1, 2:2}, {'abc':4, 2:3}]
            dl2 = [{'abc':1, 3:2}, {'abc':4, 3:9}]
            key1 = 'Abc'
            result = [{'abc':1, 2:2, 3:2}, {'abc':4, 2:3, 3:9}]
            self.assertEqual(join_dicts(dl1, dl2, key1), result)

    class GetTableTest(unittest.TestCase):
        def test0gettable(self):
            "get table from geoprocessor returns lower case keys"
            tableIn = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                {'Abc': 125, 'eee': 434, 'DEF': 456, 'test': 787, 'Finis': 999},
                {'Abc': 126, 'eee': 444, 'DEF': 556, 'test': 687, 'Finis': 999},
                {'Abc': 127, 'eee': 454, 'DEF': 656, 'test': 587, 'Finis': 999},
                {'Abc': 128, 'eee': 464, 'DEF': 756, 'test': 487, 'Finis': 999},
                {'Abc': 129, 'eee': 474, 'DEF': 856, 'test': 387, 'Finis': 999},
                ]
            tableExpect = [
                {'abc': 123, 'eee': 414, 'def': 256, 'test': 987, 'finis': 999},
                {'abc': 124, 'eee': 424, 'def': 356, 'test': 887, 'finis': 999},
                {'abc': 125, 'eee': 434, 'def': 456, 'test': 787, 'finis': 999},
                {'abc': 126, 'eee': 444, 'def': 556, 'test': 687, 'finis': 999},
                {'abc': 127, 'eee': 454, 'def': 656, 'test': 587, 'finis': 999},
                {'abc': 128, 'eee': 464, 'def': 756, 'test': 487, 'finis': 999},
                {'abc': 129, 'eee': 474, 'def': 856, 'test': 387, 'finis': 999},
                ]
            gp = mock.GpDispatch(default_table=tableIn)
            # first check that the mock gp respects upper/lower case
            fields = [i.name for i in gp_iterator(gp.ListFields(''))]
            self.assertEqual(fields, ['Abc', 'DEF', 'Finis', 'eee', 'test'])
            # then check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso")
            self.assertEqual(tableOut, tableExpect)
            pass

        def test1gettable(self):
            "get table with field name translation - as dict"
            tableIn = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                {'Abc': 125, 'eee': 434, 'DEF': 456, 'test': 787, 'Finis': 999},
                {'Abc': 126, 'eee': 444, 'DEF': 556, 'test': 687, 'Finis': 999},
                {'Abc': 127, 'eee': 454, 'DEF': 656, 'test': 587, 'Finis': 999},
                {'Abc': 128, 'eee': 464, 'DEF': 756, 'test': 487, 'Finis': 999},
                {'Abc': 129, 'eee': 474, 'DEF': 856, 'test': 387, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'nd': 414, 'rd': 256, 'th': 987, 'finis': 999},
                {'st': 124, 'nd': 424, 'rd': 356, 'th': 887, 'finis': 999},
                {'st': 125, 'nd': 434, 'rd': 456, 'th': 787, 'finis': 999},
                {'st': 126, 'nd': 444, 'rd': 556, 'th': 687, 'finis': 999},
                {'st': 127, 'nd': 454, 'rd': 656, 'th': 587, 'finis': 999},
                {'st': 128, 'nd': 464, 'rd': 756, 'th': 487, 'finis': 999},
                {'st': 129, 'nd': 474, 'rd': 856, 'th': 387, 'finis': 999},
                ]
            conversion = {'st': 'abc',
                          'nd': 'eee',
                          'rd': 'def',
                          'th': 'test',
                          }
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test2gettable(self):
            "get table with field name translation - as tuple of pairs"
            tableIn = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                {'Abc': 125, 'eee': 434, 'DEF': 456, 'test': 787, 'Finis': 999},
                {'Abc': 126, 'eee': 444, 'DEF': 556, 'test': 687, 'Finis': 999},
                {'Abc': 127, 'eee': 454, 'DEF': 656, 'test': 587, 'Finis': 999},
                {'Abc': 128, 'eee': 464, 'DEF': 756, 'test': 487, 'Finis': 999},
                {'Abc': 129, 'eee': 474, 'DEF': 856, 'test': 387, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'nd': 414, 'rd': 256, 'th': 987, 'finis': 999},
                {'st': 124, 'nd': 424, 'rd': 356, 'th': 887, 'finis': 999},
                {'st': 125, 'nd': 434, 'rd': 456, 'th': 787, 'finis': 999},
                {'st': 126, 'nd': 444, 'rd': 556, 'th': 687, 'finis': 999},
                {'st': 127, 'nd': 454, 'rd': 656, 'th': 587, 'finis': 999},
                {'st': 128, 'nd': 464, 'rd': 756, 'th': 487, 'finis': 999},
                {'st': 129, 'nd': 474, 'rd': 856, 'th': 387, 'finis': 999},
                ]
            conversion = (('st', 'abc'),
                          ('nd', 'eee'),
                          ('rd', 'def'),
                          ('th', 'test'),
                          )
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test30gettable(self):
            "get table with field name translation - with multiple values on right hand side"
            tableIn1 = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                ]
            tableIn2 = [
                {'rst': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'rst': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'nd': 414, 'rd': 256, 'th': 987, 'finis': 999},
                {'st': 124, 'nd': 424, 'rd': 356, 'th': 887, 'finis': 999},
                ]
            conversion = (('st', 'abc,rst'),
                          ('nd', 'eee'),
                          ('rd', 'def'),
                          ('th', 'test'),
                          )
            gp = mock.GpDispatch(default_table=tableIn1)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            gp = mock.GpDispatch(default_table=tableIn2)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test31gettable(self):
            "get table with field name translation - discard fields"
            tableIn1 = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'th': 987, 'finis': 999},
                {'st': 124, 'th': 887, 'finis': 999},
                ]
            conversion = (('st', 'abc'),
                          ('-', 'eee,def'),
                          ('th', 'test'),
                          )
            gp = mock.GpDispatch(default_table=tableIn1)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test32gettable(self):
            "get table with field name translation - discard fields - on individual lines"
            tableIn1 = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'th': 987, 'finis': 999},
                {'st': 124, 'th': 887, 'finis': 999},
                ]
            conversion = (('st', 'abc'),
                          ('-', 'eee'),
                          ('-', 'def'),
                          ('th', 'test'),
                          )
            gp = mock.GpDispatch(default_table=tableIn1)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test33gettable(self):
            "get table with field name translation - using defaults verbatim"
            tableIn1 = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'th': 987, 'qw': "some text", "num": 123.0, },
                {'st': 124, 'th': 887, 'qw': "some text", "num": 123.0, },
                ]
            conversion = (('st', 'abc'),
                          ('-', 'eee,def,finis'),
                          ('th', 'test'),
                          )
            defaults = (('st', 'abc'),
                        ('qw', 'some text'),
                        ('num', 123.0),
                        ('th', 'test'),
                        )
            gp = mock.GpDispatch(default_table=tableIn1)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion, defaults=defaults)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test34gettable(self):
            "get table with field name translation - using defaults and evaluating them"
            tableIn1 = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'th': 987, 'qw': "some text", "num": 123.0, },
                {'st': 124, 'th': 887, 'qw': "some text", "num": 123.0, },
                ]
            conversion = (('st', 'abc'),
                          ('-', 'eee,def,finis'),
                          ('th', 'test'),
                          )
            defaults = (('st', 'abc'),
                        ('qw', "'some text'"),
                        ('num', '123.0'),
                        ('th', 'test'),
                        )
            gp = mock.GpDispatch(default_table=tableIn1)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion, defaults=defaults, evaluate=True)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test40gettable(self):
            "get table with field name translation - mixed case"
            tableIn = [
                {'Abc': 123, 'eee': 414, 'DEF': 256, 'test': 987, 'Finis': 999},
                {'Abc': 124, 'eee': 424, 'DEF': 356, 'test': 887, 'Finis': 999},
                {'Abc': 125, 'eee': 434, 'DEF': 456, 'test': 787, 'Finis': 999},
                {'Abc': 126, 'eee': 444, 'DEF': 556, 'test': 687, 'Finis': 999},
                {'Abc': 127, 'eee': 454, 'DEF': 656, 'test': 587, 'Finis': 999},
                {'Abc': 128, 'eee': 464, 'DEF': 756, 'test': 487, 'Finis': 999},
                {'Abc': 129, 'eee': 474, 'DEF': 856, 'test': 387, 'Finis': 999},
                ]
            tableExpect = [
                {'st': 123, 'nd': 414, 'rd': 256, 'th': 987, 'finis': 999},
                {'st': 124, 'nd': 424, 'rd': 356, 'th': 887, 'finis': 999},
                {'st': 125, 'nd': 434, 'rd': 456, 'th': 787, 'finis': 999},
                {'st': 126, 'nd': 444, 'rd': 556, 'th': 687, 'finis': 999},
                {'st': 127, 'nd': 454, 'rd': 656, 'th': 587, 'finis': 999},
                {'st': 128, 'nd': 464, 'rd': 756, 'th': 487, 'finis': 999},
                {'st': 129, 'nd': 474, 'rd': 856, 'th': 387, 'finis': 999},
                ]
            conversion = (('ST', 'aBc'),
                          ('Nd', 'eeE'),
                          ('rd', 'Def'),
                          ('th', 'TEST'),
                          )
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test41gettable(self):
            "get table with value translation - through translation dictionaries"
            tableIn = [
                {'st': 123, 'nd': 133},
                {'st': 124, 'nd': 262},
                {'st': 125, 'nd': 384},
                ]
            tableExpect = [
                {'st': 123, 'nd': 414, },
                {'st': 124, 'nd': 424, },
                {'st': 125, 'nd': 434, },
                ]
            dictionaries = {'nd': {'414': '133', '424': '262', '434': '384'},
                            }
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", dictionaries=dictionaries)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test42gettable(self):
            "get table with value translation - through translation dictionaries"
            tableIn = [
                {'st': 123, 'nd': 'rechthoek'},
                {'st': 124, 'nd': 'ovaal'},
                {'st': 125, 'nd': 'RECHTHOEK'},
                ]
            tableExpect = [
                {'st': 123, 'nd': 1, },
                {'st': 124, 'nd': 2, },
                {'st': 125, 'nd': 1, },
                ]
            dictionaries = {'nd': {'1': 'rechthoek', '2': 'ovaal'},
                            }
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", dictionaries=dictionaries)
            self.assertEqual(tableOut, tableExpect)
            pass

        def test8dictjoin(self):
            "get with multiple valued translation and join on that key"
            dl1 = [{'abc':1, 'qwe':2}, {'abc':4, 'qwe':3}]
            dl2 = [{'abg':1, 'asd':2}, {'abg':4, 'asd':9}]
            conversion = (('st', 'abc,abg'),
                          ('nd', 'qwe'),
                          ('rd', 'asd'),
                          )
            gp = mock.GpDispatch(default_table=dl1)
            tb1 = get_table(gp, "nomeACaso", conversion=conversion)
            gp = mock.GpDispatch(default_table=dl2)
            tb2 = get_table(gp, "nomeACaso", conversion=conversion)
            key1 = 'st'
            result = [{'st':1, 'nd':2, 'rd':2}, {'st':4, 'nd':3, 'rd':9}]
            self.assertEqual(join_dicts(tb1, tb2, key1), result)

        def test9_gettable(self):
            "get with field name translation containing table - full"
            tableIn = [{}, ]
            for i in range(11):
                tableIn[0]["lv_%i" % i] = i
            conversion = {'levels': '[lv_%i][0,10]', }
            expectContains = {'levels': dict([(i, i) for i in range(11)])}
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            tableOut[0]['levels']
            self.assertEqual(expectContains['levels'], tableOut[0]['levels'])
            pass

        def testa_gettable(self):
            "get with field name translation containing table - with step"
            tableIn = [{}, ]
            for i in range(5):
                tableIn[0]["lv_%i" % (i * 25)] = i
            conversion = {'levels': '[lv_%i][0,100,25]', }
            tableExpect = [
                {'levels': dict([(i * 25, i) for i in range(5)])},
                ]
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut[0]['levels'], tableExpect[0]['levels'])
            pass

        def testb_gettable(self):
            "get with field name translation containing table - with holes"
            tableIn = [{}, ]
            for i in range(11):
                if i in [2, 3, 5, 7]:
                    continue
                tableIn[0]["lv_%i" % i] = i
            conversion = {'levels': '[lv_%i][0,10]', }
            tableExpect = [
                {'levels': dict([(i, i) for i in range(11) if i not in [2, 3, 5, 7]])},
                ]
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut[0]['levels'], tableExpect[0]['levels'])
            pass

        def testc_gettable(self):
            "get with field name translation containing table - with step and holes"
            tableIn = [{}, ]
            for i in range(5):
                if i == 2:
                    continue
                tableIn[0]["lv_%i" % (i * 25)] = i
            conversion = {'levels': '[lv_%i][0,100,25]', }
            tableExpect = [
                {'levels': dict([(i * 25, i) for i in range(5) if i != 2])},
                ]
            gp = mock.GpDispatch(default_table=tableIn)
            # check that our library converts to lower case
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut[0]['levels'], tableExpect[0]['levels'])
            pass

        def testd_gettable(self):
            "get table with name clash in translation"
            tableIn = [
                {'Abc': 123, 'eee': 414, },
                {'Abc': 124, 'eee': 424, },
                {'Abc': 125, 'eee': 434, },
                {'Abc': 126, 'eee': 444, },
                {'Abc': 127, 'eee': 454, },
                {'Abc': 128, 'eee': 464, },
                {'Abc': 129, 'eee': 474, },
                ]
            conversion = (('ST', 'aBc'),
                          ('extra', 'abc'),
                          ('Nd', 'eeE'),
                          )
            tableExpect = [
                {'st': 123, 'extra': 123, 'nd': 414, },
                {'st': 124, 'extra': 124, 'nd': 424, },
                {'st': 125, 'extra': 125, 'nd': 434, },
                {'st': 126, 'extra': 126, 'nd': 444, },
                {'st': 127, 'extra': 127, 'nd': 454, },
                {'st': 128, 'extra': 128, 'nd': 464, },
                {'st': 129, 'extra': 129, 'nd': 474, },
                ]
            gp = mock.GpDispatch(default_table=tableIn)
            tableOut = get_table(gp, "nomeACaso", conversion=conversion)
            self.assertEqual(tableOut, tableExpect)
            pass

    class DictionaryReversalTest(unittest.TestCase):
        def test0_reverse(self):
            "reversing a normal dictionary"
            d = {1: 2, 2: 3, 3: 4}
            r = reverse_dict(d)
            e = {2: [1], 3: [2], 4: [3]}
            self.assertEqual(e, r)

        def test1_reverse(self):
            "reversing a dictionary with string keys"
            d = {'1': 2, '2': 3, '3': 4}
            r = reverse_dict(d)
            e = {2: ['1'], 3: ['2'], 4: ['3']}
            self.assertEqual(e, r)

        def test2_reverse(self):
            "reversing a dictionary with string values"
            d = {1: '2', 2: '3', 3: '4'}
            r = reverse_dict(d)
            e = {'2': [1], '3': [2], '4': [3]}
            self.assertEqual(e, r)

        def test3_reverse(self):
            "reversing a dictionary with multiple valued string values"
            d = {1: '2', 2: '3', 3: '4,5,6'}
            r = reverse_dict(d)
            e = {'2': [1], '3': [2], '4': [3], '5': [3], '6': [3]}
            self.assertEqual(e, r)

        def test4_reverse(self):
            "reversing a normal dictionary in list format"
            d = [(1, 2), (2, 3), (3, 4)]
            r = reverse_dict(d)
            e = {2: [1], 3: [2], 4: [3]}
            self.assertEqual(e, r)

        def test5_reverse(self):
            "reversing a dictionary in list format with multiple valued string values"
            d = [(1, '2'), (2, '3'), (3, '4,5,6')]
            r = reverse_dict(d)
            e = {'2': [1], '3': [2], '4': [3], '5': [3], '6': [3]}
            self.assertEqual(e, r)

        def test6_reverse(self):
            "reversing a dictionary in list format with multiply defined forward keys"
            d = [(1, '2'), (1, '3'), (1, '4,5,6')]
            r = reverse_dict(d)
            e = {'2': [1], '3': [1], '4': [1], '5': [1], '6': [1]}
            self.assertEqual(e, r)

        def test7_reverse(self):
            "reversing a dictionary with multiply defined backwards keys"
            d = [(1, '2'), (2, '1'), (3, '1')]
            r = reverse_dict(dict(d))
            e = {'1': [2, 3], '2': [1]}
            self.assertEqual(e, r)

        def test8_reverse(self):
            "reversing a dictionary with multiply defined forward and backwards keys"
            d = [(1, '2,1'), (2, '3,1'), (3, '4,5,1')]
            r = reverse_dict(dict(d))
            e = {'1': [1, 2, 3], '2': [1], '3': [2], '4': [3], '5': [3], }
            self.assertEqual(e, r)

    class NotAValueTest(unittest.TestCase):
        def test0not_a_value(self):
            "second parameter is a list"
            d = {1: 1, 2: 2, 3: 3}
            replace_notavalue(d, [1, 3])
            self.assertEqual(d[1], None)
            self.assertEqual(d[2], 2)
            self.assertEqual(d[3], None)

        def test1not_a_value(self):
            "second parameter is a dictionary"
            d = {1: 1, 2: 2, 3: 3}
            replace_notavalue(d, {'label': 3})
            self.assertEqual(d[1], 1)
            self.assertEqual(d[2], 2)
            self.assertEqual(d[3], None)

        def test2not_a_value(self):
            "second parameter is a single value"
            d = {1: 1, 2: 2, 3: 3}
            replace_notavalue(d, 3)
            self.assertEqual(d[1], 1)
            self.assertEqual(d[2], 2)
            self.assertEqual(d[3], None)

        def test3not_a_value(self):
            "returns the modified dictionary"
            d = {1: 1, 2: 2, 3: 3}
            r = replace_notavalue(d, 3)
            self.assertEqual(d, r)

    class GpLoggingHandler(unittest.TestCase):
        "also have a look at http://code.env.duke.edu/projects/mget/browser/MGET/Trunk/PythonPackage/src/GeoEco/Logging.py?rev=15"

        def test01(self):
            "can create the handler"
            gp = mock.GpDispatch()
            h = GpHandler(geoprocessor=gp)
            self.assertTrue(h != None)

        def test02(self):
            "can set the level of the handler"
            gp = mock.GpDispatch()
            h = GpHandler(geoprocessor=gp)
            h.setLevel(logging.WARNING)
            self.assertEqual(h.level, logging.WARNING)

        def test03(self):
            "can attach the handler to the root logger"
            gp = mock.GpDispatch()
            h = GpHandler(level=logging.ERROR, geoprocessor=gp)
            rootlog = logging.getLogger('')
            rootlog.addHandler(h)
            pass

        def test04(self):
            "handler ignores a logging message of lower log_level"
            gp = mock.GpDispatch()
            h = GpHandler(level=logging.ERROR, geoprocessor=gp)
            rootlog = logging.getLogger('')
            loclog = logging.getLogger('nens.gp.test')
            rootlog.addHandler(h)
            loclog.debug('test')
            self.assertEqual(gp.receivedMessages, [])

        def test05(self):
            "handler at loglevel DEBUG sends ERROR to GP.AddError"
            gp = mock.GpDispatch()
            h = GpHandler(level=logging.DEBUG, geoprocessor=gp, format="%(message)s")
            rootlog = logging.getLogger('')
            loclog = logging.getLogger('nens.gp.test')
            rootlog.addHandler(h)
            loclog.error('test')
            self.assertEqual(gp.receivedMessages, [(logging.ERROR, 'test')])

        def test06(self):
            "handler at loglevel DEBUG sends WARNING to GP.AddWarning"
            gp = mock.GpDispatch()
            h = GpHandler(level=logging.DEBUG, geoprocessor=gp, format="%(message)s")
            rootlog = logging.getLogger('')
            loclog = logging.getLogger('nens.gp.test')
            rootlog.addHandler(h)
            loclog.warning('test')
            self.assertEqual(gp.receivedMessages, [(logging.WARNING, 'test')])
            pass

        def test07(self):
            "handler at loglevel DEBUG sends INFO to GP.AddMessage"
            gp = mock.GpDispatch()
            h = GpHandler(level=logging.DEBUG, geoprocessor=gp, format="%(message)s")
            rootlog = logging.getLogger('')
            loclog = logging.getLogger('nens.gp.test')
            rootlog.addHandler(h)
            loclog.setLevel(logging.INFO)
            loclog.info('test')
            self.assertEqual(gp.receivedMessages, [(logging.INFO, 'test')])
            pass

        def test08(self):
            "handler at loglevel DEBUG sends DEBUG to GP.AddMessage"
            gp = mock.GpDispatch()
            h = GpHandler(level=logging.DEBUG, geoprocessor=gp, format="%(message)s")
            rootlog = logging.getLogger('')
            loclog = logging.getLogger('nens.gp.test')
            rootlog.addHandler(h)
            loclog.setLevel(logging.DEBUG)
            loclog.debug('test')
            self.assertEqual(gp.receivedMessages, [(logging.INFO, 'test')])
            pass

        def test09(self):
            "handler has INFO default loglevel"
            gp = mock.GpDispatch()
            h = GpHandler(geoprocessor=gp, format="%(message)s")
            rootlog = logging.getLogger('')
            loclog = logging.getLogger('nens.gp.test')
            rootlog.addHandler(h)
            loclog.setLevel(logging.DEBUG)
            loclog.debug('test-ignored')
            loclog.info('test')
            self.assertEqual(gp.receivedMessages, [(logging.INFO, 'test')])
            pass

    class AddingObjectsToATable(unittest.TestCase):
        root = [
            {'id': 1, 'nm': 414, },
            {'id': 2, 'nm': 414, },
            {'id': 3, 'nm': 414, },
            ]
        branches = [
            {'id': 1, 'x': 123, 'y': 414, 'z': 256, },
            {'id': 1, 'x': 124, 'y': 424, 'z': 356, },
            {'id': 1, 'x': 125, 'y': 434, 'z': 456, },
            {'id': 1, 'x': 126, 'y': 444, 'z': 556, },
            {'id': 2, 'x': 127, 'y': 454, 'z': 656, },
            {'id': 2, 'x': 128, 'y': 464, 'z': 756, },
            {'id': 2, 'x': 129, 'y': 474, 'z': 856, },
            ]
        branches_2 = [
            {'id': 1, 'x': 24, 'y': 42, 'z': 3, },
            {'id': 1, 'x': 23, 'y': 41, 'z': 2, },
            {'id': 1, 'x': 25, 'y': 43, 'z': 4, },
            {'id': 2, 'x': 28, 'y': 46, 'z': 7, },
            {'id': 1, 'x': 26, 'y': 44, 'z': 5, },
            {'id': 2, 'x': 27, 'y': 45, 'z': 6, },
            {'id': 2, 'x': 29, 'y': 47, 'z': 8, },
            ]

        def test01(self):
            "a new object contains no tables"
            gp = mock.GpDispatch(default_table=self.root)
            root_dict = get_table(gp, "nomeACaso")
            self.assertTrue(root_dict != None)

            pass

        def test20(self):
            "adding objects to an object (unnamed)"
            gp = mock.GpDispatch(default_table=self.root)
            root_dict = get_table(gp, "nomeACaso")
            gp = mock.GpDispatch(default_table=self.branches)
            join_on_foreign_key(gp, root_dict, key=None, fields=['x', 'y', 'z'], table="nomeACaso", pk='id')
            self.assertEqual(root_dict[0].get(None), [[123, 414, 256, ], [124, 424, 356, ], [125, 434, 456, ], [126, 444, 556, ], ])
            self.assertEqual(root_dict[1].get(None), [[127, 454, 656, ], [128, 464, 756, ], [129, 474, 856, ], ])

        def test21(self):
            "adding objects to an object (named)"
            gp = mock.GpDispatch(default_table=self.root)
            root_dict = get_table(gp, "nomeACaso")
            gp = mock.GpDispatch(default_table=self.branches)
            join_on_foreign_key(gp, root_dict, key='uno', fields=['x', 'y', 'z'], table="nomeACaso", pk='id')
            gp = mock.GpDispatch(default_table=self.branches_2)
            join_on_foreign_key(gp, root_dict, key='due', fields=['x', 'y', 'z'], table="nomeACaso", pk='id')
            self.assertEqual(root_dict[0].get('uno'), [[123, 414, 256], [124, 424, 356], [125, 434, 456], [126, 444, 556]])
            self.assertEqual(root_dict[1].get('uno'), [[127, 454, 656, ], [128, 464, 756, ], [129, 474, 856, ], ])
            self.assertEqual(root_dict[0].get('due'), [[24, 42, 3], [23, 41, 2], [25, 43, 4], [26, 44, 5]])
            self.assertEqual(root_dict[1].get('due'), [[28, 46, 7], [27, 45, 6], [29, 47, 8]])

        def test31(self):
            "adding objects to an object (named), sorted by value"
            gp = mock.GpDispatch(default_table=self.root)
            root_dict = get_table(gp, "nomeACaso")
            gp = mock.GpDispatch(default_table=self.branches)
            join_on_foreign_key(gp, root_dict, key='uno', fields=['x', 'y', 'z'], table="nomeACaso", pk='id', sort_on=0)
            gp = mock.GpDispatch(default_table=self.branches_2)
            join_on_foreign_key(gp, root_dict, key='due', fields=['x', 'y', 'z'], table="nomeACaso", pk='id', sort_on=0)
            self.assertEqual(root_dict[0].get('uno'), [[123, 414, 256], [124, 424, 356], [125, 434, 456], [126, 444, 556]])
            self.assertEqual(root_dict[1].get('uno'), [[127, 454, 656, ], [128, 464, 756, ], [129, 474, 856, ], ])
            self.assertEqual(root_dict[0].get('due'), [[23, 41, 2], [24, 42, 3], [25, 43, 4], [26, 44, 5]])
            self.assertEqual(root_dict[1].get('due'), [[27, 45, 6], [28, 46, 7], [29, 47, 8]])

        def test30(self):
            "adding objects to an object (unnamed) - and finding empty list"
            gp = mock.GpDispatch(default_table=self.root)
            root_dict = get_table(gp, "nomeACaso")
            gp = mock.GpDispatch(default_table=self.branches)
            join_on_foreign_key(gp, root_dict, key=None, fields=['x', 'y', 'z'], table="nomeACaso", pk='id')
            self.assertEqual(root_dict[2].get(None), [])

    class RecognizingNullValues(unittest.TestCase):
        branches = [
            {'id': 123, 'x': 123, 'y': 414, 'z': 256, },
            {'id': 123, 'x': None, 'y': 424, 'z': 356, },
            {'id': 124, 'x': 125, 'y': -9999, 'z': 456, },
            {'id': 124, 'x': 126, 'y': 444, 'z': -9999.9999, },
            ]
        tableIn = [
            {'id': 123, 'eee': -9999, 'def': 256, 'test': 987, },
            {'id': 124, 'eee': -9999, 'def': -9999.9999, 'test': 887, },
            {'id': 125, 'eee': 434, 'def': 456, 'test': None, },
            ]
        tableExpect = [
            {'id': 123, 'eee': None, 'def': 256, 'test': 987, },
            {'id': 124, 'eee': None, 'def': None, 'test': 887, },
            {'id': 125, 'eee': 434, 'def': 456, 'test': None, },
            ]
        tableExpectJoined = [
            {'id': 123, 'eee': None, 'def': 256, 'test': 987, 'xyz': [[123, 414, 256, ], [None, 424, 356]], },
            {'id': 124, 'eee': None, 'def': None, 'test': 887, 'xyz': [[125, None, 456], [126, 444, None]], },
            {'id': 125, 'eee': 434, 'def': 456, 'test': None, 'xyz': [], },
            ]
        tableExpectJoinedReplaced = [
            {'id': 123, 'eee': None, 'def': 256, 'test': 987, 'xyz': [[123, 414, 256, ], [0, 424, 356]], },
            {'id': 124, 'eee': None, 'def': None, 'test': 887, 'xyz': [[125, 0, 456], [126, 444, 0]], },
            {'id': 125, 'eee': 434, 'def': 456, 'test': None, 'xyz': [], },
            ]

        def test00(self):
            "get table translating null values."
            gp = mock.GpDispatch(default_table=self.tableIn)
            # check that our library converts special values to None
            tableOut = get_table(gp, "nomeACaso", nonevalues=[-9999, -9999.9999])
            self.assertEqual(tableOut, self.tableExpect)
            pass

        def test10(self):
            "recognizing null values on joined tables."
            gp = mock.GpDispatch(default_table=self.tableIn)
            # check that our library converts special values to None
            tableOut = get_table(gp, "nomeACaso", nonevalues=[-9999, -9999.9999])
            gp = mock.GpDispatch(default_table=self.branches)
            join_on_foreign_key(gp, tableOut, key='xyz', fields=['x', 'y', 'z', ], table="nome_a_caso", pk='id', fk='id', nonevalues=[-9999, -9999.9999])
            self.assertEqual(tableOut, self.tableExpectJoined)
            pass

        def test20(self):
            "replace null values with defaults on joined tables."
            gp = mock.GpDispatch(default_table=self.tableIn)
            # check that our library converts special values to None
            tableOut = get_table(gp, "nomeACaso", nonevalues=[-9999, -9999.9999])
            gp = mock.GpDispatch(default_table=self.branches)
            join_on_foreign_key(gp, tableOut, key='xyz', fields=['x', 'y', 'z', ], table="nome_a_caso", pk='id', fk='id', nonevalues=[-9999, -9999.9999], defaults={'x': 0, 'y': 0, 'z': 0})
            self.assertEqual(tableOut, self.tableExpectJoinedReplaced)
            pass

    class RangeChecking(unittest.TestCase):
        tableIn = [
            {'abc': 3, 'eee': 4, 'def': '256', },
            {'abc': 4, 'eee': 2, 'def': '356', },
            {'abc': 6, 'eee': -4, 'def': None, },
            {'abc': 0, 'eee': 5, 'def': '12345678', },
            {'abc': 8, 'eee': 999, 'def': '756', },
            {'abc': 999, 'eee': 7, 'def': '856', },
            ]
        tableExpectFilter = [
            {'abc': 3, 'eee': 4, 'def': '256', },
            {'abc': 4, 'eee': 2, 'def': '356', },
            {'abc': 8, 'eee': 999, 'def': '756', },
            {'abc': 999, 'eee': 7, 'def': '856', },
            ]
        tableExpectSubstitute = [
            {'abc': 3, 'eee': 4, 'def': '256', },
            {'abc': 4, 'eee': 2, 'def': '356', },
            {'abc': 6, 'eee': -4, 'def': None, },
            {'abc': 0, 'eee': 5, 'def': '12345678', },
            {'abc': 8, 'eee': None, 'def': '756', },
            {'abc': None, 'eee': 7, 'def': '856', },
            ]
        tableExpectSubstituteFilter = [
            {'abc': 3, 'eee': 4, 'def': '256', },
            {'abc': 4, 'eee': 2, 'def': '356', },
            ]
        tableExpectSubstituteFilterOptional = [
            {'abc': 3, 'eee': 4, 'def': '256', },
            {'abc': 4, 'eee': 2, 'def': '356', },
            {'abc': 8, 'eee': None, 'def': '756', },
            {'abc': None, 'eee': 7, 'def': '856', },
            ]

        def test10(self):
            "range splitter"

            for s, l in [("NonNegative W[-,100]", (False, ['NonNegative', 'W[-,100]'])),
                         ("NonNegative W[-, 100]", (False, ['NonNegative', 'W[-, 100]'])),
                         ("Integer NonNegative W[-, 100]", (False, ['Integer', 'NonNegative', 'W[-, 100]'])),
                         ("Integer NonNegative [-, 100]", (False, ['Integer', 'NonNegative', '[-, 100]'])),
                         ("W[-, 100]", (False, ['W[-, 100]'])),
                         ("[-, 100]", (False, ['[-, 100]'])),
                         ("string(100)", (False, ['string(100)'])),
                         ("(Integer NonNegative)", (True, ['Integer', 'NonNegative', ])),
                         ("(Integer [-50,50] [wp,-])", (True, ['Integer', '[-50,50]', '[wp,-]', ])),
                         ("(Integer [-50,50]    [wp,-])", (True, ['Integer', '[-50,50]', '[wp,-]', ])),
                         ]:
                self.assertEqual(split_constraints(s), l)

        def test12(self):
            "range splitter does not crash on empty input"

            for s in [None, '', ]:
                split_constraints(s)

        def test130(self):
            "check integer against valid range gives True"
            obj = {'a': 12}
            constraints = '[10,20]'
            self.assertEqual(check_constraints(obj, 'a', constraints), True)

        def test132(self):
            "check integer outside weak range gives True"
            obj = {'a': 22}
            constraints = 'w[10,20]'
            self.assertEqual(check_constraints(obj, 'a', constraints), True)

        def test134(self):
            "check integer outside range gives False"
            obj = {'a': 22}
            constraints = '[10,20]'
            self.assertEqual(check_constraints(obj, 'a', constraints), False)

        def test136(self):
            "check None against range gives False"
            obj = {'a': None}
            constraints = '[10,20]'
            self.assertEqual(check_constraints(obj, 'a', constraints), False)

        def test138(self):
            "check None against optional range gives True"
            obj = {'a': None}
            constraints = '([10,20])'
            self.assertEqual(check_constraints(obj, 'a', constraints), True)

        def test140(self):
            "check None against positive gives False"
            obj = {'a': None}
            constraints = 'positive'
            self.assertEqual(check_constraints(obj, 'a', constraints), False)

        def test142(self):
            "check None against optional positive gives True"
            obj = {'a': None}
            constraints = '(positive)'
            self.assertEqual(check_constraints(obj, 'a', constraints), True)

        def test150(self):
            "check moving interval - false"
            obj = {'a': 1, 'b': 2}
            constraints = '[b,-]'
            self.assertEqual(check_constraints(obj, 'a', constraints), False)

        def test151(self):
            "check moving interval - true"
            obj = {'a': 3, 'b': 2}
            constraints = '[b,-]'
            self.assertEqual(check_constraints(obj, 'a', constraints), True)

        def test152(self):
            "check moving interval - both cases"
            constraints = 'positive [eee,-]'
            obj = {'eee': 4, 'abc': 3, 'def': '256'}
            self.assertEqual(check_constraints(obj, 'abc', constraints), False)
            obj = {'eee': 2, 'abc': 4, 'def': '356'}
            self.assertEqual(check_constraints(obj, 'abc', constraints), True)

        def test155(self):
            "check moving interval and fixed interval - both cases"
            constraints = 'positive [-50,50] [eee,-]'
            obj = {'eee': 4, 'abc': 3, 'def': '256'}
            self.assertEqual(check_constraints(obj, 'abc', constraints), False)
            obj = {'eee': 2, 'abc': 4, 'def': '356'}
            self.assertEqual(check_constraints(obj, 'abc', constraints), True)

        def test157(self):
            "check moving interval and fixed interval - both cases"
            constraints = 'positive [-50,50] [-,abc]'
            obj = {'eee': 4, 'abc': 3, 'def': '256'}
            self.assertEqual(check_constraints(obj, 'eee', constraints), False)
            obj = {'eee': 2, 'abc': 4, 'def': '356'}
            self.assertEqual(check_constraints(obj, 'eee', constraints), True)

        def test20(self):
            "gp_as_dict can check ranges"

            ranges = {'abc': 'positive',
                      'eee': 'nonnegative',
                      }
            count_none = 0
            for obj_in in self.tableIn:
                row_in = mock.GpDispatch.Row(obj_in)
                obj_out = gp_as_dict(['abc', 'def', 'eee'], row_in, ranges=ranges)
                if obj_out is None:
                    count_none += 1
                    continue
                self.assertEqual(obj_out, obj_in)
            self.assertEqual(count_none, 2)

        def test30(self):
            "numerical range checking as filters"

            ranges = {'abc': 'positive',
                      'eee': 'nonnegative',
                      }

            gp = mock.GpDispatch(default_table=self.tableIn)
            tableOut = get_table(gp, "nomeACaso",
                                 ranges=ranges)
            self.assertEqual(tableOut, self.tableExpectFilter)
            pass

        def test35(self):
            "string range checking as filters"

            ranges = {'def': 'string(4)',
                      }
            gp = mock.GpDispatch(default_table=self.tableIn)
            tableOut = get_table(gp, "nomeACaso",
                                 ranges=ranges)
            self.assertEqual(tableOut, self.tableExpectFilter)
            pass

        def test40(self):
            "special values are recognized as None before filtering - and are filtered out"

            ranges = {'abc': 'positive [-,100]',
                      'eee': 'positive [-,100]',
                      'def': 'string(4)',
                      }
            gp = mock.GpDispatch(default_table=self.tableIn)
            tableOut = get_table(gp, "nomeACaso",
                                 ranges=ranges,
                                 nonevalues=[999])
            self.assertEqual(tableOut, self.tableExpectSubstituteFilter)
            pass

        def test42(self):
            "special values are recognized as None before filtering - and are accepted by optional filter"

            ranges = {'abc': '(positive [-,100])',
                      'eee': '(positive [-,100])',
                      'def': '(string(4))',
                      }
            gp = mock.GpDispatch(default_table=self.tableIn)
            tableOut = get_table(gp, "nomeACaso",
                                 ranges=ranges,
                                 nonevalues=[999])
            self.assertEqual(tableOut, self.tableExpectSubstituteFilterOptional)
            pass

        def test500(self):
            "filtering on ranges that refer to other fields"

            ranges = {'wp': '[-100,zp]',
                      'zp': '[wp,100]',
                      }
            tableIn = [
                {'wp': 3, 'zp': 4, },
                {'wp': 4, 'zp': 2, },
                ]
            tableExpect = [
                {'wp': 3, 'zp': 4, },
                ]
            gp = mock.GpDispatch(default_table=tableIn)
            tableOut = get_table(gp, "nomeACaso",
                                 ranges=ranges,
                                 )
            self.assertEqual(tableOut, tableExpect)
            pass

    class NamedInConversion(unittest.TestCase):
        def test00(self):
            "named_in_conversion can cope with None"
            self.assertEqual(named_in_conversion(None), {})

        def test01(self):
            "named_in_conversion finds plain named fields"
            conversion = {'st': 'abc',
                          'th': 'test',
                          }
            self.assertEqual(named_in_conversion(conversion), {'abc': None, 'test': None, })

        def test02(self):
            "named_in_conversion finds array fields"
            conversion = {'levels': '[lv_%i][0,10]', }
            self.assertEqual(named_in_conversion(conversion), {'lv_0': None, 'lv_1': None, 'lv_2': None,
                                                               'lv_3': None, 'lv_4': None, 'lv_5': None,
                                                               'lv_6': None, 'lv_7': None, 'lv_8': None,
                                                               'lv_9': None, 'lv_10': None, })

        def test03(self):
            "named_in_conversion finds array fields with step"
            conversion = {'levels': '[lv_%i][0,100,25]', }
            self.assertEqual(named_in_conversion(conversion), {'lv_0': None, 'lv_25': None, 'lv_50': None, 'lv_75': None, 'lv_100': None, })

        def test04(self):
            "named_in_conversion finds multiple named fields - list"
            conversion = (('st', 'abc'),
                          ('-', 'eee,def,finis'),
                          ('th', 'test'),
                          )
            self.assertEqual(named_in_conversion(conversion), {'abc': None, 'eee': None, 'def': None, 'finis': None, 'test': None, })

        def test05(self):
            "named_in_conversion finds multiple named fields - dict"
            conversion = {'st': 'abc',
                          '-': 'eee,def,finis',
                          'th': 'test',
                          }
            self.assertEqual(named_in_conversion(conversion), {'abc': None, 'eee': None, 'def': None, 'finis': None, 'test': None, })

    class ShortenObjectName(unittest.TestCase):
        import os
        if os.name == 'posix':
            valid_dir = '/usr/local/geodatabase'
        else:
            valid_dir = "C:/Program Files/geodatabase"

        def test00(self):
            "loggable_name returns all parts after first non directory entry - empty"
            self.assertEqual(loggable_name(self.valid_dir), "")

        def test01(self):
            "loggable_name returns all parts after first non directory entry - one entry"
            self.assertEqual(loggable_name(self.valid_dir + "/level/"), "level")

        def test02(self):
            "loggable_name returns all parts after first non directory entry - two entries"
            self.assertEqual(loggable_name(self.valid_dir + "/level/second"), "level/second")

    class GetTableAndJoinOnPrimaryKey(unittest.TestCase):
        tables = {'first': [{'pk': '1', 'abc':1, 'due':2, },
                            {'pk': '2', 'abc':4, 'due':3, },
                            {'pk': '3', 'abc':4, 'due':3, },
                            ],
                  'second': [{'pk': '1', 'tre':1, },
                             {'pk': '2', 'tre':4, },
                             {'pk': '3', 'tre':4, },
                             ],
                  'third': [{'pk': '1', 'tre':1, },
                            {'pk': '2', 'tre':4, },
                            ],
                  }

        def test00(self):
            "get_table / primary_key: result is dict of dict"
            gp = mock.GpDispatch(default_table=None, tables=self.tables)
            table = get_table(gp, 'first', primary_key='pk')
            if sys.version_info < (2, 3):
                self.assertEqual(isinstance(table, types.DictionaryType), True)
            else:
                self.assertTrue(isinstance(table, types.DictionaryType))

        def test02(self):
            "get_table / primary_key: associates row to value of primary key"
            gp = mock.GpDispatch(default_table=None, tables=self.tables)
            table = get_table(gp, 'first', primary_key='pk')
            self.assertEqual(table['1'], self.tables['first'][0])

        def test04(self):
            "join_on_primary_key - returns augmented dictionary"
            gp = mock.GpDispatch(default_table=None, tables=self.tables)
            table = get_table(gp, 'first', primary_key='pk')
            augmented = join_on_primary_key(gp, table, 'second', 'pk')
            self.assertEqual(augmented, table)

        def test06(self):
            "join_on_primary_key - returns augmented contains data from second table"
            gp = mock.GpDispatch(default_table=None, tables=self.tables)
            table = get_table(gp, 'first', primary_key='pk')
            join_on_primary_key(gp, table, 'second', 'pk')
            self.assertEqual(table['1']['due'], 2)
            self.assertEqual(table['1']['tre'], 1)
            self.assertEqual(table['2']['due'], 3)
            self.assertEqual(table['2']['tre'], 4)

        def test10(self):
            "join_on_primary_key - does not complain if second table does not augment an object"
            gp = mock.GpDispatch(default_table=None, tables=self.tables)
            table = get_table(gp, 'first', primary_key='pk')
            join_on_primary_key(gp, table, 'third', 'pk')
            self.assertEqual(table['1']['tre'], 1)
            self.assertEqual(table['2']['tre'], 4)
            if sys.version_info < (2, 3):
                self.fail("can't test this in older python")
            else:
                self.assertRaises(KeyError, table['3'].__getitem__, 'tre')

        def test12(self):
            "join_on_primary_key - if first table does not define object, it remains unknown"
            gp = mock.GpDispatch(default_table=None, tables=self.tables)
            table = get_table(gp, 'third', primary_key='pk')
            join_on_primary_key(gp, table, 'first', 'pk')
            self.assertEqual(table['1']['due'], 2)
            self.assertEqual(table['2']['due'], 3)
            if sys.version_info < (2, 3):
                self.fail("can't test this in older python")
            else:
                self.assertRaises(KeyError, table.__getitem__, '3')

    class GetTableWarnsAboutUnconvertedColumns(unittest.TestCase):
        tables = [{'pk': '1', 'abc':1, 'due':2, 'tre':2, 'ctr':2, },
                  {'pk': '2', 'abc':4, 'due':3, 'tre':3, 'ctr':3, },
                  {'pk': '3', 'abc':4, 'due':3, 'tre':3, 'ctr':3, },
                  ]
        import logging
        log = logging.getLogger('test')
        handler = mock.Handler(level=logging.DEBUG)
        rootlog = logging.getLogger('')
        rootlog.addHandler(handler)
        orig_rootlog_level = rootlog.level

        def test00(self):
            "get_table - warns about unconverted columns"

            conversion = {'col1': 'abc',
                          'col2': 'tre',
                          'id': 'pk',
                          }
            self.handler.flush()
            gp = mock.GpDispatch(self.tables)
            table = get_table(gp, 'first', conversion=conversion)
            self.assertTrue(table != None)
            relevant = [i for i in self.handler.content if i.find("remain unconverted") != -1]
            self.assertEquals(["nens.gp|WARNING|first: fields '['ctr', 'due']' remain unconverted"], relevant)
            self.rootlog.level = self.orig_rootlog_level

        def test01(self):
            "get_table - conversion is case insensitive"

            conversion = {'col1': 'ABC',
                          'col3': 'tre',
                          'col4': 'ctr',
                          'id': 'PK',
                          }
            self.handler.flush()
            gp = mock.GpDispatch(self.tables)
            self.rootlog.level = logging.DEBUG
            table = get_table(gp, 'first', conversion=conversion)
            self.assertTrue(table != None)
            relevant = [i for i in self.handler.content if i.find("remain unconverted") != -1]
            self.assertEquals(["nens.gp|WARNING|first: fields '['due']' remain unconverted"], relevant)
            self.rootlog.level = self.orig_rootlog_level

        def test02(self):
            "get_table - explicitly ignored: no warning."

            conversion = {'col1': 'ABC',
                          'id': 'PK',
                          '-': 'ctr,due,tre',
                          }
            self.handler.flush()
            gp = mock.GpDispatch(self.tables)
            self.rootlog.level = logging.DEBUG
            table = get_table(gp, 'first', conversion=conversion)
            self.assertTrue(table != None)
            relevant = [i for i in self.handler.content if i.find("remain unconverted") != -1]
            self.assertEquals([], relevant)
            self.rootlog.level = self.orig_rootlog_level

        def test03(self):
            "get_table - all columns are converted, no warnings."

            conversion = {'col1': 'ABC',
                          'col2': 'due',
                          'col3': 'tre',
                          'col4': 'ctr',
                          'id': 'PK',
                          }
            self.handler.flush()
            gp = mock.GpDispatch(self.tables)
            self.rootlog.level = logging.DEBUG
            table = get_table(gp, 'first', conversion=conversion)
            self.assertTrue(table != None)
            relevant = [i for i in self.handler.content if i.find("remain unconverted") != -1]
            self.assertEquals([], relevant)
            self.rootlog.level = self.orig_rootlog_level

        def test10(self):
            "get_table - don't warn about unconverted columns if no conversion is given"

            self.rootlog.level = self.orig_rootlog_level
            self.handler.flush()
            gp = mock.GpDispatch(self.tables)
            table = get_table(gp, 'first')
            self.assertTrue(table != None)
            relevant = [i for i in self.handler.content if i.find("remain unconverted") != -1]
            self.assertEquals([], relevant)

    class GetTableDefinition(unittest.TestCase):
        tables = [{'pk': '1', 'abc':1, 'due':2, },
                  {'pk': '2', 'abc':4, 'due':3, },
                  {'pk': '3', 'abc':4, 'due':3, },
                  ]

        def test00(self):
            "get_table_def - checking initial implementation."

            gp = mock.GpDispatch(self.tables)
            types = get_table_def(gp, 'some_table_name')
            self.assertEqual(types, {'pk': '', 'abc': '', 'due': ''})

    class ValidFileName(unittest.TestCase):

        def test00(self):
            "validfilename - leaves alphanumeric in peace"

            import random
            for i in range(50):
                key = ''.join([chr(random.randrange(65, 91)) for i in range(25)])
                self.assertEqual(key, validfilename(key))
            for i in range(50):
                key = ''.join([chr(random.randrange(97, 123)) for i in range(25)])
                self.assertEqual(key, validfilename(key))
            for i in range(50):
                key = 'a' + ''.join([chr(random.randrange(48, 58)) for i in range(25)])
                self.assertEqual(key, validfilename(key))
            for i in range(50):
                key = ''.join([chr(random.randrange(97, 123)) for i in range(25)])
                self.assertEqual(key[:20], validfilename(key, maxlen=20))

        def test01(self):
            "validfilename - removes symbols as of ticket 703"

            s = "spaties of !@#$%^&*()-{}[]:\";'>?./,<123"
            v = "spatiesof123"
            self.assertEqual(v, validfilename(s))

        def test02(self):
            "validfilename - removes leading numbers"

            s = "123spaties of !@#$%^&*()-{}[]:\";'>?./,<"
            v = "spatiesof"
            self.assertEqual(v, validfilename(s))

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(IteratorTest))
    suite.addTest(unittest.makeSuite(DictJoinTest))
    suite.addTest(unittest.makeSuite(GetTableTest))
    suite.addTest(unittest.makeSuite(NotAValueTest))
    suite.addTest(unittest.makeSuite(DictionaryReversalTest))
    suite.addTest(unittest.makeSuite(GpLoggingHandler))
    suite.addTest(unittest.makeSuite(AddingObjectsToATable))
    suite.addTest(unittest.makeSuite(RecognizingNullValues))
    suite.addTest(unittest.makeSuite(RangeChecking))
    suite.addTest(unittest.makeSuite(NamedInConversion))
    suite.addTest(unittest.makeSuite(ShortenObjectName))
    suite.addTest(unittest.makeSuite(GetTableAndJoinOnPrimaryKey))
    ## suite.addTest(unittest.makeSuite(GetTableWarnsAboutUnconvertedColumns))
    suite.addTest(unittest.makeSuite(GetTableDefinition))
    suite.addTest(unittest.makeSuite(ValidFileName))
    return suite


if __name__ == '__main__':
    # perform some unit tests...

    try:
        from nens import mock
        mock.lint(__file__)
    except NameError:
        print "not linting because __file__ is not defined."

    import sys
    print "testing with python %s" % sys.version
    unittest.TextTestRunner(verbosity=2).run(testsuite())
