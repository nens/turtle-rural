Changelog of py-nens
====================


1.4 (2011-06-09)
----------------

- Nothing changed yet.


1.3 (2011-05-30)
----------------

- Nothing changed yet.


1.2 (2011-05-12)
----------------

- Fixed output of asc grids with a custom nodata_value setting.


1.1 (2011-03-30)
----------------

- Started changelog. 1.1 is the first release of the python nens library as a
  regular python package.
