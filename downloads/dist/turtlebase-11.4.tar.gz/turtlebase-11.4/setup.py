from setuptools import setup


long_description = '\n\n'.join([open('README.txt').read(),
                                open('CHANGES.txt').read()])
install_requires = [
    # Note: not handled as regular install_requires to facilitate net-less
    # installs.
    'networkx < 1.3',
    'dbfpy',
    'mock',
    'nens',
    'shapely',
    'pyodbc',
    ]
tests_require = [
    ]


setup(name='turtlebase',
      version='11.4',
      description="Base turtle library",
      long_description=long_description,
      classifiers=[],
      keywords='',
      author='Nelen & Schuurmans',
      author_email='reinout.vanrees@nelen-schuurmans.nl',
      url='',
      license='GPL',
      packages=['turtlebase'],
      include_package_data=True,
      zip_safe=False,
      install_requires=install_requires,
      tests_require=tests_require,
      extras_require={'test': tests_require},
      entry_points={
          'console_scripts': [
              'save_and_show_urban_blockschema = turtlebase.blockschema:save_and_show_urban_blockschema_main',
              'save_urban_blockschema_picture_and_data = turtlebase.blockschema:save_urban_blockschema_picture_and_data_main',
              ]},
      )
