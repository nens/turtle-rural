#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the nens library.
#
# the nens library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# the nens library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2008, 2009 Mario Frasca
#*
#***********************************************************************
#* Library    : defines grids
#*
#* Project    : various
#*
#* $Id: asc.py 19694 2011-04-01 08:22:52Z reinout.vanrees $
#*
#* initial programmer :  Mario Frasca
#* initial date       :  2008-07-30
#**********************************************************************

__revision__ = "$Rev: 19694 $"[6:-2]

import logging
log = logging.getLogger('nens.asc')

import types
import numpy

from nens import mock

gdal = None
try:
    from osgeo import gdal
except ImportError:
    pass


def name_to_location_name(name):
    if isinstance(name, types.ListType):
        name = '/'.join(name)
    name = name.replace('\\', '/')
    location = 'grid/'
    if name.find('/') != -1:
        parts = name.split('/')
        location = '/'.join(parts[:-1]) + '/'
        name = parts[-1]
    if location == '/':
        location = ''
    return location, name


def valid_float(v, nodata_value=None):
    """v or None

    >>> valid_float(0)
    0.0
    >>> print valid_float(12.3)
    12.3
    >>> print valid_float('4.32')
    4.32
    >>> print valid_float('')
    None
    >>> print valid_float('4.32', 4.32)
    4.32
    >>> print valid_float(-1000, -999)
    -999
    """

    try:
        v = float(v)
    except AttributeError:
        # in case the value was masked
        return nodata_value
    except ValueError:
        # the received string is invalid
        return nodata_value
    if v <= -999:
        return nodata_value
    if v == nodata_value:
        return nodata_value
    return v


def formatfloat(value, digits=3, nodata_value=-999):
    """same as %f, but avoids trailing zeroes

    >>> formatfloat(0)
    '0'
    >>> formatfloat(100)
    '100'
    >>> formatfloat(1.1)
    '1.1'
    >>> formatfloat(12.0004)
    '12'
    >>> formatfloat(12.0004, 4)
    '12.0004'
    >>> formatfloat(12.0004, 5)
    '12.0004'
    >>> formatfloat(numpy.ma.masked)
    '-999'
    >>> formatfloat(numpy.nan)
    '-999'
    """

    try:
        if value != value:
            # nan
            value = nodata_value
    except AttributeError:
        # masked
        value = nodata_value
    result = "%0.8f" % round(value, digits)
    trim = 0
    while result[-trim - 1] == '0':
        trim += 1
    if trim:
        if result[-trim - 1] == '.':
            trim += 1
        result = result[:-trim]
    return result


import re
import os
import os.path


class AscGrid:

    whitespace = re.compile(r'[ \t]+')

    @classmethod
    def apply(cls, f, *grids):
        o = grids[0]
        ncols, nrows = o.ncols, o.nrows
        result = AscGrid(o.ncols, o.nrows, o.xllcorner, o.yllcorner, o.cellsize, nodata_value=o.nodata_value)
        result.values = f(*[g.values for g in grids])
        return result

    @classmethod
    def firstTimestampWithValue(cls, data, threshold=0.0, default_grid=None):
        """reads a .inc file and returns two AscGrid objects

        pixels in the first returned object hold the timestamp of the
        grid in the timestamped sequence of grids where the pixel
        reaches or exceeds the threshold

        pixels in the second returned object hold the first exceeding
        value
        """

        objects = cls.listFromStream(data, threshold=threshold, default_grid=default_grid)

        template, objects = objects[0], objects[1:]
        result_0 = template.copy()
        result_1 = template.copy()

        for timestamp, values_indexes in objects:
            for value, indexes in values_indexes.items():
                for col, row in indexes:
                    result_0[col, row] = timestamp
                    result_1[col, row] = value

        return result_0, result_1

    @classmethod
    def firstTimestamp(cls, data, default_value=None, default_grid=None,
                       threshold=True):
        """reads .inc file and returns list of grids of timestamps.

        'data' is a .inc file, defining timestamped grids, values in
        the grid are from the classes listed in the header of 'data'.

        firstTimestamp examines the list of timestamped grids
        represented by 'data' and returns a list containing one grid
        per class value.  each pixel of the grid associated to a class
        contains the first timestamp for which that pixel assumes the
        value of that class.  if a class value is never assumed at a
        pixel, in the corresponding grid the pixel contains a None.
        """

        objects = cls.listFromStream(data, default_value=default_value, default_grid=default_grid,
                                     threshold=threshold)

        template, objects = objects[0], objects[1:]
        result = {}

        for timestamp, values_indexes in objects:
            for value, indexes in values_indexes.items():
                for col, row in indexes:
                    if value not in result:
                        result[value] = template.copy()
                    result[value][col, row] = timestamp

        return sorted(result.items())

    @classmethod
    def maxIncrementsFromStream(cls, data, default_value=None, default_grid=None, end_in_constant=False, oneperhour=False, pertimeunit=False):
        """reads a .inc file and produces one AscGrid object.

        pixel per pixel, the returned object contains the maximum
        increment for that pixel on all subsequent AscGrids
        represented by the .inc file.
        """

        objects = cls.listFromStream(data, default_value=default_value, default_grid=default_grid, oneperhour=oneperhour)
        if end_in_constant:
            objects.append(objects[-1])
        o = objects[0][1]

        result = AscGrid(o.ncols, o.nrows, o.xllcorner, o.yllcorner, o.cellsize, nodata_value=o.nodata_value, default_value=default_value)
        for (time_im1, obj_im1), (time_i, obj_i) in zip(objects, objects[1:]):
            for row in range(1, o.nrows + 1):
                for col in range(1, o.ncols + 1):
                    previous, current = obj_im1[col, row], obj_i[col, row]
                    if current is None:
                        continue
                    if previous is None:
                        previous = 0.0
                    if result[col, row] is None or (current - previous > result[col, row]):
                        difference = float(current - previous)
                        if pertimeunit:
                            difference /= time_i - time_im1
                        result[col, row] = difference
        return result

    @classmethod
    def listFromStream(cls, data, output=None, namepattern=None,
                       oneperhour=False, default_value=None, just_count=False,
                       default_grid=None, threshold=None):
        """reads a .inc file and produces a list of pairs (timestamp, AscGrid object).

        this is the list version of xlistFromStream and relies on
        xlistFromStream to do its work.

        listFromStream accepts the same parameters as xlistFromStream,
        all with the same meanings except 'just_count'.  in addition,
        listFromStream accepts 'output' and 'namepattern'.

        if 'output' is specified, it must be a ZipFile object to which
        files will be saved.  'namepattern' is the name of the i-th
        file saved to output and may not be None.  In this case the
        function returns the estimated time_step and the amount of
        files written.

        if 'just_count' != False, the result is the length of the list
        generated.
        """

        generator = cls.xlistFromStream(data, oneperhour, default_value, just_count, default_grid, threshold=threshold)

        if just_count:
            return len([i for i in generator])

        if output is not None:
            time_step = last_timestamp = None
            written = 0
            for timestamp, item in generator:
                if time_step is None and last_timestamp is not None:
                    time_step = timestamp - last_timestamp
                last_timestamp = timestamp

                item.writeToStream(output, (namepattern or '%04d.asc') % written)
                written += 1

            return time_step, written

        return [i for i in generator]

    @classmethod
    def xlistFromStream(cls, data, oneperhour=False, default_value=None,
                        just_count=False, default_grid=None, threshold=None):
        """reads a .inc file and produces a generator of timestamped objects.

        if 'just_count' is False, each generated element is a pair
        where the first element is the hour of the file and the second
        element is the AscGrid object.

        if 'just_count' is not False, the timestamped objects are all
        the default_value, unmodified.

        if 'threshold' is not None, the first element of the list is
        not a pair but a single AscGrid matching the input data shape
        and the remainder of the returned generator holds
        dictionaries, described differently depending on the type of
        'threshold':

        if 'threshold' is a number, the generated dictionaries
        associate a value above the threshold to the pixels that
        exceed the threshold for that timestamp.  pixel coordinates
        appear only the first time they exceed the threshold.

        if 'threshold' is a boolean, the generated dictionaries
        associate class indexes to the list of coordinates of all
        pixels that take on the value from that class.  if 'threshold'
        is True, pixel coordinates appear only the first time they
        take on each class value.
        """

        import re
        splitter = re.compile(r'[^0-9\.\-]+')

        if threshold is not None and just_count:
            raise RuntimeError("can't just_count and use a threshold at the same time")

        def number(s):
            try:
                return int(s)
            except ValueError:
                try:
                    return float(s)
                except ValueError:
                    return None

        def get_number_parts(data, guard=None):
            i = data.readline().strip()
            if guard and i.startswith(guard):
                raise StopIteration()
            groups = splitter.split(i.strip())
            return [number(a) for a in groups]

        if isinstance(data, types.StringTypes):
            data = file(data)

        line = ''
        while not line.startswith("MAIN DIMENSIONS"):
            line = data.readline().strip()
            if line.lower().startswith('nodata_value'):
                # we really got a single grid
                if just_count:
                    obj = None
                else:
                    data.seek(0)
                    obj = AscGrid(data)
                log.debug("yielding object for fictive timestamp 0")
                yield (0, obj)
                raise StopIteration
        ncols, nrows = get_number_parts(data)
        if default_grid is not None:
            if ncols is None:
                ncols = default_grid.ncols
            if nrows is None:
                nrows = default_grid.nrows

        while not line.startswith("GRID"):
            line = data.readline().strip()
        cellfields = get_number_parts(data)
        try:
            # it usually is a .inc file
            xcellsize, ycellsize, xllcorner, yllcorner = cellfields
            start_of_grid = re.compile(r'^[ ]*-?[0-9]*\.[0-9]+ +[0-9]+ +[0-9]+ +[0-9]+ *$')
        except ValueError:
            # .fls files have a different structure
            cellsize, xllcorner, yllcorner = cellfields
            ycellsize = xcellsize = cellsize
            start_of_grid = re.compile(r'^[ ]*-?[0-9]*\.[0-9]+ +[0-9]+ +[0-9]+ *$')

        if xcellsize != ycellsize:
            raise ValueError("AscGrid can't cope with rectangular cells")

        xllcorner -= xcellsize / 2
        yllcorner -= ycellsize / 2
        while not line.startswith("CLASSES OF INCREMENTAL FILE"):
            line = data.readline().strip()

        classes = []
        while True:
            try:
                class_def = get_number_parts(data, "ENDCLASSES")
                classes.append(class_def)
            except StopIteration:
                break

        obj = default_value
        if threshold is not None:
            assigned = set()
            yield AscGrid(ncols, nrows, xllcorner, yllcorner, xcellsize, -999, default_value=None)
            obj = {}
        obj_is_to_yield = False
        yielded_hour = None
        hour = None

        while True:
            line = data.readline().strip()
            if not line:
                if obj_is_to_yield:
                    log.debug("yielding object for timestamp %s" % hour)
                    yield (hour, obj)
                raise StopIteration
            if start_of_grid.match(line):
                if obj_is_to_yield:
                    log.debug("yielding object for timestamp %s" % hour)
                    if threshold is None or obj != {}:
                        yield (hour, obj)
                    yielded_hour = int(hour)
                hour, _, class_column = splitter.split(line.strip())[:3]
                hour = float(hour)
                class_column = int(class_column)
                obj_is_to_yield = (not oneperhour or yielded_hour != int(hour))
                if threshold is not None:
                    obj = {}
                elif not just_count:
                    obj = AscGrid(ncols, nrows, xllcorner, yllcorner, xcellsize,
                                  nodata_value=-999, default_value=obj)
                continue
            if not just_count:
                groups = splitter.split(line.strip())
                col, row, class_no = [number(a) for a in groups]
                if threshold is not None:
                    if class_no == 0:
                        value = 0.0
                    else:
                        value = classes[class_no - 1][class_column - 1]
                    if (value >= threshold > 0 or value > threshold >= 0) or isinstance(threshold, bool):
                        if isinstance(threshold, bool):
                            check = (class_no, col, row)
                        else:
                            check = (col, row)
                        if check not in assigned:
                            if threshold is not False:
                                assigned.add(check)
                            obj.setdefault(value, [])
                            obj[value].append((col, (nrows - row + 1)))
                elif class_no is not 0:
                    obj[col, (nrows - row + 1)] = classes[class_no - 1][class_column - 1]
                else:
                    obj[col, (nrows - row + 1)] = 0.0

    def copy(self):
        """returns a new object equal to self"""

        return AscGrid(self.ncols, self.nrows, self.xllcorner, self.yllcorner,
                       self.cellsize, nodata_value=self.nodata_value, default_value=None)

    def __init__(self, *args, **kwargs):
        if (1 <= len(args) <= 2 and kwargs == {}) or 'data' in kwargs.keys():
            self._init_from_data(*args, **kwargs)
        else:
            self._init_from_scratch(*args, **kwargs)
        self.images = {}

    def _init_from_data(self, data, name=None, cellsize=None, xllcorner=None, yllcorner=None, nodata_value=-999.0):
        self.location = self.srcname = ''
        self.source = None
        read_params = []
        if gdal and isinstance(data, gdal.Dataset):
            import struct
            geotransform = data.GetGeoTransform()
            self.nrows = data.RasterYSize
            self.ncols = data.RasterXSize
            self.xllcorner = geotransform[0]
            self.yllcorner = geotransform[3] - geotransform[1] * self.nrows
            self.cellsize = geotransform[1]
            self.nodata_value = nodata_value
            description = data.GetDescription()
            self.source = description + '.asc'
            self.location = os.path.dirname(description)
            self.srcname = os.path.basename(description)

            band = data.GetRasterBand(1)
            dataType = band.DataType
            unpacking_types = [(None, None),
                               ('c', numpy.ubyte),
                               ('H', numpy.uint16),
                               ('h', numpy.int16),
                               ('I', numpy.uint32),
                               ('i', numpy.int32),
                               ('f', numpy.float32),
                               ('d', numpy.float64)]
            unpack_char, numpy_type = unpacking_types[dataType]
            content = numpy.ndarray((band.YSize, band.XSize), dtype=numpy_type)
            content[:] = 0
            for y in range(band.YSize):
                scanline = band.ReadRaster(0, y, band.XSize, 1, band.XSize, 1, dataType)
                tuple_of_values = struct.unpack(unpack_char * band.XSize, scanline)
                content[y, :] = tuple_of_values
            self.values = numpy.ma.masked_values(content, band.GetNoDataValue())

            ## DONE
            return

        elif isinstance(data, numpy.ndarray):
            log.debug("initializing AscGrid from numpy.ndarray" % data)
            if xllcorner is None or yllcorner is None or cellsize is None:
                raise RuntimeError("initialization from numpy.ndarray needs metadata.")
            self.xllcorner = xllcorner
            self.yllcorner = yllcorner
            self.cellsize = cellsize
            self.nodata_value = nodata_value
            self.location = 'grid/'
            self.srcname = ''

            self.values = data.copy
            self.nrows, self.ncols = data.shape

            ## DONE
            return

        elif isinstance(data, types.StringTypes):
            log.debug("initializing AscGrid from '%s'" % data)
            self.location, self.srcname = name_to_location_name(data)
            data = file(self.location + self.srcname)
        elif name is not None:
            log.debug("initializing AscGrid from zipfile")
            read_params = [name]
        else:
            log.debug("initializing AscGrid from data stream")

        ## if we got here: data is more or less a stream
        data = data.read(*read_params)
        data = [i.strip() for i in data.split('\n') if not i.strip().startswith("/*")]

        header_len = 0
        for header_line in data:
            fields = self.whitespace.split(header_line)
            if len(fields) > 2:
                break
            self.__dict__[fields[0].lower()] = float(fields[1])
            header_len += 1

        self.nrows = int(self.nrows)
        self.ncols = int(self.ncols)

        content = numpy.zeros((self.nrows, self.ncols))
        for rowno, line in enumerate(data[header_len:]):
            values = [valid_float(i, self.nodata_value) for i in self.whitespace.split(line) if i]
            if values:
                content[rowno, :] = values
        self.values = numpy.ma.masked_values(content, self.nodata_value)

    def _init_from_scratch(self, ncols, nrows, xllcorner, yllcorner,
                            cellsize, nodata_value, default_value=0.0):
        log.debug("initializing AscGrid from parameters")
        self.ncols = int(ncols)
        self.nrows = int(nrows)
        self.xllcorner = xllcorner
        self.yllcorner = yllcorner
        self.cellsize = cellsize
        self.nodata_value = nodata_value
        self.location = 'grid/'
        self.srcname = ''
        content = numpy.zeros((self.nrows, self.ncols))
        if default_value == nodata_value:
            default_value = None
        for row in range(nrows):
            if isinstance(default_value, AscGrid):
                values = default_value.values.filled(nodata_value)[row, :]
            else:
                values = default_value

            content[row, :] = values
        self.values = numpy.ma.masked_values(content, nodata_value)

    def _pair_to_coords(self, pair):
        try:
            col, row = pair
            get_by_rowcol = (1 <= col <= self.ncols) and (1 <= row <= self.nrows)
        except (TypeError, AttributeError):
            pair = pair.x, pair.y
            get_by_rowcol = False
        if get_by_rowcol:
            col -= 1
            row -= 1
        else:
            x, y = pair
            col = int((x - self.xllcorner) / self.cellsize)
            row = int(self.nrows - int(y - self.yllcorner) / self.cellsize)
        return col, row

    def __getitem__(self, pair, value=None):
        col, row = self._pair_to_coords(pair)
        try:
            if col < 0 or row < 0:
                return False
            result = self.values[row, col]
            try:
                if result == self.nodata_value:
                    return None
                if result != result:
                    return None
            except:
                # checking fails if element is masked
                return None
            return result
        except IndexError:
            return False

    def __setitem__(self, pair, value):
        col, row = self._pair_to_coords(pair)
        if value == self.nodata_value:
            value = None
        self.values[row, col] = value

    def scoreatpercentile(self, per):
        try:
            from scipy.stats import scoreatpercentile
        except ImportError:
            log.error("can't import scoreatpercentile from scipy.stats")
            return None
        return scoreatpercentile(self.values.compressed(), per)

    def save(self, destdir=None):
        if destdir is None:
            dest = self.source
        else:
            destdir = destdir.replace('\\', '/')
            if not destdir.endswith('/'):
                destdir += '/'
            log.debug("writing AscGrid to '%s' destination directory" % destdir)
            location, name = name_to_location_name(self.srcname)
            dest = destdir + name
        output = file(dest, "w")
        self.writeToStream(output)
        output.close()

    def headerLines(self):
        """the list of lines for the .asc header

        >>> obj = AscGrid(5, 5, xllcorner=15.0, yllcorner=12.5, cellsize=0.5, nodata_value=-999)
        >>> obj.headerLines()
        ['nCols        5', 'nRows        5', 'xllCorner    15', 'yllCorner    12.5', 'CellSize     0.5', 'nodata_value -999']
        """

        result = []
        for fieldname in ['nCols', 'nRows']:
            line = ("%-13s" % fieldname)
            line += "%i" % getattr(self, fieldname.lower())
            result.append(line)

        for fieldname in ['xllCorner', 'yllCorner', 'CellSize', 'nodata_value']:
            line = ("%-13s" % fieldname)
            line += formatfloat(getattr(self, fieldname.lower()),
                                nodata_value=self.nodata_value)
            result.append(line)

        return result

    def writeToStream(self, output, name=None):
        "writes self to a stream or a zipfile"

        log.debug("about to save self to %s(%s)" % (type(output), name))
        result = self.headerLines()
        for row in self.values.filled(self.nodata_value):
            stringvalues = [formatfloat(value, nodata_value=self.nodata_value)
                            for value in row]
            result.append(' ' + ' '.join(stringvalues))

        result.append('')
        result = '\n'.join(result)

        output_methods = output.__class__.__dict__
        try:
            temp = result.replace('\n', '\r\n')
            if name is None:
                location, name = self.location, self.srcname
            else:
                location, name = name_to_location_name(name)
                if not name:
                    name = self.srcname
            output.writestr(str(location + name), temp)
            log.info("wrote item '%s' to zipfile" % (location + name))
            return
        except AttributeError:
            pass

        try:
            output.write(result)
            log.debug("writing item file")
            return
        except AttributeError:
            pass

        raise ValueError("don't know how to write to a %(__name__)s" % output_methods)

    def get_col_row(self, pair):
        col, row = self._pair_to_coords(pair)
        return (col + 1, row + 1)
        pass

    def point(self, pair, percent=(0.5, 0.5)):
        col, row = self._pair_to_coords(pair)
        if not (0 <= row < self.nrows) or not (0 <= col <= self.ncols):
            raise ValueError("point falls outside of the grid")
        x = self.xllcorner + self.cellsize * (col + percent[0])
        y = self.yllcorner + self.cellsize * ((self.nrows - row - 1) + percent[1])
        return (x, y)

    def asImage(self, colorMapping, bits=24):
        """calculates an image that represents the current object given the
        colorMapping.

        colorMapping: anything with method getColor: float->(r, g, b).
        bits: either 8 (palette, black for transparency) or 24 (RGB+alpha).
        """

        from PIL import Image
        if bits == 8:
            palette = [(0, 0, 0)]
            for boundary, color in colorMapping.values:
                palette.append(color)
            result = Image.new(size=(self.ncols, self.nrows), mode='P', color=0)
            p = []
            for r, g, b in palette:
                p.extend([r, g, b])
            result.putpalette(p)
        elif bits == 24:
            result = Image.new(size=(self.ncols, self.nrows), mode='RGBA')
        else:
            raise ValueError("bits must be either 8 or 24")

        if (bits) not in self.images:
            data = []
            for row in self.values.filled(0):
                for cell in row:
                    color = colorMapping.getColor(cell)
                    if bits == 8:
                        color = palette.index(color)
                    else:
                        if color == (0, 0, 0):
                            color = (0, 0, 0, 0)
                    data.append(color)

            self.images[bits] = data
        result.putdata(self.images[bits])
        return result


class ColorMapping:

    def __init__(self, data_stream):
        """create a ColorMapping object

        reads the color mapping from the data_stream.
        """

        header = data_stream.readline()
        fields = [i.lower().strip() for i in header.split(',')]
        if fields != ['leftbound', 'colour']:
            raise Exception("unexpected mapping file format")

        self.values = []
        while True:
            line = data_stream.readline()
            if not line:
                break
            fields = [i.lower().strip() for i in line.split(',')]
            if not fields:
                continue
            bound = float(fields[0])
            color = [int(fields[1][i * 2:(i + 1) * 2], 16) for i in range(3)]
            self.values.append((bound, tuple(color)))

        self.palette = None

    def getColor(self, value):
        """returns color associated to value

        either black or the color associated to the greatest value
        that is smaller than the given one"""

        if value is None:
            return (0, 0, 0)
        try:
            found = max([(v, c) for (v, c) in self.values if v < value])
            return found[1]
        except ValueError:
            return (0, 0, 0)

    def getPaletteIndex(self, value):
        "returns the index of the color associated to value"

        # make sure that palette has been calculated
        self.asPalette()

        return None

    def asPalette(self):
        "returns the palette associated to the color mapping"

        if self.palette is None:
            pass

        return self.palette


def testsuite():
    """Return test suite"""
    import sys
    print "testing with python %s" % sys.version

    import unittest

    class GridFromFile(unittest.TestCase):
        data = """\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
"""
        outstr0 = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 0 0 0 0 0 0
 0 0 0 0 0 0
 0 0 0 0 0 0
 0 0 0 0 0 0
"""
        outstr1 = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 0.1 0.1 0.1 0.1 0.1 0.1
 0.1 0.1 0.1 0.1 0.1 0.1
 0.1 0.1 0.1 0.1 0.1 0.1
 0.1 0.1 0.1 0.1 0.1 0.1
"""

        def test00(self):
            "create object from scratch"

            obj = AscGrid(ncols=6, nrows=4, xllcorner=135000, yllcorner=455000, cellsize=100, nodata_value=-999, default_value=0.0)
            output = mock.Stream()
            obj.writeToStream(output)
            self.assertEqual(''.join(output.content), self.outstr0)

        def test01(self):
            "create object from scratch with defaults"

            obj = AscGrid(ncols=6, nrows=4, xllcorner=135000, yllcorner=455000, cellsize=100, nodata_value=-999, default_value=0.1)
            obj = AscGrid(ncols=6, nrows=4, xllcorner=135000, yllcorner=455000, cellsize=100, nodata_value=-999, default_value=obj)
            output = mock.Stream()
            obj.writeToStream(output)
            self.assertEqual(''.join(output.content), self.outstr1)

        def test1_reading_from_file(self):
            "metadata about the grid"
            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj.ncols, 5)
            self.assertEqual(obj.nrows, 5)
            self.assertEqual(obj.xllcorner, 135000)
            self.assertEqual(obj.yllcorner, 455000)
            self.assertEqual(obj.cellsize, 100)
            self.assertEqual(obj.nodata_value, -999)

        def test2_reading_from_file(self):
            "matrix of digital elevation model"
            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(len(obj.values), obj.nrows)
            self.assertEqual([len(item) for item in obj.values], [obj.ncols] * int(obj.nrows))

        def test30_reading_from_file(self):
            "matrix of digital elevation model - with comments line"
            obj = AscGrid(mock.Stream("/* qualcuno vuole dirti qualcosa che non ti interessa\n" + self.data))
            self.assertEqual(len(obj.values), obj.nrows)
            self.assertEqual([len(item) for item in obj.values], [obj.ncols] * int(obj.nrows))

    class GridRecognizesObjects(unittest.TestCase):
        data = """\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
"""

        def test2_reading(self):
            "grid elevation model, valid pixel by row/col"

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[2, 1], -0.2)
            self.assertEqual(obj[3, 1], 0.0)
            self.assertEqual(obj[5, 1], 3.05)
            self.assertEqual(obj[1, 4], 0)

        def test3_pixel(self):
            "grid elevation model, non valid pixel inside of the grid."

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[1, 1], None)
            self.assertEqual(obj[4, 1], None)
            self.assertEqual(obj[1, 1], None)
            self.assertEqual(obj[1, 2], None)
            self.assertEqual(obj[1, 3], None)
            self.assertEqual(obj[1, 5], None)

        def test40_pixel_by_geocoords(self):
            "grid elevation model, (non)valid pixel by geographical coordinates"

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[135054, 455009], None)
            self.assertEqual(obj[135254, 455209], 0.0)
            self.assertEqual(obj[135154, 455049], 1.1)
            self.assertEqual(obj[135254, 455089], 1.4)

        def test45_pixel_by_geocoords(self):
            "grid elevation model, (non)valid pixel by Point"

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[mock.Point(135054, 455009)], None)
            self.assertEqual(obj[mock.Point(135254, 455209)], 0.0)
            self.assertEqual(obj[mock.Point(135154, 455049)], 1.1)
            self.assertEqual(obj[mock.Point(135254, 455089)], 1.4)

        def test50_pixel(self):
            "grid elevation model, pixel outside of the grid by geographical coordinates."

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[105054, 455009], False)
            self.assertEqual(obj[235054, 455009], False)
            self.assertEqual(obj[135054, 355009], False)
            self.assertEqual(obj[135000, 455600], False)
            self.assertEqual(obj[134900, 455000], False)

        def test55_pixel(self):
            "grid elevation model, pixel outside of the grid by Point."

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[mock.Point(105054, 455009)], False)
            self.assertEqual(obj[mock.Point(235054, 455009)], False)
            self.assertEqual(obj[mock.Point(135054, 355009)], False)
            self.assertEqual(obj[mock.Point(135000, 455600)], False)
            self.assertEqual(obj[mock.Point(134900, 455000)], False)

        def test6_pixel(self):
            "grid elevation model, pixel outside of the grid by row/col."

            obj = AscGrid(mock.Stream(self.data))
            self.assertEqual(obj[3, 20], False)
            self.assertEqual(obj[30, 5], False)

        def test70_reading_from_file(self):
            "reading data from inconsistent file - #205"
            input1 = """\
nCols        5
nRows        3
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999.999 -0.2 0 -9999 3.05
 -99 -9 0 0.5 1.2
 -9999.99 0 0 0 -99999
"""
            obj = AscGrid(mock.Stream(input1))
            self.assertEqual(obj[1, 1], None)
            self.assertEqual(obj[1, 2], -99)
            self.assertEqual(obj[2, 2], -9)
            self.assertEqual(obj[1, 3], None)
            self.assertEqual(obj[4, 1], None)
            self.assertEqual(obj[5, 1], 3.05)
            self.assertEqual(obj[5, 3], None)

    class GridModifyingContent(unittest.TestCase):
        data = mock.Stream("""\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
""")

        def test1_setPixelValue(self):
            "set pixel value, to valid pixel by row/col"

            obj = AscGrid(self.data)
            self.assertEqual(obj[2, 1], -0.2)
            obj[2, 1] = -0.1
            self.assertEqual(obj[2, 1], -0.1)

        def test2_setPixelValue(self):
            "setting pixel out of grid raises IndexError - geo"

            obj = AscGrid(self.data)
            self.assertEqual(obj[100000, 455000], False)
            self.assertRaises(IndexError, obj.__setitem__, (100000, 455000), 1)

        def test3_setPixelValue(self):
            "setting pixel out of grid raises IndexError - row/col"

            obj = AscGrid(self.data)
            self.assertEqual(obj[3, 20], False)
            self.assertRaises(IndexError, obj.__setitem__, (3, 20), 1)

        def test31_setPixelValue(self):
            "setting pixel out of grid raises IndexError - row/col"

            obj = AscGrid(self.data)
            self.assertEqual(obj[3, 0], False)
            self.assertRaises(IndexError, obj.__setitem__, (3, 0), 1)

        def test5_setPixelValue(self):
            "setting valid pixel as invalid alters grid shape"

            obj = AscGrid(self.data)
            self.assertEqual(obj[2, 1], -0.2)
            obj[2, 1] = None
            self.assertEqual(obj[2, 1], None)

        def test6_setPixelValue(self):
            "setting invalid pixel as valid alters grid shape"

            obj = AscGrid(self.data)
            self.assertEqual(obj[1, 3], None)
            obj[1, 3] = 1
            self.assertEqual(obj[1, 3], 1)

    class GridWritingToStream(unittest.TestCase):
        data_str = """\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
"""
        output_str = """\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.1 0 -999 1.05
 -999 0 0 0.5 0.9
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
"""
        outputfloat_str = """\
nCols        5
nRows        5
xllCorner    135000.1
yllCorner    455000.01
CellSize     0.5
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
"""

        def test1_writeUnaltered(self):
            "writing to stream, unaltered"
            obj = AscGrid(mock.Stream(self.data_str))
            output = mock.Stream()
            obj.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_str)

        def test2_writeAltered(self):
            "writing to stream, after altering some values"
            obj = AscGrid(mock.Stream(self.data_str))
            obj[2, 1] = -0.1
            obj[5, 1] = 1.05
            obj[4, 2] = 0.5
            obj[5, 2] = 0.9
            output = mock.Stream()
            obj.writeToStream(output)
            self.assertEqual(''.join(output.content), self.output_str)

        def test3_writeAltered(self):
            "writing to stream, non integer grid"
            obj = AscGrid(mock.Stream(self.data_str))
            obj.xllcorner += 0.1
            obj.yllcorner += 0.01
            obj.cellsize = 0.5
            output = mock.Stream()
            obj.writeToStream(output)
            self.assertEqual(''.join(output.content), self.outputfloat_str)

        def test70writing(self):
            "writing to a zip archive gives CRLF line terminators"
            obj = AscGrid(mock.Stream(self.data_str))
            output = mock.ZipFile()
            obj.writeToStream(output, 'name.asc')
            self.assertEqual(''.join(output.content), self.data_str.replace('\n', '\r\n'))

        def test71writing(self):
            "writing to a zip archive goes per default into grid/ dir"
            obj = AscGrid(mock.Stream(self.data_str))
            output = mock.ZipFile()
            obj.writeToStream(output, 'name.asc')
            self.assertEqual(output.namelist(), ['grid/name.asc'])

        def test72writing(self):
            "writing to a zip archive explicitly to root dir"
            obj = AscGrid(mock.Stream(self.data_str))
            output = mock.ZipFile()
            obj.writeToStream(output, '/name.asc')
            self.assertEqual(output.namelist(), ['name.asc'])

        def test76writing(self):
            "writing to a zip archive with explicit location"
            obj = AscGrid(mock.Stream(self.data_str))
            output = mock.ZipFile()
            obj.writeToStream(output, 'grid/name.asc')
            self.assertEqual(output.namelist(), ['grid/name.asc'])

        def test78writing(self):
            "writing to a zip archive with explicit list location"
            obj = AscGrid(mock.Stream(self.data_str))
            output = mock.ZipFile()
            obj.writeToStream(output, ['0', '1', '2', 'name.asc'])
            self.assertEqual(output.namelist(), ['0/1/2/name.asc'])

    class CoordsConversion(unittest.TestCase):
        data = mock.Stream("""\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
""")

        def test1_getPixel(self):
            "get sobek coords of pixel containing a given point"

            obj = AscGrid(self.data)
            self.assertEqual(obj.get_col_row((135050, 455450)), (1, 1))
            self.assertEqual(obj.get_col_row((135178, 455089)), (2, 5))

        def test2_getPixel(self):
            "get geographical coords of middle point for pixel"

            obj = AscGrid(self.data)
            self.assertEqual(obj.point((1, 1)), (135050, 455450))
            self.assertEqual(obj.point((2, 5)), (135150, 455050))

        def test3_getPixel(self):
            "get geographical coords of point for pixel, in % from lower left"

            obj = AscGrid(self.data)
            self.assertEqual(obj.point((1, 1), (0.5, 0.5)), (135050, 455450))
            self.assertEqual(obj.point((2, 5), (0.78, 0.89)), (135178, 455089))

        def test4_getPixel(self):
            "get geographical coords of point in invalid pixel raises ValueError"

            obj = AscGrid(self.data)
            self.assertRaises(ValueError, obj.point, (100050, 455450))

        def test5_getPixel(self):
            "get geographical coords of point in invalid pixel raises ValueError"

            obj = AscGrid(self.data)
            self.assertRaises(ValueError, obj.point, (1, 45))

    class ListFromIncFile(unittest.TestCase):

        data = """\
INC1.0
DOMAIN                        NUMBER   ID
                                 1   '24                                      '
MAIN DIMENSIONS                MMAX  NMAX
                               6   4
GRID                           DX      DY      X0      Y0
                               100.00     100.00   135050.00  455050.00
domain                        END
START TIME T0: 1991.01.07 00:00:00
CLASSES OF INCREMENTAL FILE    Waterdepth(m) Velocity(m/s)  Waterlevel(m) U-velocity(m/s)  V-velocity(m/s)
                                   0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
ENDCLASSES
.000000 0 1 1
3 1 1
4 1 1
.500000 0 1 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1.000000 0 1 1
1 1 2
2 1 3
3 1 3
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
1.500000 0 1 1
5 2 2
6 2 1
5 3 2
6 3 1
5 4 1
2.010000 0 1 1
1 1 1
2 1 2
3 1 2
4 1 2
5 1 2
6 1 2
1 2 2
2 2 2
3 2 2
4 2 2
1 3 1
3 3 1
4 3 1
 2.500000 0 1 1
2 1 1
3 1 1
4 1 1
5 1 1
6 1 1
1 2 1
2 2 1
3 2 1
4 2 1
5 2 1
2 3 1
5 3 1
3 4 1
4 4 1
"""

        output = [(0, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 0.5 0.5 -999 -999
"""),
                  (0.5, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 0.5 0.5 0.5 -999
 -999 0.5 1 2 1 -999
"""),
                  (1, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 2 -999
 0.5 0.5 0.5 0.5 2 -999
 1 2 2 2 2 0.5
"""),
                  (1.5, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 0.5 -999
 -999 -999 -999 -999 1 0.5
 0.5 0.5 0.5 0.5 1 0.5
 1 2 2 2 2 0.5
"""),
                  (2.01, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 0.5 -999
 0.5 -999 0.5 0.5 1 0.5
 1 1 1 1 1 0.5
 0.5 1 1 1 1 1
"""),
                  (2.5, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 0.5 0.5 0.5 -999
 0.5 0.5 0.5 0.5 0.5 0.5
 0.5 0.5 0.5 0.5 0.5 0.5
 0.5 0.5 0.5 0.5 0.5 0.5
"""),
                  ]

        output_hour = [(0, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 0.5 0.5 -999 -999
"""),
                       (1, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 2 -999
 0.5 0.5 0.5 0.5 2 -999
 1 2 2 2 2 0.5
"""),
                       (2.01, """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 0.5 -999
 0.5 -999 0.5 0.5 1 0.5
 1 1 1 1 1 0.5
 0.5 1 1 1 1 1
"""),
                  ]

        input0 = """\
INC1.0
DOMAIN                        NUMBER   ID
                                 1   '24                                      '
MAIN DIMENSIONS                MMAX  NMAX
                               6   4
GRID                           DX      DY      X0      Y0
                               100.00     100.00   135050.00  455050.00
domain                        END
START TIME T0: 1991.01.07 00:00:00
CLASSES OF INCREMENTAL FILE    Waterdepth(m) Velocity(m/s)  Waterlevel(m) U-velocity(m/s)  V-velocity(m/s)
                                   0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
ENDCLASSES
.000000 0 1 1
3 1 1
4 1 1
3 2 0
.100000 0 1 1
3 1 0
"""

        output00 = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 0 -999 -999 -999
 -999 -999 0.5 0.5 -999 -999
"""
        output01 = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 0 -999 -999 -999
 -999 -999 0 0.5 -999 -999
"""

        def test10(self):
            "inc - shape of grid"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            for timestamp, item in asclist:
                self.assertEqual(item.ncols, 6)
            for timestamp, item in asclist:
                self.assertEqual(item.nrows, 4)

        def test12(self):
            "inc - counting list of AscGrid objects"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data, just_count=True)
            self.assertEqual(asclist, 6)

        def test13(self):
            "inc - counting list of AscGrid objects, one per hour"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data, oneperhour=True, just_count=True)
            self.assertEqual(asclist, 3)

        def test14(self):
            "inc - counting asc data, returning one"

            data = mock.Stream(self.output[0][1])
            asclist = AscGrid.listFromStream(data, just_count=True)
            self.assertEqual(asclist, 1)

        def test20(self):
            "inc - reading list of AscGrid objects"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            for i in range(6):
                output = mock.Stream()
                asclist[i][1].writeToStream(output)
                self.assertEqual((i, asclist[i][0]), (i, self.output[i][0]))
                self.assertEqual((i, ''.join(output.content)), (i, self.output[i][1]))

        def test21(self):
            "inc - reading list of AscGrid objects - class '0' means hard coded 0.000"

            data = mock.Stream(self.input0)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 2)
            output = mock.Stream()
            asclist[0][1].writeToStream(output)
            self.assertEqual(''.join(output.content), self.output00)
            output = mock.Stream()
            asclist[1][1].writeToStream(output)
            self.assertEqual(''.join(output.content), self.output01)

        def test23(self):
            "inc - reading list of AscGrid objects, DOS-separators"

            data = mock.Stream(self.data.replace('\n', '\r\n'))
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            for i in range(6):
                output = mock.Stream()
                asclist[i][1].writeToStream(output)
                self.assertEqual((i, asclist[i][0]), (i, self.output[i][0]))
                self.assertEqual((i, ''.join(output.content)), (i, self.output[i][1]))

        def test25(self):
            "inc - reading list of AscGrid objects to zipfile"

            data = mock.Stream(self.data)
            output = mock.ZipFile()
            step, asclist = AscGrid.listFromStream(data, output)
            self.assertEqual(asclist, 6)
            self.assertEqual('!!!'.join(output.content), '!!!'.join([i[1] for i in self.output]).replace('\n', '\r\n'))
            self.assertEqual(output.names[0], 'grid/0000.asc')
            self.assertEqual(output.names[5], 'grid/0005.asc')
            self.assertEqual(step, 0.5)

        def test26(self):
            "inc - reading list of AscGrid objects to zipfile, by name"

            data = mock.Stream(self.data)
            output = mock.ZipFile()
            step, asclist = AscGrid.listFromStream(data, output, "/tst%05d.asc")
            self.assertEqual(asclist, 6)
            self.assertEqual('!!!'.join(output.content), '!!!'.join([i[1] for i in self.output]).replace('\n', '\r\n'))
            self.assertEqual(output.names[0], 'tst00000.asc')
            self.assertEqual(output.names[5], 'tst00005.asc')

        def test30(self):
            "inc - reading list of AscGrid objects, one per hour"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data, oneperhour=True)
            self.assertEqual(len(asclist), 3)
            for i in range(3):
                output = mock.Stream()
                asclist[i][1].writeToStream(output)
                self.assertEqual((i, asclist[i][0]), (i, self.output_hour[i][0]))
                self.assertEqual((i, ''.join(output.content)), (i, self.output_hour[i][1]))

        def test40(self):
            "inc - accepting asc data, returning one AscGrid"

            data = mock.Stream(self.output[0][1])
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 1)
            output = mock.Stream()
            asclist[0][1].writeToStream(output)
            self.assertEqual(''.join(output.content), self.output[0][1])

        def test50(self):
            "inc - reading list of AscGrid objects, one per hour, using generator"

            data = mock.Stream(self.data)
            asclist = AscGrid.xlistFromStream(data, oneperhour=True)
            for i in range(3):
                output = mock.Stream()
                obj = asclist.next()
                obj[1].writeToStream(output)
                self.assertEqual((i, obj[0]), (i, self.output_hour[i][0]))
                self.assertEqual((i, ''.join(output.content)), (i, self.output_hour[i][1]))
            self.assertRaises(StopIteration, asclist.next)

        def test53(self):
            "inc - accepting asc data, returning one AscGrid, using generator"

            data = mock.Stream(self.output[0][1])
            asclist = AscGrid.xlistFromStream(data)
            output = mock.Stream()
            obj = asclist.next()
            obj[1].writeToStream(output)
            self.assertEqual(''.join(output.content), self.output[0][1])
            self.assertRaises(StopIteration, asclist.next)

        def test56(self):
            "inc - reading list of AscGrid objects, using generator"

            data = mock.Stream(self.data)
            asclist = AscGrid.xlistFromStream(data)
            for i in range(6):
                output = mock.Stream()
                obj = asclist.next()
                obj[1].writeToStream(output)
                self.assertEqual((i, obj[0]), (i, self.output[i][0]))
                self.assertEqual((i, ''.join(output.content)), (i, self.output[i][1]))
            self.assertRaises(StopIteration, asclist.next)

    class ListFromFLSIncFile(unittest.TestCase):
        data = """\
/* run: 38da1, created at: 18:33:11, 23- 1-2003, time =    78.00     DELFT-FLS version 2.55, 14-july-2001
MAIN DIMENSIONS                  MMAX    NMAX
                                6   4
GRID                           DX    X0       Y0
                                   100.00   135050.00  455050.00
CLASSES OF INCREMENTAL FILE    H       C       Z       U       V
                                  0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
ENDCLASSES
0.000 0 1
3 1 1
4 1 1
.500000 0 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1.000000 0 1
1 1 2
2 1 3
3 1 3
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
1.500000 0 1
5 2 2
6 2 1
5 3 2
6 3 1
5 4 1
2.000000 0 1
1 1 1
2 1 2
3 1 2
4 1 2
5 1 2
6 1 2
1 2 2
2 2 2
3 2 2
4 2 2
1 3 1
3 3 1
4 3 1
 2.500000 0 1
2 1 1
3 1 1
4 1 1
5 1 1
6 1 1
1 2 1
2 2 1
3 2 1
4 2 1
5 2 1
2 3 1
5 3 1
3 4 1
4 4 1
"""
        output = ["""\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 %(v)s %(v)s %(v)s %(v)s %(v)s %(v)s
 %(v)s %(v)s %(v)s %(v)s %(v)s %(v)s
 %(v)s %(v)s %(v)s %(v)s %(v)s %(v)s
 %(v)s %(v)s 0.5 0.5 %(v)s %(v)s
""",
                  """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 %(v)s %(v)s %(v)s %(v)s %(v)s %(v)s
 %(v)s %(v)s %(v)s %(v)s %(v)s %(v)s
 %(v)s %(v)s 0.5 0.5 0.5 %(v)s
 %(v)s 0.5 1 2 1 %(v)s
""",
                  """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 %(v)s %(v)s %(v)s %(v)s %(v)s %(v)s
 %(v)s %(v)s %(v)s %(v)s 2 %(v)s
 0.5 0.5 0.5 0.5 2 %(v)s
 1 2 2 2 2 0.5
""",
                  """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 %(v)s %(v)s %(v)s %(v)s 0.5 %(v)s
 %(v)s %(v)s %(v)s %(v)s 1 0.5
 0.5 0.5 0.5 0.5 1 0.5
 1 2 2 2 2 0.5
""",
                  """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 %(v)s %(v)s %(v)s %(v)s 0.5 %(v)s
 0.5 %(v)s 0.5 0.5 1 0.5
 1 1 1 1 1 0.5
 0.5 1 1 1 1 1
""",
                  """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 %(v)s %(v)s 0.5 0.5 0.5 %(v)s
 0.5 0.5 0.5 0.5 0.5 0.5
 0.5 0.5 0.5 0.5 0.5 0.5
 0.5 0.5 0.5 0.5 0.5 0.5
""",
                  ]

        def test400(self):
            "FLS inc - shape of grid"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            for timestamp, item in asclist:
                self.assertEqual(item.ncols, 6)
            for timestamp, item in asclist:
                self.assertEqual(item.nrows, 4)

        def test401(self):
            "FLS - counting list of AscGrid objects"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data, just_count=True)
            self.assertEqual(asclist, 6)

        def test410(self):
            "FLS - reading list of AscGrid objects"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            for i in range(6):
                output = mock.Stream()
                asclist[i][1].writeToStream(output)
                self.assertEqual(''.join(output.content), self.output[i] % {'v': -999})

        def test412(self):
            "FLS - reading list of AscGrid objects with default value"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data, default_value=-5)
            self.assertEqual(len(asclist), 6)
            for i in range(6):
                output = mock.Stream()
                asclist[i][1].writeToStream(output)
                self.assertEqual(''.join(output.content), self.output[i] % {'v': -5})

        def test42(self):
            "FLS - reading list of AscGrid objects to zipfile"

            data = mock.Stream(self.data)
            output = mock.ZipFile()
            step, asclist = AscGrid.listFromStream(data, output)
            self.assertEqual(asclist, 6)
            self.assertEqual('!!!'.join(output.content), '!!!'.join(self.output).replace('\n', '\r\n') % {'v': -999})
            self.assertEqual(output.names[0], 'grid/0000.asc')
            self.assertEqual(output.names[5], 'grid/0005.asc')
            self.assertEqual(step, 0.5)

        def test43(self):
            "FLS - reading list of AscGrid objects to zipfile, by name"

            data = mock.Stream(self.data)
            output = mock.ZipFile()
            step, asclist = AscGrid.listFromStream(data, output, "/tst%05d.asc")
            self.assertEqual(asclist, 6)
            self.assertEqual('!!!'.join(output.content), '!!!'.join(self.output).replace('\n', '\r\n') % {'v': -999})
            self.assertEqual(output.names[0], 'tst00000.asc')
            self.assertEqual(output.names[5], 'tst00005.asc')

    class TestColorMapping(unittest.TestCase):
        data = """\
leftbound,colour
0,FEE1E1
0.8,FE5956
0.9,FE4A47
2.3,860200
"""

        def test000_readingFromFile(self):
            "ColorMapping read from file"
            obj = ColorMapping(mock.Stream(self.data))
            self.assertEqual(len(obj.values), 4)
            self.assertEqual(obj.values[0], (0, (0xFE, 0xE1, 0xE1)))
            self.assertEqual(obj.values[-1], (2.3, (0x86, 0x02, 0x00)))

        def test100_getColorFromValue(self):
            "ColorMapping associates colour to a value - inside extremes"

            obj = ColorMapping(mock.Stream(self.data))
            self.assertEqual(obj.getColor(0.89), (0xfe, 0x59, 0x56))
            self.assertEqual(obj.getColor(0.91), (0xfe, 0x4a, 0x47))

        def test110_getColorFromValue(self):
            "ColorMapping associates colour to a value - left bounds go to previous color"

            obj = ColorMapping(mock.Stream(self.data))
            self.assertEqual(obj.getColor(0.8), (0xFE, 0xE1, 0xE1))
            self.assertEqual(obj.getColor(0.9), (0xFE, 0x59, 0x56))
            self.assertEqual(obj.getColor(2.3), (0xFE, 0x4A, 0x47))
            self.assertEqual(obj.getColor(0.0), (0x00, 0x00, 0x00))

        def test115_getColorFromValue(self):
            "ColorMapping associates colour to higher bound for all values above that"

            obj = ColorMapping(mock.Stream(self.data))
            self.assertEqual(obj.getColor(5), (0x86, 0x02, 0x00))
            self.assertEqual(obj.getColor(50), (0x86, 0x02, 0x00))
            self.assertEqual(obj.getColor(500), (0x86, 0x02, 0x00))

        def test120_getColorFromValue(self):
            "ColorMapping associates black to values less than lower bound"

            obj = ColorMapping(mock.Stream(self.data))
            self.assertEqual(obj.getColor(-49), (0x00, 0x00, 0x00))

        def test130_getColorFromValue(self):
            "ColorMapping associates black to None"

            obj = ColorMapping(mock.Stream(self.data))
            self.assertEqual(obj.getColor(None), (0x00, 0x00, 0x00))

        def test140_cantInitializeFromFileName(self):
            "ColorMapping cannot be initialized from a file name (AttributeError)"

            self.assertRaises(AttributeError, ColorMapping, "some_file_name")

    class ImageConversion(unittest.TestCase):
        data = """\
/* run: 38da1, created at: 18:33:11, 23- 1-2003, time =    78.00     DELFT-FLS version 2.55, 14-july-2001
MAIN DIMENSIONS                  MMAX    NMAX
                                6   4
GRID                           DX    X0       Y0
                                   100.00   135050.00  455050.00
CLASSES OF INCREMENTAL FILE    H       C       Z       U       V
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
                                   3.000     -999     -999     -999     -999
                                   4.000     -999     -999     -999     -999
ENDCLASSES
0.000 0 1
3 3 0
3 1 1
4 1 1
.500000 0 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1.000000 0 1
1 1 2
2 1 3
3 1 4
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
1.500000 0 1
5 2 2
6 2 1
5 3 2
6 3 1
5 4 1
2.000000 0 1
1 1 1
2 1 2
3 1 2
4 1 2
5 1 2
6 1 2
1 2 2
2 2 2
3 2 2
4 2 2
1 3 1
3 3 1
4 3 1
 2.500000 0 1
2 1 1
3 1 1
4 1 1
5 1 1
6 1 1
1 2 1
2 2 1
3 2 1
4 2 1
5 2 1
2 3 1
5 3 1
3 4 1
4 4 1
"""
        colors = """\
leftbound,colour
0,FEE1E1
1,FE5906
2,0EFA07
3,8602F0
"""

        def test51(self):
            "FLS - reading list of AscGrid objects - converting to RGBA images"
            colors = ColorMapping(mock.Stream(self.colors))
            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            expectAt = {
                # pixel-array-category
                # (2,1)-[3,3]-(000011)
                (2, 1): [(0x00, 0x00, 0x00, 0x00),  # 0
                         (0x00, 0x00, 0x00, 0x00),  # 0
                         (0x00, 0x00, 0x00, 0x00),  # 0
                         (0x00, 0x00, 0x00, 0x00),  # 0
                         (0xfe, 0xe1, 0xe1, 0xff),  # 1
                         (0xfe, 0xe1, 0xe1, 0xff),  # 1
                         ],
                # pixel-array-category
                # (4,2)-[5,2]-(013221)
                (4, 2): [(0x00, 0x00, 0x00, 0x00),  # 0
                         (0xfe, 0xe1, 0xe1, 0xff),  # 1
                         (0x0e, 0xfa, 0x07, 0xff),  # 3
                         (0xfe, 0x59, 0x06, 0xff),  # 2
                         (0xfe, 0x59, 0x06, 0xff),  # 2
                         (0xfe, 0xe1, 0xe1, 0xff),  # 1
                         ],
                # pixel-array-category
                # (2,3)-[3,1]-(124421)
                (2, 3): [(0xfe, 0xe1, 0xe1, 0xff),  # 1
                         (0xfe, 0x59, 0x06, 0xff),  # 2
                         (0x86, 0x02, 0xf0, 0xff),  # 4
                         (0x86, 0x02, 0xf0, 0xff),  # 4
                         (0xfe, 0x59, 0x06, 0xff),  # 2
                         (0xfe, 0xe1, 0xe1, 0xff),  # 1
                         ],
                }
            for i in range(6):
                image = asclist[i][1].asImage(colors, bits=24)
                self.assertEqual(image.mode, "RGBA")
                for coords, expected_colors in expectAt.items():
                    self.assertEqual((coords, i, image.getpixel(coords)), (coords, i, expected_colors[i]))

        def test60(self):
            "FLS - reading list of AscGrid objects - converting to paletted images"
            colors = ColorMapping(mock.Stream(self.colors))
            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            expectAt = {(4, 2): [0, 0, 0, 0, 1, 1, ],
                        (4, 2): [0, 1, 3, 2, 2, 1, ],
                        (2, 3): [1, 2, 4, 4, 2, 1, ],
                        }
            for i in range(6):
                image = asclist[i][1].asImage(colors, bits=8)
                self.assertEqual(image.mode, "P")
                for coords, expected_colors in expectAt.items():
                    self.assertEqual((coords, image.getpixel(coords)), (coords, expected_colors[i]))

        def test80(self):
            "FLS - reading list of AscGrid objects - converting to paletted images - buffered"
            colors = ColorMapping(mock.Stream(self.colors))
            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data)
            self.assertEqual(len(asclist), 6)
            expectAt = {(4, 2): [0, 0, 0, 0, 1, 1, ],
                        (4, 2): [0, 1, 3, 2, 2, 1, ],
                        (2, 3): [1, 2, 4, 4, 2, 1, ],
                        }
            for i in range(6):
                _ = asclist[i][1].asImage(colors, bits=8)
                image = asclist[i][1].asImage(colors, bits=8)
                self.assertEqual(image.mode, "P")
                for coords, expected_colors in expectAt.items():
                    self.assertEqual((coords, image.getpixel(coords)), (coords, expected_colors[i]))

    class CanPickleGrid(unittest.TestCase):
        data = mock.Stream("""\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
""")
        colors = """\
leftbound,colour
0.0,FEE1E1
1.0,FE5906
2.0,0EFA07
3.0,8602F0
"""

        def test00(self):
            "can pickle AscGrid without an image"
            out = mock.Stream()
            obj = AscGrid(self.data)
            import pickle
            pickle.dump(obj, out)

        def test01(self):
            "can pickle AscGrid with/ an image"

            out = mock.Stream()
            obj = AscGrid(self.data)
            colors = ColorMapping(mock.Stream(self.colors))
            obj.asImage(colors, bits=8)
            import pickle
            pickle.dump(obj, out)

    class CanHandleTripleStars(unittest.TestCase):
        data = """\
/* run: 38da1, created at: 18:33:11, 23- 1-2003, time =    78.00     DELFT-FLS version 2.55, 14-july-2001
MAIN DIMENSIONS                  MMAX    NMAX
                                ***   4
GRID                           DX    X0       Y0
                                   100.00   135050.00  455050.00
CLASSES OF INCREMENTAL FILE    H       C       Z       U       V
                                  0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
ENDCLASSES
0.000 0 1
3 1 1
4 1 1
.500000 0 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1.000000 0 1
1 1 2
2 1 3
3 1 3
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
"""

        def test400(self):
            "can count even with *** and no extra knowledge"

            data = mock.Stream(self.data)
            asclist = AscGrid.listFromStream(data, just_count=True)
            self.assertEqual(asclist, 3)

        def test410(self):
            "can read *** if a default is given"

            data = mock.Stream(self.data)
            default_grid = mock.Object(ncols=10)
            asclist = AscGrid.listFromStream(data, default_grid=default_grid)
            self.assertEqual(len(asclist), 3)
            for timestamp, item in asclist:
                self.assertEqual(item.ncols, 10)
            for timestamp, item in asclist:
                self.assertEqual(item.nrows, 4)

        def test420(self):
            "without a default *** causes a TypeError"

            data = mock.Stream(self.data)
            self.assertRaises(TypeError, AscGrid.listFromStream, data)

    class CalculateDotIncMaximumDifference(unittest.TestCase):
        data = """\
/* run: 38da1, created at: 18:33:11, 23- 1-2003, time =    78.00     DELFT-FLS version 2.55, 14-july-2001
MAIN DIMENSIONS                  MMAX    NMAX
                                  6   4
GRID                           DX    X0       Y0
                                   100.00   135050.00  455050.00
CLASSES OF INCREMENTAL FILE    H       C       Z       U       V
                                  0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
ENDCLASSES
0.000 0 1
3 1 1
4 1 1
.500000 0 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1.000000 0 1
1 1 2
2 1 2
3 1 3
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
"""
        outputNN = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
-999 -999 -999 -999 -999 -999
-999 -999 -999 -999 2.0 -999
0.5 0.5 0.5 0.5 2.0 -999
1.0 1.0 2.0 2.0 2.0 0.5
"""
        outputN0 = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
-999 -999 -999 -999 -999 -999
-999 -999 -999 -999 2.0 -999
0.5 0.5 0.5 0.5 1.5 -999
1.0 0.5 1.0 1.5 1.0 0.5
"""
        output0N = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
0.0 0.0 0.0 0.0 0.0 0.0
0.0 0.0 0.0 0.0 2.0 0.0
0.5 0.5 0.5 0.5 1.5 0.0
1.0 0.5 1.0 1.5 1.0 0.5
"""
        output00 = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
0.0 0.0 0.0 0.0 0.0 0.0
0.0 0.0 0.0 0.0 2.0 0.0
0.5 0.5 0.5 0.5 1.5 0.0
1.0 0.5 1.0 1.5 1.0 0.5
"""

        def test400(self):
            "correct metadata from inc file"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data)

            self.assertEqual(obj.ncols, 6)
            self.assertEqual(obj.nrows, 4)
            self.assertEqual(obj.xllcorner, 135000)
            self.assertEqual(obj.yllcorner, 455000)
            self.assertEqual(obj.cellsize, 100)
            self.assertEqual(obj.nodata_value, -999)

        def test410(self):
            "maximum increments, from raw sequence"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data)
            reference = [[None, None, None, None, None, None],
                         [None, None, None, None, 2.0, None],
                         [0.5, 0.5, 0.5, 0.5, 1.5, None],
                         [1.0, 0.5, 1.0, 1.5, 1.0, 0.5],
                         ]

            for col in range(1, obj.ncols + 1):
                for row in range(1, obj.nrows + 1):
                    self.assertEqual(obj[col, row], reference[row - 1][col - 1], "[%d,%d]: %s != %s" % (col, row, obj[col, row], reference[row - 1][col - 1], ))

        def test420(self):
            "maximum increments, starts from None, ends in constant grid"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data, end_in_constant=True)
            reference = AscGrid(mock.Stream(self.outputN0))

            for col in range(1, obj.ncols + 1):
                for row in range(1, obj.nrows + 1):
                    self.assertEqual(obj[col, row], reference[col, row], "[%d,%d]: %s != %s" % (col, row, obj[col, row], reference[col, row], ))

        def test430(self):
            "maximum increments, starts from 0.0, ends with last grid"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data, default_value=0.0)
            reference = AscGrid(mock.Stream(self.output0N))

            for col in range(1, obj.ncols + 1):
                for row in range(1, obj.nrows + 1):
                    self.assertEqual(obj[col, row], reference[col, row], "[%d,%d]: %s != %s" % (col, row, obj[col, row], reference[col, row], ))

        def test440(self):
            "maximum increments, starts from 0.0, ends in repeated grid"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data, default_value=0.0, end_in_constant=True)
            reference = AscGrid(mock.Stream(self.output00))

            for col in range(1, obj.ncols + 1):
                for row in range(1, obj.nrows + 1):
                    self.assertEqual(obj[col, row], reference[col, row], "[%d,%d]: %s != %s" % (col, row, obj[col, row], reference[col, row], ))

        def test530(self):
            "maximum increments in time units, ends with last grid"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data, pertimeunit=True)
            reference = [[None, None, None, None, None, None],
                         [None, None, None, None, 4.0, None],
                         [1.0, 1.0, 1.0, 1.0, 3.0, None],
                         [2.0, 1.0, 1.0, 3.0, 2.0, 1.0],
                         ]

            for col in range(1, obj.ncols + 1):
                for row in range(1, obj.nrows + 1):
                    self.assertEqual(obj[col, row], reference[row - 1][col - 1], "[%d,%d]: %s != %s" % (col, row, obj[col, row], reference[row - 1][col - 1], ))

        def test630(self):
            "maximum increments in time units, ends with last grid, grouping per hour"

            data = mock.Stream(self.data)
            obj = AscGrid.maxIncrementsFromStream(data, oneperhour=True, pertimeunit=True)
            reference = [[None, None, None, None, None, None],
                         [None, None, None, None, 2.0, None],
                         [0.5, 0.5, 0.5, 0.5, 2.0, None],
                         [1.0, 1.0, 1.5, 1.5, 2.0, 0.5],
                         ]

            for col in range(1, obj.ncols + 1):
                for row in range(1, obj.nrows + 1):
                    self.assertEqual(obj[col, row], reference[row - 1][col - 1], "[%d,%d]: %s != %s" % (col, row, obj[col, row], reference[row - 1][col - 1], ))

    class ApplyFunctionToGrids(unittest.TestCase):
        data_inc = """\
/* run: 38da1, created at: 18:33:11, 23- 1-2003, time =    78.00     DELFT-FLS version 2.55, 14-july-2001
MAIN DIMENSIONS                  MMAX    NMAX
                                  6   4
GRID                           DX    X0       Y0
                                   100.00   135050.00  455050.00
CLASSES OF INCREMENTAL FILE    H       C       Z       U       V
                                  0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
ENDCLASSES
0.000 0 1
3 1 1
4 1 1
.500000 0 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1.000000 0 1
1 1 2
2 1 2
3 1 3
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
"""
        data_asc = """\
nCols        5
nRows        5
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -0.2 0 -999 3.05
 -999 0 0 0.5 1.2
 -999 0 0 0 -999
 0 0 0 0 -999
 -999 1.1 1.4 0.1 0
"""

        def test000(self):
            "result of pixelwise unary function has correct metadata"

            i = AscGrid(mock.Stream(self.data_asc))
            obj = AscGrid.apply(lambda x: x, i)
            self.assertEqual(obj.ncols, 5)
            self.assertEqual(obj.nrows, 5)
            self.assertEqual(obj.xllcorner, 135000)
            self.assertEqual(obj.yllcorner, 455000)
            self.assertEqual(obj.cellsize, 100)
            self.assertEqual(obj.nodata_value, -999)

        def test010(self):
            "doubling pixelwise a 5x5 grid"

            i = AscGrid(mock.Stream(self.data_asc))
            obj = AscGrid.apply(lambda x: 2 * x, i)
            for row in range(1, obj.nrows + 1):
                for col in range(1, obj.ncols + 1):
                    if i[col, row] is not None:
                        self.assertEqual(obj[col, row], 2 * i[col, row])
                    else:
                        self.assertEqual(obj[col, row], None)

        def test100(self):
            "result of pixelwise binary function has correct metadata"

            i = [i[1] for i in AscGrid.listFromStream(mock.Stream(self.data_inc))]
            obj = AscGrid.apply(lambda x, y: x + y, i[0], i[1])
            self.assertEqual(obj.ncols, 6)
            self.assertEqual(obj.nrows, 4)
            self.assertEqual(obj.xllcorner, 135000)
            self.assertEqual(obj.yllcorner, 455000)
            self.assertEqual(obj.cellsize, 100)
            self.assertEqual(obj.nodata_value, -999)

        def test110(self):
            "adding two 6x4 grids"

            i = [i[1] for i in AscGrid.listFromStream(mock.Stream(self.data_inc))]
            obj = AscGrid.apply(lambda x, y: x + y, i[0], i[1])
            for row in range(1, obj.nrows + 1):
                for col in range(1, obj.ncols + 1):
                    if i[0][col, row] is not None and i[1][col, row] is not None:
                        self.assertEqual(obj[col, row], i[0][col, row] + i[1][col, row])
                    else:
                        self.assertEqual(obj[col, row], None)

    class FirstTimestampWithValue(unittest.TestCase):
        data_inc = """\
/* run: 38da1, created at: 18:33:11, 23- 1-2003, time =    78.00     DELFT-FLS version 2.55, 14-july-2001
MAIN DIMENSIONS                  MMAX    NMAX
                                  6   4
GRID                           DX    X0       Y0
                                   100.00   135050.00  455050.00
CLASSES OF INCREMENTAL FILE    H       C       Z       U       V
                                  0.500     -999     -999     -999     -999
                                   1.000     -999     -999     -999     -999
                                   2.000     -999     -999     -999     -999
                                   0.000     -999     -999     -999     -999
                                   20.000     -999     -999     -999     -999
ENDCLASSES
50.000 0 1
2 1 4
3 1 1
4 1 1
50.500000 0 1
2 1 1
3 1 2
4 1 3
5 1 2
3 2 1
4 2 1
5 2 1
1 4 0
51.000000 0 1
1 1 2
2 1 2
3 1 3
5 1 3
6 1 1
1 2 1
2 2 1
5 2 3
5 3 3
4 1 1
"""
        data_timestamps_gt00_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 51 -999
 51 51 50.5 50.5 50.5 -999
 51 50.5 50 50 50.5 51
"""
        data_timestamps_ge05_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 51 -999
 51 51 50.5 50.5 50.5 -999
 51 50.5 50 50 50.5 51
"""
        data_timestamps_ge10_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 51 -999
 -999 -999 -999 -999 51 -999
 51 51 50.5 50.5 50.5 -999
"""
        data_timestamps_ge15_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 51 -999
 -999 -999 -999 -999 51 -999
 -999 -999 51 50.5 51 -999
"""
        data_timestamps_eq00_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 50.5 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 50 -999 -999 -999 -999
"""
        data_timestamps_eq05_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 51 51 50.5 50.5 50.5 -999
 -999 50.5 50 50 -999 51
"""
        data_timestamps_eq10_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 -999 -999
 51 51 50.5 -999 50.5 -999
"""
        data_timestamps_eq20_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 51 -999
 -999 -999 -999 -999 51 -999
 -999 -999 51 50.5 51 -999
"""
        data_levels_00_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 2 -999
 0.5 0.5 0.5 0.5 0.5 -999
 1 0.5 0.5 0.5 1 0.5
"""
        data_levels_10_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 2 -999
 -999 -999 -999 -999 2 -999
 1 1 1 2 1 -999
"""
        data_levels_15_asc = """\
nCols        6
nRows        4
xllCorner    135000
yllCorner    455000
CellSize     100
nodata_value -999
 -999 -999 -999 -999 -999 -999
 -999 -999 -999 -999 2 -999
 -999 -999 -999 -999 2 -999
 -999 -999 2 2 2 -999
"""

        def test000(self):
            "xlistFromStream with threshold, check the template"

            received = AscGrid.listFromStream(mock.Stream(self.data_inc), threshold=1.0)
            output = mock.Stream()
            received[0].writeToStream(output)
            self.assertEqual(''.join(output.content), "nCols        6\nnRows        4\nxllCorner    135000\nyllCorner    455000\nCellSize     100\nnodata_value -999\n -999 -999 -999 -999 -999 -999\n -999 -999 -999 -999 -999 -999\n -999 -999 -999 -999 -999 -999\n -999 -999 -999 -999 -999 -999\n")

        def test002(self):
            "xlistFromStream with threshold 1.0"

            received = AscGrid.listFromStream(mock.Stream(self.data_inc), threshold=1.0)
            self.assertEqual(received[1:], [(50.5, {1.0: [(3, 4), (5, 4)],
                                                    2.0: [(4, 4)]}),
                                            (51.0, {1.0: [(1, 4), (2, 4)],
                                                    2.0: [(5, 3), (5, 2)]})])

        def test004(self):
            "xlistFromStream with threshold 1.5"

            received = AscGrid.listFromStream(mock.Stream(self.data_inc), threshold=1.5)
            self.assertEqual(received[1:], [(50.5, {2.0: [(4, 4)]}),
                                            (51.0, {2.0: [(3, 4), (5, 4), (5, 3), (5, 2)]})])

        def test006(self):
            "xlistFromStream with threshold 0.0"

            received = AscGrid.listFromStream(mock.Stream(self.data_inc), threshold=0.0)
            self.assertEqual(received[1:], [(50.0, {0.5: [(3, 4), (4, 4)]}),
                                            (50.5, {0.5: [(2, 4), (3, 3), (4, 3), (5, 3)],
                                                    1.0: [(5, 4)]}),
                                            (51.0, {0.5: [(6, 4), (1, 3), (2, 3)],
                                                    1.0: [(1, 4)],
                                                    2.0: [(5, 2)]})])

        def test010(self):
            "earliest timestamp for pixel reaching or exceeding value 1.0 (1.0 a possible grid value)"

            received = AscGrid.firstTimestampWithValue(mock.Stream(self.data_inc), threshold=1.0)

            timestamps, levels = received

            output = mock.Stream()
            timestamps.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_timestamps_ge10_asc)

        def test012(self):
            "first value for pixel reaching or exceeding value 1.0 (1.0 a possible grid value)"

            received = AscGrid.firstTimestampWithValue(mock.Stream(self.data_inc), threshold=1.0)

            timestamps, levels = received

            output = mock.Stream()
            levels.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_levels_10_asc)

        def test020(self):
            "earliest timestamp for pixel reaching or exceeding value 1.5 (1.5 is not a possible grid value)"

            received = AscGrid.firstTimestampWithValue(mock.Stream(self.data_inc), threshold=1.5)

            timestamps, levels = received

            output = mock.Stream()
            timestamps.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_timestamps_ge15_asc)

        def test022(self):
            "first value for pixel reaching or exceeding value 1.5 (1.5 is not a possible grid value)"

            received = AscGrid.firstTimestampWithValue(mock.Stream(self.data_inc), threshold=1.5)

            timestamps, levels = received

            output = mock.Stream()
            levels.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_levels_15_asc)

        def test030(self):
            "earliest timestamp for pixel EXCEEDING value 0.0 (for 0.0 reaching is not enough)"

            received = AscGrid.firstTimestampWithValue(mock.Stream(self.data_inc), threshold=0.0)

            timestamps, levels = received

            output = mock.Stream()
            timestamps.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_timestamps_gt00_asc)

        def test032(self):
            "first value for pixel EXCEEDING value 0.0 (for 0.0 reaching is not enough)"

            received = AscGrid.firstTimestampWithValue(mock.Stream(self.data_inc), threshold=0.0)

            timestamps, levels = received

            output = mock.Stream()
            levels.writeToStream(output)
            self.assertEqual(''.join(output.content), self.data_levels_00_asc)

        def test100(self):
            "list timestamps for pixel taking on each class value, with repetitions"

            received = AscGrid.listFromStream(mock.Stream(self.data_inc), threshold=False)
            self.assertEqual(received[1:], [(50.0, {0.0: [(2, 4)],
                                                    0.5: [(3, 4), (4, 4)]}),
                                            (50.5, {0.0: [(1, 1)],
                                                    0.5: [(2, 4), (3, 3), (4, 3), (5, 3)],
                                                    1.0: [(3, 4), (5, 4)],
                                                    2.0: [(4, 4)]}),
                                            (51.0, {0.5: [(6, 4), (1, 3), (2, 3), (4, 4)],
                                                    1.0: [(1, 4), (2, 4)],
                                                    2.0: [(3, 4), (5, 4), (5, 3), (5, 2)]})])

        def test104(self):
            "list of timestamps for pixel taking on each class value, no repetitions"

            received = AscGrid.listFromStream(mock.Stream(self.data_inc), threshold=True)
            self.assertEqual(received[1:], [(50.0, {0.0: [(2, 4)],
                                                    0.5: [(3, 4), (4, 4)]}),
                                            (50.5, {0.0: [(1, 1)],
                                                    0.5: [(2, 4), (3, 3), (4, 3), (5, 3)],
                                                    1.0: [(3, 4), (5, 4)],
                                                    2.0: [(4, 4)]}),
                                            (51.0, {0.5: [(6, 4), (1, 3), (2, 3)],
                                                    1.0: [(1, 4), (2, 4)],
                                                    2.0: [(3, 4), (5, 4), (5, 3), (5, 2)]})])

        def test120(self):
            "grids with first timestamps for each class value"

            expected = [(0.0, self.data_timestamps_eq00_asc),
                        (0.5, self.data_timestamps_eq05_asc),
                        (1.0, self.data_timestamps_eq10_asc),
                        (2.0, self.data_timestamps_eq20_asc),
                        ]
            received = AscGrid.firstTimestamp(mock.Stream(self.data_inc), threshold=True)

            for i_expected, i_received in zip(expected, received):
                output = mock.Stream()
                i_received[1].writeToStream(output)
                self.assertEqual(i_expected, (i_received[0], ''.join(output.content)))

    class ExtractPercentiles(unittest.TestCase):

        def setUp(self):

            import random

            self.grid = AscGrid(ncols=80, nrows=80, xllcorner=150000, yllcorner=400000,
                                cellsize=100, nodata_value=-999)
            for row in range(80):
                for col in range(0, 80, 2):
                    self.grid.values[row, col] = random.random() - 1
                    self.grid.values[row, col + 1] = random.random() + 1
            self.grid.values[0, 0:2] = 0.0

        def test010(self):
            "extract 50th percentile of 80x80 grid, made easy"

            self.assertEqual(self.grid.scoreatpercentile(50), 0.0)

    class ReadingGdalObject(unittest.TestCase):

        def setUp(self):
            global gdal
            self.oldgdal = gdal
            gdal = mock.gdal

        def tearDown(self):
            global gdal
            gdal = self.oldgdal

        def test000(self):
            "initializing from gdal.Dataset"

            v = numpy.ndarray((3, 4))
            v[:] = 0
            dataset_1 = mock.gdal.Dataset(v, 0, 0, 10, -999)
            g = AscGrid(dataset_1)
            output = mock.Stream()
            g.writeToStream(output)
            expect = """\
nCols        4
nRows        3
xllCorner    0
yllCorner    0
CellSize     10
nodata_value -999
 0 0 0 0
 0 0 0 0
 0 0 0 0
"""
            self.assertEqual(''.join(output.content), expect)

        def test010(self):
            "NoDataValues in gdal.Dataset become None"

            v = numpy.ndarray((3, 3))
            v[0, :] = [-999] * 3
            v[1, :] = [21, -999, 23]
            v[2, :] = [31, -999, 33]
            dataset_1 = mock.gdal.Dataset(v, 0, 0, 10, -999)
            g = AscGrid(dataset_1)
            self.assertEqual(g[1, 1], None)
            self.assertEqual(g[2, 2], None)
            self.assertEqual(g[3, 3], 33)

        def test100(self):
            "scoreatpercentile from gdal.Dataset without None"

            v = numpy.ndarray((3, 3))
            v[0, :] = [11, 12, 13]
            v[1, :] = [21, 22, 23]
            v[2, :] = [31, 32, 33]
            dataset_1 = mock.gdal.Dataset(v, 0, 0, 10, -999)
            g = AscGrid(dataset_1)
            self.assertEqual(g.scoreatpercentile(50), 22.0)

        def test110(self):
            "scoreatpercentile from gdal.Dataset with None"

            v = numpy.ndarray((3, 3))
            v[1, :] = [21, 22, 23]
            v[2, :] = [31, 32, 33]
            v[0, :] = [-999] * 3
            v[:, 1] = [-999] * 3
            dataset_1 = mock.gdal.Dataset(v, 0, 0, 10, -999)
            g = AscGrid(dataset_1)
            self.assertEqual(g.scoreatpercentile(50), 27.0)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(GridFromFile))
    suite.addTest(unittest.makeSuite(GridRecognizesObjects))
    suite.addTest(unittest.makeSuite(GridModifyingContent))
    suite.addTest(unittest.makeSuite(GridWritingToStream))
    suite.addTest(unittest.makeSuite(CoordsConversion))
    suite.addTest(unittest.makeSuite(ListFromIncFile))
    suite.addTest(unittest.makeSuite(ListFromFLSIncFile))
    suite.addTest(unittest.makeSuite(TestColorMapping))
    suite.addTest(unittest.makeSuite(ImageConversion))
    suite.addTest(unittest.makeSuite(CanPickleGrid))
    suite.addTest(unittest.makeSuite(CanHandleTripleStars))
    suite.addTest(unittest.makeSuite(CalculateDotIncMaximumDifference))
    suite.addTest(unittest.makeSuite(ApplyFunctionToGrids))
    suite.addTest(unittest.makeSuite(FirstTimestampWithValue))
    suite.addTest(unittest.makeSuite(ExtractPercentiles))
    suite.addTest(unittest.makeSuite(ReadingGdalObject))

    import doctest
    suite.addTest(doctest.DocTestSuite())
    return suite

if __name__ == '__main__':
    mock.lint(__file__)

    from unittest import TextTestRunner
    TextTestRunner(verbosity=2).run(testsuite())
