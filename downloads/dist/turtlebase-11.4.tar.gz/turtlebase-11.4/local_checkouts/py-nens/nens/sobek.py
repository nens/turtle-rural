#!/usr/bin/env python
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the nens library.
#
# the nens library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# the nens library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2008, 2009 Mario Frasca
#
#***********************************************************************
#* Library    : defines sobek objects, enables reading and comparing
#*
#* Project    : various
#*
#* $Id: sobek.py 19362 2011-03-24 10:44:35Z reinout.vanrees $
#*
#* initial programmer :  Mario Frasca
#* initial date       :  2008-07-28
#**********************************************************************

"""this module defines classes that are useful for reading and writing sobek files.

one way to use this is by reading a sobek file into a ``nens.sobek.File`` object.

you can then access the objects by type, index or id.

objects can be queried and altered.

if you alter the content, you may save the ``nens.sobek.File`` container.

"""

__revision__ = "$Rev: 19362 $"[6:-2]

from types import StringTypes, NoneType

NoneValue = -99999
max_decimal_digits = 15

import logging
import datetime
import os
import os.path
import re
from struct import unpack

log = logging.getLogger('nens.sobek')


def deprecated(func):
    """use this decorator to mark functions as deprecated.

    calling a function marked as deprecated will result in a warning
    being emitted.
    """

    def new_func(*args, **kwargs):
        log.warn("Call to deprecated function %s." % func.__name__,
                 category=DeprecationWarning)
        return func(*args, **kwargs)

    new_func.__name__ = func.__name__
    new_func.__doc__ = func.__doc__
    new_func.__dict__.update(func.__dict__)
    return new_func


def print_float(value):
    # don't try to be smart with exponent notation
    if value >= 1e9:
        return '%g' % value
    # natural notation
    from math import log, ceil
    try:
        leading_length = ceil(log(value) / log(10))
    except (ValueError, OverflowError):
        leading_length = 0
    trailing_length = min(15 - leading_length, max_decimal_digits)

    format = "%%0.%if" % trailing_length
    result = format % value
    while result[-1] == '0':
        result = result[:-1]
    if result[-1] == '.':
        result = result[:-1]
    return result


def isvalue(text):
    if text[0] == text[-1] == "'":
        return True
    if text == '<':
        return True
    try:
        int(text)
        return True
    except:
        pass
    try:
        float(text)
        return True
    except:
        pass
    return False


def value(text):
    if text == "":
        return ""
    if text[0] == text[-1] == "'":
        return text[1:-1]
    try:
        return int(text)
    except:
        pass
    try:
        return float(text)
    except:
        pass
    return text

splitter = re.compile(r'[ \t\n]+')


def despace_strings(text):
    """returns altered text where included strings have no spaces.
    """

    instring = False
    result = []
    for ch in text:
        if ch == "'":
            instring = not instring
        if (ch in [' ', '\t']) and instring:
            ch = chr(0)
        result.append(ch)
    result = ''.join(result)
    return result


def respace_strings(text):
    return text.replace(chr(0), ' ')


class File(object):
    '''represents a list of Sobek objects.'''

    sourcedir = '.'

    @classmethod
    def setSourceDir(cls, d):
        if os.path.isdir(d):
            cls.sourcedir = d
        else:
            # raise an exception
            os.chdir(d)

    @classmethod
    def getSourceDir(cls):
        return cls.sourcedir

    pattern = re.compile(r'[A-Z][A-Z0-9_]{3}', re.I)

    def _str_to_stream(self, input):
        "this is part of the initialization process"
        self.source = None
        if isinstance(input, StringTypes):
            pastlastsep = (input.rfind(os.sep) + 1)
            if not pastlastsep and os.altsep:
                pastlastsep = input.rfind(os.altsep) + 1
            self.basename = input[pastlastsep:]
            if pastlastsep == 0:
                input = self.sourcedir + os.sep + input
            self.source = input
            try:
                input = file(self.source)
            except IOError:
                input = None
        return input

    def __len__(self):
        return len(self.content)

    def __init__(self, input):
        """initialize a ``File`` object from a file or a file name.

        if ``input`` is a file name, the name is held in
        ``self.source`` and can be used in a subsequent call to
        ``save``.
        """

        self.basename = None
        input = self._str_to_stream(input)
        content, self.extension, self.version = content_of_sobek_file(input, with_version=True)
        self.content = split_sobek_content(content)
        self.hashed = {}
        for i in self.content:
            self.hashed.setdefault(i.tag, [])
            self.hashed[i.tag].append(i)

    def writeToStream(self, output):
        """write self to an open writable output stream.
        """

        result = []
        if self.version and self.extension:
            result.append("%s%1.1f" % (self.extension, self.version))
        for item in self.content:
            result.append(str(item))

        if len(result) and result[-1] != '':
            result.append('')
        result = '\n'.join(result)

        output_methods = output.__class__.__dict__
        if 'writestr' in output_methods:
            result = result.replace('\n', '\r\n')
            output.writestr(self.basename, result)
        elif 'write' in output_methods:
            output.write(result)
        else:
            raise TypeError("don't know how to write to a %(__name__)s" % type(output))
        pass

    def save(self, destdir=None):
        """write ``self`` to ``destdir``.

        the behaviour depends on the type of destdir.
          - if a stream, ``self`` is written to it.
          - if None, ``self`` is rewritten to ``self.source``.
          - if a directory name, ``self`` is written to its
            corresponding file in that directory.

        """

        if isinstance(destdir, (NoneType, StringTypes)):
            if destdir is None:
                dest = self.source
            else:
                dest = destdir + os.sep + self.basename
            output = file(dest, "w")
            self.writeToStream(output)
            output.close()
        else:
            self.writeToStream(output)

    def append(self, obj):
        if not isinstance(obj, Object):
            raise TypeError("can't add this kind of objects")
        self.content.append(obj)
        self.hashed.setdefault(obj.tag, [])
        self.hashed[obj.tag].append(obj)

    def addObject(self, obj):
        self.append(obj)

    def _getindex(self, type, id, pool=None):
        if pool is None:
            pool = self.hashed.get(type.upper(), [])
        for i, item in enumerate(pool):
            log.debug('maybe this? %s(%s)' % (str(item), item.id))
            if item.id == id:
                return i
        raise KeyError("no %s object with id '%s'" % (i, id))

    def __delitem__(self, i):
        if isinstance(i, tuple):
            type, i = i
        else:
            raise ValueError('can remove one item at a time')
        if isinstance(i, StringTypes):
            i = self._getindex(type, i)
        obj = self.hashed[type][i]
        del self.hashed[type][i]
        self.content.remove(obj)

    def __getitem__(self, i):
        if isinstance(i, int):
            return self.content[i]

        if isinstance(i, tuple):
            i, id = i
        else:
            id = None

        if not isinstance(i, str) or not self.pattern.match(i):
            raise ValueError("not legal key %s(%s).  must be string [A-Z_0-9]{4}" %
                             (str(type(i)), i))
        result = self.hashed.get(i.upper(), [])
        log.debug('File being asked for %s, %s' % (i, id))
        log.debug('candidates for __getitem__ are %s' % result)
        if id is None:
            log.debug('returning the whole result')
            return result
        else:
            log.debug('choosing item with id %s' % id)
            return result[self._getindex(i, id, result)]

    def keys(self):
        return self.hashed.keys()


class Verbatim(File):
    '''represents a file which knows how to save itself'''

    def __init__(self, input):
        stream = self._str_to_stream(input)
        if stream is None:
            raise IOError("File not found: " + input)
        self.content = stream.readlines()
        self.hashed = {}
        self.extension = self.version = None
        self.lines = self.lines_generator()

    def __getitem__(self, i):
        raise IndexError("can't look at a verbatim as if it was a list")

    def writeToStream(self, output):
        output_methods = output.__class__.__dict__
        tmp = ''.join(self.content)
        if 'writestr' in output_methods:
            if self.basename[-3:].lower() not in ['zip', 'nvl']:
                tmp = tmp.replace('\n', '\r\n')
            output.writestr(self.basename, tmp)
        elif 'write' in output_methods:
            output.write(tmp)
        else:
            raise TypeError("don't know how to write to a %(__name__)s" % type(output))
        pass

    def append(self, obj):
        raise NotImplementedError("can't append to Verbatim files")

    def replace(self, old, new, count=-1):
        self.content = [i.replace(old, new, count) for i in self.content]

    def truncate(self, size=0):
        if size != 0:
            raise ValueError("can only truncate a Verbatim to empty string")
        self.content = []

    def write(self, s):
        self.content.append(s)

    def reset(self):
        self.lines = self.lines_generator()

    def readline(self):
        try:
            return self.lines.next()
        except StopIteration:
            return ''

    def lines_generator(self):
        for i in self.content:
            yield i


class Network(Verbatim):

    header = ["ID_NETWORK", "NAME_NETWORK", "", "", "TYPE_NETWORK",
              "", "", "", "", "", "LENGTE", "", "", "", "ID_FROM",
              "NAME_FROM", "", "", "", "TYPE_FROM", "", "X_COORD_FROM",
              "Y_COORD_FROM", "", "", "", "", "ID_TO", "NAME_TO", "",
              "", "", "TYPE_TO", "", "X_COORD_TO", "Y_COORD_TO", "",
              "", "", ""]

    def __init__(self, input):
        Verbatim.__init__(self, input)

        log.debug('get CSV content as list of dictionaries.')
        import csv
        stream = self._str_to_stream(input)
        input_reader = csv.reader(stream)
        input_data = [dict(zip(self.header, i))
                      for i in input_reader
                      if len(i) == len(self.header)]
        log.debug('%d candidate elements' % len(input_data))

        log.debug('throw away all that does not match type_network == "SBK_CHANNEL"')
        input_data = [i for i in input_data if i['TYPE_NETWORK'] == "SBK_CHANNEL"]
        log.debug('%d candidate elements' % len(input_data))

        self.categorized = {}

        for item in input_data:
            log.debug("%s" % item)
            for ident, type, x_coord, y_coord in [(item["ID_FROM"], item["TYPE_FROM"],
                                                   item["X_COORD_FROM"], item["Y_COORD_FROM"]),
                                                  (item["ID_TO"], item["TYPE_TO"],
                                                   item["X_COORD_TO"], item["Y_COORD_TO"])]:
                self.categorized.setdefault(type, {})
                self.categorized[type][ident, x_coord, y_coord] = True

    def __getitem__(self, key):
        return self.categorized[key]


class Object(object):
    '''represents a Sobek object or array.

    a sobek object has a tag, an id and a variable amount of fields.
    a sobek array has a tag and holds a variable amount of values.

    each field can hold a single value, a list of values, a sobek
    array or a sobek object.
    '''

    def __init__(self, input=None, tag=None, id=None, name=None, cols=None):
        self.fields = {}
        self.order = []
        self.tables = {}
        self.content = []
        if input is None:
            if tag is None:
                raise ValueError("can't initialize object without input nor tag")
            if id is None:
                import uuid
                id = str(uuid.uuid4())
            self.tag = tag
            if tag != 'TBLE':
                self['id'] = id
            else:
                self.id = None
                self.__cols = cols
        else:
            if tag is not None:
                raise ValueError("can't initialize object with both input and tag")
            self.tag = None
            if isinstance(input, StringTypes):
                input = [respace_strings(i) for i in splitter.split(despace_strings(input)) if i]
            source = ' '.join(input)
            try:
                self.initFromList(input)
            except:
                raise ValueError("can't initialize object from '%s'" % source)
            self._hash = repr(self.fields).__hash__()
            if 'id' in self.fields:
                self.id = self.fields['id'][0]
            else:
                self.id = None
            if self.tag == 'TBLE':
                try:
                    self.__cols = self['TBLE'].index('<')
                except ValueError:
                    self.__cols = None
        if name is not None:
            if self.tag == 'TBLE':
                self.name = name
            else:
                self['nm'] = name
        if self.tag == 'TBLE':
            self.table_data = {}
            row_no = 0
            row_values = []
            for item in self['TBLE']:
                if item == '<':
                    col_no = 0
                    for v in row_values:
                        self.table_data[row_no, col_no] = v
                        col_no += 1
                    row_no += 1
                    row_values = []
                    continue
                row_values.append(item)

    def initFromList(self, input):
        if isvalue(input[1]):
            self.tag = input.pop(0)
            values = []
            while input[0] != self.tag.lower():
                values.append(value(input.pop(0)))
            closing_tag = input.pop(0)
            self.fields[self.tag] = values
            self.order.append(self.tag)
        else:
            self.tag = input.pop(0)
            if self.tag == 'TBLE' and input[0] != 'tble' and not isvalue(input[0]):
                # specifying name and length...
                self.name = input.pop(0)
                input.pop(0)
            while input[0] != self.tag.lower():
                #print self.fields
                #print input
                i = input.pop(0)
                values = []
                if isvalue(i):
                    # seems to be a loose literal...
                    self.fields.setdefault(self.tag, [])
                    self.fields[self.tag].append(value(i))
                elif i == i.upper():
                    # included object
                    input.insert(0, i.strip())
                    self.addObject(Object(input))
                else:
                    # field - copy it then scan all its optional values
                    fields = []
                    if not isvalue(input[0]) and not (i == i.upper()):
                        i = i + ' ' + input.pop(0)
                    while isvalue(input[0]):
                        fields.append(value(input.pop(0)))
                    self.fields[i] = fields
                    if i not in self.order:
                        self.order.append(i)
            closing_tag = input.pop(0)
        return closing_tag

    def __lt__(self, other):
        return self.fields.__lt__(other.fields)

    def __eq__(self, other):
        return self.fields.__eq__(other.fields)

    def __hash__(self):
        return self._hash

    def print_field(self, value, depth=0):
        if isinstance(value, (float, int, long)):
            value = print_float(value)
        elif isinstance(value, StringTypes):
            if value == '<':
                value = '<' + '  ' * depth
            else:
                value = "'" + value + "'"
        elif isinstance(value, datetime.datetime):
            value = value.strftime("'%Y-%m-%d;%H:%M:%S'")
        elif isinstance(value, datetime.timedelta):
            # sorry, too lazy to program it properly...
            day = datetime.datetime(2000, 1, 10, 0, 0, 0) + value
            value = "'" + day.strftime("%d:%H:%M:%S")[1:] + "'"
        elif isinstance(value, Object):
            inc_obj = value.__repr__(depth=depth)
            if self.tag == 'DOMN':
                depth = depth + 1
            log.debug("string representation of included object = %s" % inc_obj)
            # objects as CLID and CLTT do not want to go on a new line
            if value.tag not in ['CLID', 'CLTT']:
                value = '\n'.join([''] + [('  ' * depth + i) for i in inc_obj.split('\n')])
            else:
                value = inc_obj
        else:
            raise TypeError("can't handle this type: " + str(type(value)))
        return value

    def __repr__(self, depth=0):
        parts = []
        done = []

        if self.id is None and len(self.fields) == 1 and self.tag in self.fields:
            log.debug("string representation of an array")
            parts.append(self.tag)
            if self.tag == 'TBLE':
                if 'name' in self.__dict__:
                    parts.append(self.name)
                    parts.append(str(self.fields[self.tag].count('<')))
                parts.append(chr(0))
            for value in self.fields[self.tag]:
                parts.append(self.print_field(value))
            parts.append(self.tag.lower())
        else:
            log.debug("string representation of a true sobek object")
            ordered_fields = list(self.order)
            ordered_fields.extend([k for k in self.fields if k not in self.order])
            parts.append(self.tag)
            for field_name in ordered_fields:
                if field_name != field_name.upper():
                    parts.append(field_name)
                done.append(field_name)
                for value in self.fields[field_name]:
                    parts.append(self.print_field(value, depth=depth))
            if self.tag.lower() == 'domn':
                parts.append('\ndomn')
            else:
                parts.append(self.tag.lower())

        result = ' '.join(parts)
        result = result.replace(chr(0) + ' ', '\n')
        result = result.replace('< ', '<\n')
        return result

    def __delitem__(self, key):
        try:
            self.order.remove(key)
        except ValueError:
            pass
        del self.fields[key]

    def __getitem__(self, key, value=None):
        if isinstance(key, tuple):
            if self.tag == 'TBLE':
                return self.table_data[key]
            else:
                raise ValueError("indexing by tuple only allowed in TBLE")
        if isinstance(key, int):
            return self.content[key]
        return self.fields.setdefault(key, value or list())

    def __setitem__(self, key, value):
        if value is None:
            value = NoneValue
        if isinstance(key, tuple) and self.tag == 'TBLE':
            self.table_data[key] = value
            row, col = key
            self.fields['TBLE'][(self.__cols + 1) * row + col] = value
        elif isinstance(value, (list, tuple)):
            self.fields[key] = list(value)
        else:
            self.fields[key] = [value]
        if key not in self.order:
            self.order.append(key)
        if key == 'id':
            if isinstance(value, (list, tuple)):
                value = value[0]
            self.__dict__['id'] = value

    def __setattr__(self, key, value):
        if key == 'id' and 'id' in self.__dict__:
            raise AttributeError("can't redefine id attribute")
        object.__setattr__(self, key, value)

    def addObject(self, obj):
        self.fields.setdefault(obj.tag, [])
        self.fields[obj.tag].append(obj)
        self.content.append(obj)
        if obj.tag not in self.order:
            self.order.append(obj.tag)
        return obj

    def addRow(self, row, add_table=True, to_table=None, decimals=None):
        if self.tag == 'TBLE':
            add_to = self
        else:
            if to_table is None:
                if 'TBLE' not in self.fields:
                    if not add_table:
                        raise AttributeError("object does not have a TBLE field")
                    else:
                        self.addObject(Object("TBLE tble"))
                add_to = self['TBLE'][0]
            else:
                if to_table not in self.tables:
                    table = self.addObject(Object("TBLE tble"))
                    table.name = to_table
                    self.tables[to_table] = table
                add_to = self.tables[to_table]

        if add_to.__cols is None:
            add_to.__cols = len(row)
        if len(row) != add_to.__cols:
            raise ValueError("adding row with incorrect lenght")
        row_no = add_to.rows()

        col_no = 0
        for item in row:
            try:
                item = round(item, decimals)
            except:
                pass
            add_to['TBLE'].append(item)
            add_to[row_no, col_no] = item
            col_no += 1
        add_to['TBLE'].append('<')

    def clone(self):
        import copy
        return copy.deepcopy(self)

    def cols(self):
        "returns the amount of columns in a TBLE"
        return self.__cols

    def rows(self):
        "returns the amount of rows in a TBLE"

        if self.tag != 'TBLE':
            raise AttributeError("only TBLE objects have rows")

        if self.__cols is None:
            return 0

        return len(self['TBLE']) / (self.__cols + 1)

    def attribs(self):
        return self.fields.keys()

    def __contains__(self, key):
        return key in self.fields


class HISFile(Verbatim):
    """Read sobek ``his`` file en make timeseries visible.

    interne gegevenstructuren:

      - ``bin``: compleet inhoud van his file.
      - ``parameter_names``, ``location_names``: dictionaries.  ze
        koppelen de naam van een parameter/location aan zijn
        sequentiele plaats in het his bestand.

    """

    def __init__(self, input):
        input = self._str_to_stream(input)
        self.bin = input.read()
        #simple checks
        if self.bin[0:40].strip() != 'SOBEK':
            raise ValueError('HIS file corrupt.')

        #read

        reg = re.compile('T0: (?P<year>\d+)\.(?P<month>\d+)\.(?P<day>\d+) (?P<hour>\d+):(?P<minute>\d+):(?P<second>\d+)[ ]*\(scu=[ ]*(?P<scu>\d+).*')
        match = reg.match(self.bin[120:160])
        props = match.groupdict()

        self.dtstart = datetime.datetime(
            int(props['year']), int(props['month']), int(props['day']),
            int(props['hour']), int(props['minute']), int(props['second']))

        self.calc_timestep = int(props['scu'])

        self.nrof_parameters = unpack('<L', self.bin[160:164])[0]  # little endian
        self.nrof_locations = unpack('<L', self.bin[164:168])[0]  # little endian
        self.size_of_timestep = 4 + 4 * self.nrof_parameters * self.nrof_locations

        self.parameter_names = {}
        for p_count in range(self.nrof_parameters):
            idx_start = 168 + p_count * 20
            idx_end = idx_start + 20
            self.parameter_names[self.bin[idx_start:idx_end].strip()] = p_count

        self.location_names = {}
        for l_count in range(self.nrof_locations):
            idx_start = 168 + self.nrof_parameters * 20 + l_count * 24
            idx_end = idx_start + 20
            self.location_names[self.bin[idx_start + 4:idx_end].strip()] = l_count

        self.size_of_header = 168 + self.nrof_parameters * 20 + self.nrof_locations * 24

        self.timesteps = (len(self.bin) - self.size_of_header) / self.size_of_timestep

        idx_start = self.size_of_header + 0 * self.size_of_timestep
        idx_end = idx_start + 4
        ts_0 = unpack('<L', self.bin[idx_start:idx_end])[0]
        idx_start = self.size_of_header + 1 * self.size_of_timestep
        idx_end = idx_start + 4
        ts_1 = unpack('<L', self.bin[idx_start:idx_end])[0]

        self.nr_calc_timesteps_in_result_timestep = ts_1 - ts_0
        self.result_timestep = self.nr_calc_timesteps_in_result_timestep * self.calc_timestep
        log.debug('tijdstap resultaat is ' + str(self.result_timestep) + ' ' + str(self.nr_calc_timesteps_in_result_timestep) + ' ' + str(self.calc_timestep))

    def size(self):
        """the length (number of readings) of the timeseries"""
        return self.timesteps

    def parameters(self):
        """the parameters in the timeseries"""
        return self.parameter_names.keys()

    def locations(self):
        """the locations in the timeseries"""
        return self.location_names.keys()

    def get_timestamps(self):
        """return the timestamps for the values in the file"""

        return [self.get_datetime_of_timestep(i) for i in range(self.timesteps)]

    def get_timeseries(self, location_name, parameter_name, start=None, end=None, result_type=dict):
        """return the timeseries at location/parameter.

        a timeseries is a dictionary associating timestamp to value
        """

        result = [(self.get_datetime_of_timestep(i), v)
                  for i, v in enumerate(self.get_values(location_name, parameter_name))]
        if start:
            start = mk_datetime(start)
            result = [(t, v) for (t, v) in result if t >= start]
        if end:
            end = mk_datetime(end)
            result = [(t, v) for (t, v) in result if t < end]
        return result_type(result)

    def get_parameter_index(self, name):
        """return index of first matching parameter.

        if name is present in HIS file, its index is returned.

        otherwise interpret name as a regular expression and find the
        first match.  this is not guaranteed to provide the same
        result each time, as the order of the keys of a dictionary is
        dependent on the content of the dictionary and we return the
        first matching name.
        """

        if name not in self.parameter_names:

            par_re = re.compile(name)
            for p in self.parameter_names.keys():  # implementation
                                                   # dependent order
                if par_re.match(p):
                    log.warn("you asked for parameter '%s', you got '%s'." %
                             (name, unicode(p, errors='replace')))
                    name = p
                    break
            else:
                raise KeyError('parameter ' + name + ' not in hisfile')

        return self.parameter_names[name]

    def get_values(self, location_name, parameter_name, dtstart=None, dtend=None):
        """get complete timeseries at location/parameter.
        """

        if dtstart is not None or dtend is not None:
            log.warn("dtstart/dtend in nens.sobek.HISFile.get_values have no effect.")
        if location_name in self.location_names:
            idx_location = self.location_names[location_name]
        else:
            raise KeyError('location ' + location_name + ' not in hisfile ')

        idx_parameter = self.get_parameter_index(parameter_name)
        timestep_start = 0
        timestep_end = self.timesteps
        return self.get_timeseries_by_index(idx_location, idx_parameter, timestep_start, timestep_end)

    def get_timeseries_by_index(self, idx_location, idx_parameter, timestep_start, timestep_end):
        """get complete timeseries at location/parameter.
        """

        return [self.get_value(idx_location, idx_parameter, i)
                for i in range(timestep_start, timestep_end)]

    def get_values_timestep_by_index(self, idx_parameter, idx_timestep):
        """get values for all locations for given parameter/timestamp.
        """

        return dict([(name, self.get_value(value, idx_parameter, idx_timestep))
                     for name, value in self.location_names.items()])

    def get_value(self, idx_location, idx_parameter, idx_timestep):
        """get single value read at location/parameter/timestamp.
        """

        idx_start = (self.size_of_header +
                     idx_timestep * self.size_of_timestep +
                     (4 + idx_location * 4 * self.nrof_parameters + idx_parameter * 4))
        idx_end = idx_start + 4
        return unpack_floats(self.bin[idx_start:idx_end])[0]

    def get_datetime_of_timestep(self, idx_timestep):
        """get timestamp of given index.
        """

        pos = self.size_of_header + idx_timestep * self.size_of_timestep
        seconds = unpack('<L', self.bin[pos:pos + 4])[0] * self.calc_timestep
        return self.dtstart + datetime.timedelta(0, seconds)


def unpack_floats(input):
    return [float("%1.7g" % d) for d in unpack("<f", input)]


def mk_datetime(seconds_or_datetime):
    if isinstance(seconds_or_datetime, int):
        return datetime.datetime(1970, 1, 1) + datetime.timedelta(0, seconds_or_datetime)
    elif isinstance(seconds_or_datetime, datetime.datetime):
        return seconds_or_datetime
    else:
        raise TypeError("mk_datetime can only handle int or datetime.datetime, got %s instead." % type(seconds_or_datetime))


class SobekHIS(HISFile):
    @deprecated
    def __init__(self, input):
        '''a SobekHIS is different from a HISFile in that you
        initialize if with its content (not the stream)

        its get_timeseries method is different from the HISFile implementation
        '''
        from nens import mock
        HISFile.__init__(self, mock.Stream(input))

    @deprecated
    def get_timeseries(self, *argv, **kwargs):
        return self.get_values(*argv, **kwargs)


def compare_two_lists(first, second):
    """computes the differences between first and second files...

    the differences is a 5-tuple of the following values:
    number of elements in first file,
    number of elements in second file,
    elements in common,
    elements in first file which are not in the second one,
    elements in second file which are not in the first one.
    """

    #print len(first), len(second)

    # create the indices for the objects read
    hash_orig = dict((item, None) for item in first)
    hash_new = dict((item, None) for item in second)

    # create list of objects in one file not present in other
    intersection = [item for item in first if item in hash_new]
    orig_min_new = [item for item in first if item not in hash_new]
    new_min_orig = [item for item in second if item not in hash_orig]

    return (len(first), len(second), intersection, orig_min_new, new_min_orig)


def compare_two_files(first, second):
    "see: compare_two_lists"

    # read from files into lists of objects
    list_orig = split_sobek_content(content_of_sobek_file(file(first)))
    list_new = split_sobek_content(content_of_sobek_file(file(second)))
    return compare_two_lists(list_orig, list_new)


def compare_two_domains(first, second):
    """computes the difference between first and second domain

    it's an in-place substitution for compare_two_files, but works on
    the *content* of the two domains.

    see: compare_two_lists
    """

    domain_content_re = re.compile(r'DOMN .*?([A-Z0-9_]{4} .*)domn', re.S)

    first_content = content_of_sobek_file(file(first))
    match = domain_content_re.match(first_content)
    if not match:
        return None
    first_content = match.group(1)

    second_content = content_of_sobek_file(file(second))
    match = domain_content_re.match(second_content)
    if not match:
        return None
    second_content = match.group(1)

    #print first_content, second_content
    list_orig = split_sobek_content(first_content)
    list_new = split_sobek_content(second_content)
    #print list_orig, list_new
    return compare_two_lists(list_orig, list_new)


def content_of_sobek_file(stream, with_version=False):
    "reads a sobek file returning a content rich string"

    if stream is None:
        extension = version = None
        input = ""
    else:
        input = stream.read()
        # fall back to Mac separator style (the lazy way).
        input = input.replace('\r', '\n')
        input = input.replace('\n\n', '\n')

        # it may start with three chars plus some version number.
        fileversion_re = re.compile(r'^([A-Z0-9_]{3})([0-9]+\.[0-9]+)$')
        try:
            header, rest = input.split("\n", 1)
        except ValueError:
            header, rest = input, ''

        version = fileversion_re.match(header)
        if version:
            #print "skipping header"
            extension, version = version.groups()
            version = float(version)
            input = rest
        else:
            extension, version = None, None

    #print extension, version_number, header, input[:20]
    if with_version:
        return input, extension, version
    else:
        return input


def split_sobek_content(input):
    """splits the input string into the sobek parts, matching the start
    tag with the first corresponding closing tag.

    returns a list of Object.
    """

    result = []

    first_word_re = re.compile(r"^[ \t\n]*([A-Z_0-9]+) (.*)", re.S)
    #print r"^[ \t\n]*([A-Z_0-9]+) (.*)", input[:20]

    while first_word_re.match(input):
        first_word_match = first_word_re.match(input)
        opening = first_word_match.group(1)
        closing = opening.lower()
        first_object_re_string = "([ \t\n]*%s[ \t\n]+.*?[ \t\n]+%s)[\t ]*(?:[\n]+|$)(.*)" % (opening, closing)
        first_object_re = re.compile(first_object_re_string, re.S)

        #print input, first_object_re_string,
        item, input = first_object_re.match(input).groups()
        #print item
        result.append(Object(item))

    return result


def testsuite():
    import logging
    from nens import mock

    handler = mock.Handler(level=logging.DEBUG)
    logging.getLogger('').addHandler(handler)

    def reindent(s, i=1):
        return '\n'.join(['' * i + l for l in s.split('\n')])

    import unittest

    class ReadingAtomsTest(unittest.TestCase):
        def testNODE_length(self):
            "NODE object with 4 fields"
            obj = Object("NODE id 'BOEZ_1' nm '' px 134808.891822728 py 456721.97309417 node")
            self.assertEqual(len(obj.fields), 4)
            pass

        def testPDIN_no_id(self):
            "PDIN are arrays without an id"
            obj = Object("PDIN 1 2 3 pdin")
            self.assertEqual(obj['PDIN'], [1, 2, 3])
            pass

        def testNODE_tag(self):
            "NODE tag"
            obj = Object("NODE id '1' node")
            self.assertEqual(obj.tag, 'NODE')
            pass

        def testNODE_id(self):
            "NODE id"
            obj = Object("NODE id '1' node")
            self.assertEqual(obj.id, '1')
            pass

        def testNODE_fields(self):
            "NODE fields"
            obj = Object("NODE id 'BOEZ_1' nm '' px 134808.891822728 py 456721.97309417 node")
            self.assertEqual(obj['id'], ['BOEZ_1'])
            self.assertEqual(obj['nm'], [''])
            self.assertEqual(obj['px'], [134808.891822728])
            self.assertEqual(obj['py'], [456721.97309417])
            pass

    class ObjectLikeHandling(unittest.TestCase):

        def test1_creation(self):
            "create object with TAG only gets random id"
            obj = Object(tag="TEST")
            self.assertNotEqual(obj.id, None)

        def test2_creation(self):
            "create object with TAG and id"
            obj = Object(tag="TEST", id='id')
            self.assertEqual(obj.id, 'id')
            self.assertEqual(str(obj), "TEST id 'id' test")

        def test3_alter(self):
            "altering id field is reflected in id attribute"
            obj = Object(tag="TEST", id='id')
            obj['id'] = 'test'
            self.assertEqual(obj.id, 'test')
            self.assertEqual(str(obj), "TEST id 'test' test")

        def test40_alter(self):
            "altering id attribute raises AttributeError"
            obj = Object(tag="TEST", id='id')
            self.assertRaises(AttributeError, obj.__setattr__, 'id', 'test')

        def test42_alter(self):
            "reading incorrectly formed object raises ValueError"
            input = "GLFR id '0' BDFR id '0' ci '0' mf 0 sf 0 mr cp 0 40 mt st sr bdfr glfr"
            self.assertRaises(ValueError, Object, input)

        def test5_addingFields(self):
            "adding fields to object created with TAG and id"
            obj = Object(tag="TEST", id='id')
            obj['px'] = 135000
            obj['py'] = 455000
            self.assertEqual(str(obj), "TEST id 'id' px 135000 py 455000 test")

        def test60(self):
            "asking all attributes of an object"
            obj = Object(tag="TEST", id='id')
            obj['px'] = 135000
            obj['py'] = 455000
            self.assertEqual(len(obj.attribs()), 3)
            self.assertEqual('id' in obj.attribs(), True)
            self.assertEqual('px' in obj.attribs(), True)
            self.assertEqual('py' in obj.attribs(), True)

        def test61(self):
            "asking if an object has an attribute"
            obj = Object(tag="TEST", id='id')
            obj['px'] = 135000
            obj['py'] = 455000
            self.assertEqual('id' in obj, True)
            self.assertEqual('px' in obj, True)
            self.assertEqual('py' in obj, True)

        def test70(self):
            "reading attributes that contain attributes that contain values"
            src = "STFR id '15' ci '15' mf 4 mt cp 0 0.003 0 mr cp 0 0.003 0 s1 6 s2 6 sf 4 st cp 0 0.003 0 sr cp 0 0.003 stfr"
            obj = Object(src)
            self.assertEqual('mt cp' in obj.fields, True)
            self.assertEqual(obj.fields['mt cp'], [0, 0.003, 0])
            self.assertEqual(str(obj), src)

        def test71(self):
            "reading attributes that contain attributes with empty list of values"
            src = "GRID id '1' ci '1' gr gr grid"
            obj = Object(src)
            self.assertEqual('gr gr' in obj.fields, True)
            self.assertEqual(obj.fields['gr gr'], [])
            self.assertEqual(str(obj), src)

    class ReadingComplexTest(unittest.TestCase):

        def testFLBO_containedArray(self):
            "FLBO contained array"
            obj = Object("FLBO id 'lkb_condition_extern' ty 0 h_ wt 1 0 0 PDIN 0 0  pdin flbo")
            pdin = Object("PDIN 0 0 pdin")
            self.assertEqual(len(obj['PDIN']), 1)
            self.assertEqual(obj['PDIN'][0], pdin)
            pass

        def testFLBO_containedTable(self):
            "FLBO contained table"
            table_str = """\
TBLE \n\
 '2000/01/01;00:00:00' 1 <
 '2000/01/01;06:00:00' 1.5 <
 '2000/01/01;12:00:00' 1 <
 '2000/01/01;18:00:00' 1.9 <
 '2000/01/02;00:00:00' .8 <
 '2000/01/02;06:00:00' 1.5 <
 '2000/01/02;12:00:00' .6 <
 '2000/01/02;18:00:00' 1.5 <
 '2000/01/03;00:00:00' 0 <
 tble"""
            obj = Object("FLBO id 'lkb_condition_extern' " + table_str + " flbo")
            table = Object(table_str)
            self.assertEqual(obj['TBLE'][0], table)
            pass

    class ReadingListsTest(unittest.TestCase):
        obj1_str = """\
GFLS nc 15 nr 15 x0 135000 y0 456500 dx 100 dy 100 cp 0 fnm '\Sobek210\lizardkb.lit\FIXED\grid\test_hoogte.asc' gfls
"""
        obj2_str = """\
PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12
"""
        obj3_str = """\
PT12 id '5' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12
"""
        domain_str = """\
DOMN id '1' nm '1'
  """ + obj1_str + """
  """ + obj2_str + """
  """ + obj3_str + """
domn"""

        def testDOMN_length(self):
            "DOMN reads that many objects"
            domain = Object(self.domain_str)
            self.assertEqual(len(domain.fields), 4)
            self.assertEqual(len(domain['GFLS']), 1)
            self.assertEqual(len(domain['PT12']), 2)

        def testDOMN_first(self):
            "DOMN reads the first object"
            domain = Object(self.domain_str)
            gfls = Object(self.obj1_str)
            self.assertEqual(domain['GFLS'][0], gfls)

        def testDOMN_last(self):
            "DOMN reads the last object"
            domain = Object(self.domain_str)
            pt12 = Object(self.obj3_str)
            self.assertEqual(domain['PT12'][1], pt12)

    class ReadingFromFile(unittest.TestCase):
        point_1 = "PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12"
        point_2 = "PT12 id '5' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12"
        input_domn = mock.Stream("""\
D121.0
DOMN id '2' nm '1'
domn
DOMN id '1' nm '1'
  GFLS nc 15 nr 15 x0 135000 y0 456500 dx 100 dy 100 cp 0 fnm '\\Sobek210\\lizardkb.lit\\FIXED\\grid\\test_hoogte.asc' gfls
  """ + point_1 + """
  """ + point_2 + """
domn
DOMN id '3' nm '1'
  PT12 id '7' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12
domn
""")
        input_noversion = mock.Stream("""\
GFLS nc 15 nr 15 x0 135000 y0 456500 dx 100 dy 100 cp 0 fnm '\Sobek210\lizardkb.lit\FIXED\grid\test_hoogte.asc' gfls
NODE id '10' ty 1 ws 10000 ss 0 wl -0.89 ml 0 node
PT12 id '7' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12
PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12
""")

        def test01Reading(self):
            "reading three objects from a stream"

            content = File(self.input_domn)
            self.assertEqual(len(content), 3)

        def test02Reading(self):
            "reading one object from a versionless stream"

            content = File(self.input_noversion)
            self.assertEqual(len(content), 4)

        def test11Reading(self):
            "version and extension from source stream"

            content = File(self.input_domn)
            self.assertEqual(content.version, 1.0)
            self.assertEqual(content.extension, 'D12')

        def test12Reading(self):
            "source stream does not have any version information"

            content = File(self.input_noversion)
            self.assertEqual(content.version, None)
            self.assertEqual(content.extension, None)

        def test2GetElement(self):
            "reading a file and selecting an atom"
            network_d12 = File(self.input_domn)
            grid_name = network_d12['DOMN'][1]['GFLS'][0]['fnm'][0]
            self.assertEqual(grid_name, r'\Sobek210\lizardkb.lit\FIXED\grid\test_hoogte.asc')

        def test3GetFirstIteratedElement(self):
            "reading a file and selecting first of two objects with same type"
            network_d12 = File(self.input_domn)
            self.assertEqual(len(network_d12['DOMN'][1]['PT12']), 2)
            self.assertEqual(len(network_d12['DOMN'][2]['PT12']), 1)
            point = network_d12['DOMN'][1]['PT12'][0]
            self.assertEqual(str(point), self.point_1)

        def test4GetSecondIteratedElement(self):
            "reading a file and selecting second of two objects with same type"
            network_d12 = File(self.input_domn)
            point = network_d12['DOMN'][1]['PT12'][1]
            self.assertEqual(str(point), self.point_2)

        def test50(self):
            "reading a file and selecting object by type and id"
            network_d12 = File(self.input_domn)
            self.assertEqual(network_d12['DOMN', '2'], network_d12['DOMN'][0])
            self.assertEqual(network_d12['DOMN', '1'], network_d12['DOMN'][1])
            self.assertEqual(network_d12['DOMN', '3'], network_d12['DOMN'][2])

        def test60(self):
            "iterating in a File is allowed"
            f = File(self.input_domn)
            self.assertEqual(len([i for i in f]), 3)

        def test61(self):
            "iterating in a DOMN is allowed"
            f = File(self.input_domn)
            self.assertEqual(len([0 for i in f['DOMN'][0]]), 0)
            self.assertEqual(len([0 for i in f['DOMN'][1]]), 3)
            self.assertEqual(len([0 for i in f['DOMN'][2]]), 1)

        def test70(self):
            "reading a GFLR containing a BDFR and nothing else"
            txt = "GLFR BDFR id '0' ci '0' mf 0 mt cp 0 0.0000 0 mr cp 0 0.0000 0 s1 6 s2 6 sf 0 st cp 0 0.0000 0 sr cp 0 0.0000 bdfr    glfr"
            f = File(mock.Stream(txt))
            f['GLFR']
            f['GLFR'][0]
            f['GLFR'][0]['BDFR']

    class RepresentingAsText(unittest.TestCase):

        obj0_str = """\
PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 %spt12"""
        obj1_str = """\
PT12 id '2' nm '2' ci '1' lc 0 px 135451.5 py 456366 mc 5 mr 2 %spt12"""
        obj2_str = """\
PT12 id '2' nm '2 bis' ci '1' lc 0 px 135451.5 py 456366 mc 5 mr 2 %spt12"""
        obj2a_str = """\
PT12 id '2' nm '2 bis a' ci '1' lc 0 px 135451.5 py 456366 mc 5 mr 2 %spt12"""

        def test10writing(self):
            "representing unmodified object"
            obj = Object(self.obj0_str % '')
            self.assertEqual(str(obj), self.obj0_str % '')

        def test11writing(self):
            "representing unmodified object - with spaces in string"
            obj = Object(self.obj2_str % '')
            self.assertEqual(str(obj), self.obj2_str % '')

        def test12writing(self):
            "representing modified object - with spaces in string"
            obj = Object(self.obj2_str % '')
            obj['nm'] = '2 bis a'
            self.assertEqual(str(obj), self.obj2a_str % '')

        def test24writing(self):
            "representing modified object (modify single field value)"

            obj = Object(self.obj0_str % '')
            obj['px'][0] = 135451.5
            obj['py'][0] = 456366
            self.assertEqual(str(obj), self.obj1_str % '')

        def test25writing(self):
            "representing modified object (redefine atomic field)"

            obj = Object(self.obj0_str % '')
            obj['px'] = 135451.5
            obj['py'] = 456366
            self.assertEqual(str(obj), self.obj1_str % '')

        def test251writing(self):
            "representing modified object (adding atomic fields)"

            d2li = Object("D2LI id 'id' d2li")
            d2li['bx'] = 125500
            d2li['by'] = 425500
            d2li['ex'] = 135500
            d2li['ey'] = 455500
            self.assertEqual(str(d2li), "D2LI id 'id' bx 125500 by 425500 ex 135500 ey 455500 d2li")

        def test252writing(self):
            "representing modified object (adding list of fields)"

            d2li = Object("D2LI id 'id' d2li")
            d2li['bn'] = [125500, 425500]
            d2li['en'] = [135500, 455500]
            self.assertEqual(str(d2li), "D2LI id 'id' bn 125500 425500 en 135500 455500 d2li")

        def test253writing(self):
            "representing modified object (adding two fields at once)"

            li12 = Object("LI12 id 'id' li12")
            li12['bx'], li12['by'] = [125500, 425500]
            li12['ex'], li12['ey'] = [135500, 455500]
            self.assertEqual(str(li12), "LI12 id 'id' bx 125500 by 425500 ex 135500 ey 455500 li12")

        def test26writing(self):
            "representing modified object (add 'str' field)"

            obj = Object(self.obj0_str % '')
            obj['iets'] = 'waarde'
            self.assertEqual(str(obj), self.obj0_str % "iets 'waarde' ")

        def test270writing(self):
            "representing modified object (add int field)"

            obj = Object(self.obj0_str % '')
            obj['iets'] = 13
            self.assertEqual(str(obj), self.obj0_str % "iets 13 ")

        def test271writing(self):
            "representing modified object (add long field)"

            obj = Object(self.obj0_str % '')
            obj['iets'] = 13401345L
            self.assertEqual(str(obj), self.obj0_str % "iets 13401345 ")

        def test272writing(self):
            "representing modified object (add small float field)"

            obj = Object(self.obj0_str % '')
            obj['iets'] = 13.40
            self.assertEqual(str(obj), self.obj0_str % "iets 13.4 ")

        def test273writing(self):
            "representing modified object (add large float field)"

            obj = Object(self.obj0_str % '')
            obj['iets'] = 9999900000
            try:
                self.assertEqual(str(obj), self.obj0_str % "iets 9.9999e+009 ")
            except AssertionError:
                self.assertEqual(str(obj), self.obj0_str % "iets 9.9999e+09 ")

        def test274writing(self):
            "representing modified object (add huge float field)"

            obj = Object(self.obj0_str % '')
            obj['iets'] = 9.999e+019
            try:
                self.assertEqual(str(obj), self.obj0_str % "iets 9.999e+019 ")
            except AssertionError:
                self.assertEqual(str(obj), self.obj0_str % "iets 9.999e+19 ")

        def test28writing(self):
            "representing modified object (add PDIN field)"

            obj = Object(self.obj0_str % '')
            pdin = Object("PDIN 0 1 '' pdin")
            obj['PDIN'].append(pdin)
            self.assertEqual(str(obj), self.obj0_str % "\nPDIN 0 1 '' pdin ")

        def test3PDIN_no_id(self):
            "representing arrays without an id"
            obj = Object("PDIN 1 2 3 pdin")
            self.assertEqual(str(obj), "PDIN 1 2 3 pdin")
            pass

        def test4FLBO_containedArray(self):
            "representing FLBO with contained array"
            obj_str = "FLBO id 'lkb_condition_extern' ty 0 h_ wt 1 0 0 \nPDIN 0 0 pdin flbo"
            obj = Object(obj_str)
            self.assertEqual(str(obj), obj_str)
            pass

        def test5FLBO_containedTable(self):
            "representing FLBO with contained table"
            table_str = """\
TBLE \n\
'2000/01/01;00:00:00' 1 <
'2000/01/01;06:00:00' 1.5 <
'2000/01/01;12:00:00' 1 <
'2000/01/01;18:00:00' 1.9 <
'2000/01/02;00:00:00' 0.8 <
'2000/01/02;06:00:00' 1.5 <
'2000/01/02;12:00:00' 0.6 <
'2000/01/02;18:00:00' 1.5 <
'2000/01/03;00:00:00' 0 <
tble"""
            obj_str = "FLBO id 'lkb_condition_extern' \n" + table_str + " flbo"
            obj = Object(obj_str)
            self.assertEqual(str(obj), obj_str)

        def test60_printingdatetime(self):
            "can write datetime.datetime objects in tables"

            flbo = Object("FLBO id 'lkb_condition_extern' ty 0 h_ wt 1 0 0 PDIN 0 0 pdin flbo")
            values = {datetime.datetime(2000, 1, 1, 0): 1.2,
                      datetime.datetime(2000, 1, 1, 1): 1.1,
                      datetime.datetime(2000, 1, 1, 2): 1.0,
                      datetime.datetime(2000, 1, 1, 3): 0.7,
                      datetime.datetime(2000, 1, 1, 4): 0.4,
                      }

            for key, value in values.items():
                flbo.addRow([key, value])
            self.assertEqual(str(flbo), """\
FLBO id 'lkb_condition_extern' ty 0 h_ wt 1 0 0 \n\
PDIN 0 0 pdin \n\
TBLE \n\
'2000-01-01;00:00:00' 1.2 <
'2000-01-01;01:00:00' 1.1 <
'2000-01-01;02:00:00' 1 <
'2000-01-01;03:00:00' 0.7 <
'2000-01-01;04:00:00' 0.4 <
tble flbo""")

        def test62_printingtimedelta(self):
            "can write datetime.datetime objects"

            obj = Object("STDS id 'id' nm '' ts '2000/01/01;00:30:00' dt '0:01:00:00' stds")

            obj['ts'] = datetime.datetime(2000, 1, 2, 3, 4, 5)
            self.assertEqual(str(obj), "STDS id 'id' nm '' ts '2000-01-02;03:04:05' dt '0:01:00:00' stds")

        def test63_printingtimedelta(self):
            "can write datetime.timedelta objects, longer than 1 day"

            obj = Object("STDS id 'id' nm '' ts '2000/01/01;00:30:00' dt '0:01:00:00' stds")

            obj['dt'] = datetime.timedelta(1, 43251)
            self.assertEqual(str(obj), "STDS id 'id' nm '' ts '2000/01/01;00:30:00' dt '1:12:00:51' stds")

        def test64_printingtimedelta(self):
            "can write datetime.timedelta objects, shorter than 1 day"

            obj = Object("STDS id 'id' nm '' ts '2000/01/01;00:30:00' dt '0:01:00:00' stds")

            obj['dt'] = datetime.timedelta(0, 43251)
            self.assertEqual(str(obj), "STDS id 'id' nm '' ts '2000/01/01;00:30:00' dt '0:12:00:51' stds")

    class RepresentingFloats(unittest.TestCase):

        def test_excess(self):
            "1.1 (1.1000000000000001) is printed as 1.1"
            self.assertEqual(print_float(1.1), "1.1")

        def test_defect(self):
            "1.4 (1.3999999999999999) is printed as 1.4"
            self.assertEqual(print_float(1.4), "1.4")

        def test_larger(self):
            "135451.113212727 (135451.11321272701)"
            self.assertEqual(print_float(135451.113212727), "135451.113212727")

        def test_smaller(self):
            "0.06 (0.059999999999999998)"
            self.assertEqual(print_float(0.06), "0.06")

    class WritingToFile(unittest.TestCase):

        def test0writing(self):
            "writing a NETWORK.TP - no version"
            input_str = """\
NODE id 'BOEZ_1' nm '' px 134808.891822728 py 456721.97309417 node
BRCH id '6' nm '' bn 'BOEZ_4' en 'BOEZ_2' al 204.961262972225 brch
"""
            sobek = File(mock.Stream(input_str))
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str)

        def test1writing(self):
            "writing a NETWORK.TP - with version"
            input_str = """\
TP_1.0
NODE id 'BOEZ_1' nm '' px 134808.891822728 py 456721.97309417 node
BRCH id '6' nm '' bn 'BOEZ_4' en 'BOEZ_2' al 204.961262972225 brch
"""
            sobek = File(mock.Stream(input_str))
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str)

        def test2writing(self):
            "writing DOMN with more than one included objects of same type"
            input_str = """\
D121.0
DOMN id '2' nm '1' \n\
domn
DOMN id '1' nm '1' \n\
  GFLS nc 15 nr 15 x0 135000 y0 456500 dx 100 dy 100 cp 0 fnm '\\Sobek210\\lizardkb.lit\\FIXED\\grid\\test_hoogte.asc' gfls \n\
  PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12 \n\
  PT12 id '5' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12 \n\
domn
DOMN id '3' nm '1' \n\
  PT12 id '7' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12 \n\
domn
"""
            sobek = File(mock.Stream(input_str))
            self.assertEqual(len(sobek['DOMN'][1]['PT12']), 2)
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str)

        def test3writing(self):
            "reading empty DOMN and writing it after adding one PT12"
            input_str = """\
D121.0
DOMN id '2' nm '1' %s
domn
"""
            pt_str = """
  PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12 """

            sobek = File(mock.Stream(input_str % ''))
            self.assertEqual(sobek['DOMN'][0]['PT12'], [])
            sobek['DOMN'][0].addObject(Object(pt_str))
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str % pt_str)

        def test40writing(self):
            "reading empty DOMN and writing it after adding two PT12"
            input_str = """\
D121.0
DOMN id '2' nm '1' %s
domn
"""
            pt_str = """
  PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12 """

            sobek = File(mock.Stream(input_str % ''))
            self.assertEqual(sobek['DOMN'][0]['PT12'], [])
            sobek['DOMN'][0].addObject(Object(pt_str))
            sobek['DOMN'][0].addObject(Object(pt_str))
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str % (pt_str * 2))

        def test41(self):
            "writing DOMN with GRID with TBLE"
            expect = """\
DOMN id 'id' \n\
  GRID id 'id' \n\
  TBLE \n\
  1 2 3 <
  1 2 3 <
  tble grid \n\
domn"""
            domn = Object(tag='DOMN', id='id')
            grid = domn.addObject(Object(tag='GRID', id='id'))
            grid.addRow([1, 2, 3])
            grid.addRow([1, 2, 3])
            self.assertEqual(str(domn), expect)

        def test5writing(self):
            "reading and writing a NETWORK.GR"
            input_str = """\
GR_1.1
GRID id '1' ci '1' gr gr 'GridPoint Table' \n\
PDIN 0 0 '' pdin CLTT 'Location' '1/R' cltt CLID '' '' clid \n\
TBLE \n\
0 0 '' '2' '1' 135451.113212727 456364.531129484 <
99.1349688238926 0 '1' '5' '4' 135352.060094798 456360.503490938 <
199.443229780832 0 '4' '6' '5' 135253.892598708 456340.348467165 <
381.75081351349 0 '5' '19' '17' 135248.677965555 456162.71307676 <
612.922174526211 0 '15' '23' '21' 135249.438818165 455931.542967845 <
784.754497959803 0 '11' '10' '9' 135250.004368634 455759.71157511 <
974.405728092209 0 '9' '20' '18' 135250.628566341 455570.061372189 <
1188.8456835183 0 '14' '21' '19' 135251.334350998 455355.622578238 <
1403.21641321846 0 '16' '22' '20' 135252.039907812 455141.253009638 <
1505.92919162709 0 '20' '8' '7' 135267.300230805 455054.47672909 <
1577.18307555953 0 '7' '9' '8' 135338.415507777 455058.918953381 <
1694.41879530824 0 '8' '3' '' 135455.423174178 455066.227851273 <
tble grid
GRID id '2' ci '2' gr gr 'GridPoint Table' \n\
PDIN 0 0 '' pdin CLTT 'Location' '1/R' cltt CLID '' '' clid \n\
TBLE \n\
0 0 '' '3' '2' 135455.423174178 455066.227851273 <
196.965217438059 0 '12' '11' '10' 135473.319683645 455241.69159442 <
391.97895625292 0 '10' '4' '' 135650.055480615 455159.260918116 <
tble grid
GRID id '3' ci '3' gr gr 'GridPoint Table' \n\
PDIN 0 0 '' pdin CLTT 'Location' '1/R' cltt CLID '' '' clid \n\
TBLE \n\
0 0 '' '3' '3' 135455.423174178 455066.227851273 <
111.679498816059 0 '3' '7' '6' 135556.183537484 455114.390696312 <
215.724097483806 0 '13' '4' '' 135650.055480615 455159.260918116 <
tble grid
GRID id 'lkb_grid' ci 'lkb_breach' gr gr 'GridPointTable' \n\
PDIN 0 0 '' pdin CLTT 'Location' '1/R' cltt CLID '' '' clid \n\
TBLE \n\
0 0 '' 'lkb_extern' '23' 134838 455760 <
412.004469957 0 '23' '10' '' 135250.004368634 455759.71157511 <
tble grid
"""
            sobek = File(mock.Stream(input_str))
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str)

        def test6writing(self):
            "writing a NODE.DAT - one object, no version"
            input_str = """\
NODE id '10' ty 1 ws 10000 ss 0 wl -0.89 ml 0 node
"""
            sobek = File(mock.Stream(input_str))
            output = mock.Stream()
            sobek.writeToStream(output)
            self.assertEqual(''.join(output.content), input_str)

        def test70writing(self):
            "writing a sobek.File to a zip archive gives CRLF line terminators"
            input_str = """\
NODE id '10' ty 1 ws 10000 ss 0 wl -0.89 ml 0 node
"""
            sobek = File(mock.Stream(input_str))
            output = mock.ZipFile()
            sobek.basename = "n1.nod"
            sobek.writeToStream(output)
            sobek.basename = "n2.nod"
            sobek.writeToStream(output)
            output_withCRLF = (input_str + input_str).replace('\n', '\r\n')
            self.assertEqual(''.join(output.content), output_withCRLF)
            self.assertEqual(output.namelist(), ['n1.nod', 'n2.nod'])

        def test71writing(self):
            "writing a sobek.Verbatim to a zip archive"
            input_str = "ND d'0 y1w 00 s0w 08 l0nd"
            sobek = Verbatim(mock.Stream(input_str))
            output = mock.ZipFile()
            sobek.basename = "f1"
            sobek.writeToStream(output)
            sobek.basename = "f2"
            sobek.writeToStream(output)
            self.assertEqual(output.namelist(), ['f1', 'f2'])
            self.assertEqual(''.join(output.content), input_str + input_str)

    class AddingRowsToATable(unittest.TestCase):
        input_str = "TBLE tble"
        values = [['2000/01/01;00:00:00', 1],
                  ['2000/01/01;06:00:00', 1.9],
                  ['2000/01/01;12:00:00', 0.87],
                  ['2000/01/01;18:00:00', 2.1],
                  ]
        tble_str = """\
TBLE \n\
'2000/01/01;00:00:00' 1 <
'2000/01/01;06:00:00' 1.9 <
'2000/01/01;12:00:00' 0.87 <
'2000/01/01;18:00:00' 2.1 <
tble"""
        named_values = [['0', 1],
                        ['4', 1.9],
                        ['5', 0.87],
                        ['8', 2.1],
                        ]
        named_tble_str = {None: """\
TBLE %s 4 \n\
'0' 1 <
'4' 1.9 <
'5' 0.87 <
'8' 2.1 <
tble""",
                          2: """\
TBLE %s 4 \n\
'0' 1 <
'4' 1.9 <
'5' 0.87 <
'8' 2.1 <
tble""",
                          1: """\
TBLE %s 4 \n\
'0' 1 <
'4' 1.9 <
'5' 0.9 <
'8' 2.1 <
tble""",
                          0: """\
TBLE %s 4 \n\
'0' 1 <
'4' 2 <
'5' 1 <
'8' 2 <
tble""",
                          }
        obj_str = """\
FLBO id 'lkb_condition_extern' ty 0 h_ wt 1 0 0 %sflbo"""

        def test1writing(self):
            "adding values to unnamed table 'by hand'"
            obj = Object(self.input_str)
            for d, v in self.values:
                obj['TBLE'].append(d)
                obj['TBLE'].append(v)
                obj['TBLE'].append('<')
            self.assertEqual(str(obj), self.tble_str)

        def test2writing(self):
            "adding values to unnamed table using the addRow utility function"
            obj = Object(self.input_str)
            for d, v in self.values:
                obj.addRow((d, v))
            self.assertEqual(str(obj), self.tble_str)

        def test4writing(self):
            "addRow without TBLE allowing addition"
            obj = Object(self.obj_str % '')
            for d, v in self.values:
                obj.addRow((d, v))
            self.assertEqual(str(obj), self.obj_str % ('\n' + reindent(self.tble_str) + ' '))

        def test6writing(self):
            "addRow without TBLE not allowing addition causes error"
            obj = Object(self.obj_str % '')
            for d, v in self.values:
                self.assertRaises(AttributeError, obj.addRow, (d, v), False)

        def test7writing(self):
            "addRow with TBLE without addition"
            obj = Object(self.obj_str % 'TBLE tble ')
            for d, v in self.values:
                obj.addRow((d, v), False)
            self.assertEqual(str(obj), self.obj_str % ('\n' + reindent(self.tble_str) + ' '))

        def test80_named(self):
            "addRow to named TBLE - adding table"
            obj = Object(self.obj_str % '')
            for d, v in self.named_values:
                obj.addRow((d, v), to_table='cells')
            self.assertEqual(str(obj), self.obj_str % ('\n' + reindent(self.named_tble_str[None] % 'cells') + ' '))

        def test82_named(self):
            "addRow to named TBLE - adding second table"
            obj = Object(self.obj_str % '')
            for d, v in self.named_values:
                obj.addRow((d, v), to_table='cells')
            for d, v in self.named_values:
                obj.addRow((d, v), to_table='other')
            repr1 = '\n' + reindent(self.named_tble_str[None] % 'cells') + ' '
            repr2 = '\n' + reindent(self.named_tble_str[None] % 'other') + ' '
            self.assertEqual(str(obj), self.obj_str % (repr1 + repr2))

        def test90_named(self):
            "reading back named TBLE"
            obj = Object(tag='TBLE', name='cells')
            for d, v in self.named_values:
                obj.addRow((d, v))
            obj2 = Object(str(obj))
            self.assertEqual(obj.fields, obj2.fields)
            self.assertEqual(str(obj2), str(obj))

        def test91_named(self):
            "reading back an object with one named TBLE"
            obj = Object(self.obj_str % '')
            for d, v in self.named_values:
                obj.addRow((d, v), to_table='cells')
            self.assertEqual(str(obj), self.obj_str % ('\n' + reindent(self.named_tble_str[None] % 'cells') + ' '))
            obj2 = Object(str(obj))
            self.assertEqual(obj.fields, obj2.fields)
            self.assertEqual(str(obj2), str(obj))

        def test92_named(self):
            "reading back an object with two named TBLEs"
            obj = Object(self.obj_str % '')
            for d, v in self.named_values:
                obj.addRow((d, v), to_table='cells')
            for d, v in self.named_values:
                obj.addRow((d, v), to_table='other')
            repr1 = ('\n' + reindent(self.named_tble_str[None] % 'cells') + ' ')
            repr2 = ('\n' + reindent(self.named_tble_str[None] % 'other') + ' ')
            self.assertEqual(str(obj), self.obj_str % (repr1 + repr2))
            obj2 = Object(str(obj))
            self.assertEqual(obj.fields, obj2.fields)
            self.assertEqual(str(obj2), str(obj))

        def test930_named(self):
            "addRow to named TBLE - specifying decimal places"
            for decs in [None, 2, 1, 0]:
                obj = Object(self.obj_str % '')
                for d, v in self.named_values:
                    obj.addRow((d, v), to_table='cells', decimals=decs)
                self.assertEqual(str(obj), self.obj_str % ('\n' + reindent(self.named_tble_str[decs] % 'cells') + ' '))

    class AddingObjectsToFiles(unittest.TestCase):

        input_str = """\
D121.0
DOMN id '1' nm '1'
domn
"""

        def test1(self):
            "reading file and adding one object - append"

            f = File(mock.Stream(self.input_str))
            self.assertEqual(len(f), 1)
            f.append(Object(tag='DOMN', id='2'))
            self.assertEqual(len(f), 2)

        def test2(self):
            "reading file and adding one object - addObject"

            f = File(mock.Stream(self.input_str))
            self.assertEqual(len(f), 1)
            f.addObject(Object(tag='DOMN', id='2'))
            self.assertEqual(len(f), 2)

        def test3(self):
            "reading file, adding one object, retrieving it by id"

            f = File(mock.Stream(self.input_str))
            self.assertEqual(len(f), 1)
            obj = Object(tag='DOMN', id='2')
            f.addObject(obj)
            self.assertEqual(len(f), 2)
            self.assertEqual(f['DOMN', '2'], obj)

        def test4(self):
            "altering object id, retrieving it by new id"

            f = File(mock.Stream(self.input_str))
            obj = f['DOMN', '1']
            obj['id'] = '2'
            self.assertEqual(f['DOMN', '2'], obj)

        def test5(self):
            "altering object id (list), retrieving it by new id"

            f = File(mock.Stream(self.input_str))
            obj = f['DOMN', '1']
            obj['id'] = ['id']
            self.assertEqual(f['DOMN', 'id'], obj)

    class VerbatimDoesNothing(unittest.TestCase):

        def test0(self):
            "reading a Verbatim file does not cause errors"
            f = Verbatim(mock.Stream("abcde\n\naaa"))
            self.assertTrue(f != None)

        def test1(self):
            "writing a Verbatim file gets you the input verbatim"
            f = Verbatim(mock.Stream("abcde\n\naaa"))
            output = mock.Stream()
            f.writeToStream(output)
            self.assertEqual(''.join(output.content), "abcde\n\naaa")

        def test2(self):
            "iterating in a Verbatim file gives the empty list"
            f = Verbatim(mock.Stream("abcde"))
            self.assertEqual([i for i in f], [])

        def test3(self):
            "appending to a Verbatim file gives NotImplementedError"
            f = Verbatim(mock.Stream("abcde"))
            self.assertRaises(NotImplementedError, f.append, '1')

    class DictionaryLikeAccess(unittest.TestCase):
        input_noversion = mock.Stream("""\
GFLS nc 15 nr 15 x0 135000 y0 456500 dx 100 dy 100 cp 0 fnm '\Sobek210\lizardkb.lit\FIXED\grid\test_hoogte.asc' gfls
NODE id '10' ty 1 ws 10000 ss 0 wl -0.89 ml 0 node
PT12 id '7' nm '5' ci '1' lc 99.1349688238926 px 135352.060094798 py 456360.503490938 mc 4 mr 2 pt12
PT12 id '2' nm '2' ci '1' lc 0 px 135451.113212727 py 456364.531129484 mc 5 mr 2 pt12
GRID id '1' ci '1' gr gr 'GridPointTable'
PDIN 0 0 '' pdin CLTT 'Location' '1/R' cltt CLID '' '' clid
TBLE \n\
0 0 '' '2' '1' 135451.113212727 456364.531129484 <
99.1349688238926 0 '1' '5' '4' 135352.060094798 456360.503490938 <
199.443229780832 0 '4' '6' '5' 135253.892598708 456340.348467165 <
tble grid
""")

        def test0(self):
            "get base objects by type - existing gives list"
            f = File(self.input_noversion)
            self.assertEqual(len(f['PT12']), 2)
            self.assertEqual(len(f['NODE']), 1)
            self.assertEqual(len(f['GFLS']), 1)

        def test1(self):
            "get base objects by type - not existing gives empty list"
            f = File(self.input_noversion)
            self.assertEqual(len(f['DOMN']), 0)

        def test2(self):
            "get list of types of base objects"
            f = File(self.input_noversion)
            self.assertEqual(f.keys(), ['GFLS', 'NODE', 'GRID', 'PT12'])

        def test3(self):
            "asking by integer index in File gives i-th contained object"
            f = File(self.input_noversion)
            self.assertEqual(f[0].tag, 'GFLS')
            self.assertEqual(f[1].tag, 'NODE')
            self.assertEqual(f[2].tag, 'PT12')
            self.assertEqual(f[3].tag, 'PT12')
            self.assertEqual(f[4].tag, 'GRID')
            self.assertRaises(IndexError, f.__getitem__, 5)

        def test31(self):
            "asking by integer index in Object gives i-th included object"
            f = File(self.input_noversion)
            self.assertEqual(f['GRID', '1'][0].tag, 'PDIN')
            self.assertEqual(f['GRID', '1'][1].tag, 'CLTT')
            self.assertEqual(f['GRID', '1'][2].tag, 'CLID')
            self.assertEqual(f['GRID', '1'][3].tag, 'TBLE')
            self.assertRaises(IndexError, f['GRID', '1'].__getitem__, 4)

        def test4(self):
            "asking impossible sobek name gives ValueError"
            f = File(self.input_noversion)
            self.assertRaises(ValueError, f.__getitem__, "no")

        def test5(self):
            "asking lower case sobek name gives upper case answer"
            f = File(self.input_noversion)
            self.assertEqual(f['domn'], f['DOMN'])
            self.assertEqual(f['pt12'], f['PT12'])

    class ReadingAndAlteringTables(unittest.TestCase):
        input_str = "TBLE tble"
        values = [
            [0, 0, '', 'c_BOEZ_1', 'c_17', 134808.891822728, 456721.97309417, ],
            [188.779056149839, 0, 'c_17', 'c_BOEZ_5', 'c_20', 134997.326506, 456710.575630373, ],
            [505.605005395534, 0, 'c_25', 'c_BOEZ_6', 'c_21', 135313.574497785, 456691.44738405, ],
            [779.884026046477, 0, 'c_21', 'c_BOEZ_2', '', 135587.353175561, 456674.887892377, ],
            ]
        tble_str = """\
TBLE \n\
0 0 '' 'c_BOEZ_1' 'c_17' 134808.891822728 456721.97309417 <
188.779056149839 0 'c_17' 'c_BOEZ_5' 'c_20' 134997.326506 456710.575630373 <
505.605005395534 0 'c_25' 'c_BOEZ_6' 'c_21' 135313.574497785 456691.44738405 <
779.884026046477 0 'c_21' 'c_BOEZ_2' '' 135587.353175561 456674.887892377 <
tble"""
        obj_str = """\
FLBO id 'lkb_condition_extern' ty 0 h_ wt 1 0 0 %sflbo"""

        def test0(self):
            "TBLE contains list of values accessible by pair of coordinates"
            t = Object(self.tble_str)
            self.assertEqual(t.fields['TBLE'],
                             [0, 0, '', 'c_BOEZ_1', 'c_17', 134808.89182272801, 456721.97309416998, '<',
                              188.77905614983899, 0, 'c_17', 'c_BOEZ_5', 'c_20', 134997.32650600001, 456710.57563037297, '<',
                              505.60500539553402, 0, 'c_25', 'c_BOEZ_6', 'c_21', 135313.57449778501, 456691.44738405, '<',
                              779.88402604647695, 0, 'c_21', 'c_BOEZ_2', '', 135587.353175561, 456674.88789237698, '<',
                              ])

        def test10(self):
            "getting info from the first row of a TBLE"
            t = Object(self.tble_str)
            self.assertEqual(t[0, 0], 0)
            self.assertEqual(t[0, 1], 0)
            self.assertEqual(t[0, 2], '')
            self.assertEqual(t[0, 3], 'c_BOEZ_1')
            self.assertEqual(t[0, 4], 'c_17')
            self.assertEqual(t[0, 5], 134808.891822728)
            self.assertEqual(t[0, 6], 456721.97309417)

        def test15(self):
            "setting info into the first row of a TBLE"
            t = Object(self.tble_str)
            t[0, 3] = "c_1"
            t[0, 4] = "c_2"
            self.assertEqual(t[0, 0], 0)
            self.assertEqual(t[0, 1], 0)
            self.assertEqual(t[0, 2], '')
            self.assertEqual(t[0, 3], 'c_1')
            self.assertEqual(t[0, 4], 'c_2')
            self.assertEqual(t[0, 5], 134808.891822728)
            self.assertEqual(t[0, 6], 456721.97309417)

        def test2(self):
            "accessing by tuple into a non-TBLE gives ValueError"
            nt = Object(self.obj_str % '')
            self.assertRaises(ValueError, nt.__getitem__, (0, 0))

        #def test3(self):
        #    "accessing by non-tuple into a TBLE gives ValueError"
        #    t = Object(self.tble_str)
        #    self.assertRaises(ValueError, t.__getitem__, "")
        #    self.assertRaises(ValueError, t.__getitem__, 0)

        def test4(self):
            "accessing out of range -by row- in a TBLE gives KeyError"
            t = Object(self.tble_str)
            self.assertRaises(KeyError, t.__getitem__, (7, 0))

        def test41(self):
            "accessing out of range -by col- in a TBLE gives KeyError"
            t = Object(self.tble_str)
            self.assertRaises(KeyError, t.__getitem__, (0, 25))

        def test42(self):
            "accessing the '<' of a TBLE gives KeyError"
            t = Object(self.tble_str)
            self.assertRaises(KeyError, t.__getitem__, (0, 7))
            self.assertRaises(KeyError, t.__getitem__, (1, 7))
            self.assertRaises(KeyError, t.__getitem__, (2, 7))

        def test50(self):
            "initialize an empty TBLE specifying the column count"
            t = Object(tag='TBLE', id='44', cols=6)
            self.assertEqual(t.cols(), 6)

        def test52(self):
            "initialize an empty TBLE without specifying the column count"
            t = Object(tag='TBLE', id='44')
            self.assertEqual(t.cols(), None)

        def test54(self):
            "empty TBLE without column count infers it from addRow data"
            t = Object(tag='TBLE', id='44')
            self.assertEqual(t.cols(), None)
            t.addRow([1, 2, 3])
            self.assertEqual(t.cols(), 3)

        def test56(self):
            "TBLE accepts addRow data with correct amount of columns"
            t = Object(tag='TBLE', id='44')
            self.assertEqual(t.cols(), None)
            t.addRow([1, 2, 3])
            self.assertEqual(t.cols(), 3)
            t.addRow([1, 2, 3])

        def test58(self):
            "TBLE addRow with wrong amount of columns raises ValueError"
            t = Object(tag='TBLE', id='44', cols=3)
            self.assertRaises(ValueError, t.addRow, [1, 2, 3, 4])

        def test582(self):
            "TBLE addRow and read new entries by tuple"
            t = Object(tag='TBLE', id='44')
            self.assertEqual(t.cols(), None)
            t.addRow([1, 2, 3])
            self.assertEqual(t[0, 0], 1)
            self.assertEqual(t[0, 1], 2)
            self.assertEqual(t[0, 2], 3)
            t.addRow([4, 5, 6])
            self.assertEqual(t[1, 0], 4)
            self.assertEqual(t[1, 1], 5)
            self.assertEqual(t[1, 2], 6)

        def test584(self):
            "TBLE addRow and alter entries by tuple"
            t = Object(tag='TBLE', id='44')
            self.assertEqual(t.cols(), None)
            t.addRow([1, 2, 3])
            t.addRow([4, 5, 6])
            t.addRow([4, 5, 6])
            t[2, 0] = 7
            t[2, 1] = 8
            t[2, 2] = 9
            self.assertEqual(t[0, 0], 1)
            self.assertEqual(t[0, 1], 2)
            self.assertEqual(t[0, 2], 3)
            self.assertEqual(t[1, 0], 4)
            self.assertEqual(t[1, 1], 5)
            self.assertEqual(t[1, 2], 6)
            self.assertEqual(t[2, 0], 7)
            self.assertEqual(t[2, 1], 8)
            self.assertEqual(t[2, 2], 9)

        def test586(self):
            "TBLE addRow and alter entries by tuple - prints new values"
            t = Object(tag='TBLE')
            t.addRow([1, 2, 3])
            t.addRow([4, 5, 6])
            t.addRow([4, 5, 6])
            t[2, 0] = 7
            t[2, 1] = 8
            t[2, 2] = 9
            self.assertEqual(str(t), """\
TBLE \n\
1 2 3 <
4 5 6 <
7 8 9 <
tble""")

        def test600(self):
            "TBLE counting rows from empty"
            t = Object(tag='TBLE')
            t.addRow([1, 2, 3])
            self.assertEqual(t.rows(), 1)
            t.addRow([4, 5, 6])
            self.assertEqual(t.rows(), 2)
            t.addRow([4, 5, 6])
            self.assertEqual(t.rows(), 3)

        def test601(self):
            "TBLE counting rows from input string"
            t = Object('TBLE 1 2 3 < 2 2 2 < tble')
            self.assertEqual(t.rows(), 2)

        def test610(self):
            "empty TBLE has 0 rows"
            t = Object(tag='TBLE', cols=5)
            self.assertEqual(t.rows(), 0)

        def test620(self):
            "empty TBLE not knowing about its shape has 0 rows"
            t = Object(tag='TBLE')
            self.assertEqual(t.rows(), 0)

        def test650(self):
            "not TBLE raises AttributeError when asking rows count"
            t = Object(tag='DOMN')
            self.assertRaises(AttributeError, t.rows)

    class VerbatimFunctions(unittest.TestCase):
        "a few functions available in Verbatim objects"

        def test01replace(self):
            "replace a substring in a Verbatim object"
            f = Verbatim(mock.Stream("abcde"))
            f.replace("bcd", "123")
            output = mock.Stream()
            f.writeToStream(output)
            self.assertEqual(''.join(output.content), "a123e")

        def test02(self):
            "Verbatim file-like behaviour: truncate to 0"
            f = Verbatim(mock.Stream("abcde\n12345\nxyzt"))
            f.truncate(0)
            output = mock.Stream()
            f.writeToStream(output)
            self.assertEqual(''.join(output.content), "")

        def test030(self):
            "Verbatim file-like behaviour: truncate to nonzero raises ValueError"
            f = Verbatim(mock.Stream("abcde\n12345\nxyzt"))
            self.assertRaises(ValueError, f.truncate, 1)

        def test031(self):
            "Verbatim file-like behaviour: truncate and extend"
            f = Verbatim(mock.Stream("abcde\nabcde\n12345\nxyzt\n"))
            f.truncate(0)
            f.write('test')
            output = mock.Stream()
            f.writeToStream(output)
            self.assertEqual(''.join(output.content), "test")

        def test04(self):
            "Verbatim file-like behaviour: write adds to end of buffer"
            f = Verbatim(mock.Stream("abcde\n"))
            output = mock.Stream()
            f.writeToStream(output)
            self.assertEqual(''.join(output.content), "abcde\n")
            f.write("12345\nxyzt")
            output = mock.Stream()
            f.writeToStream(output)
            self.assertEqual(''.join(output.content), "abcde\n12345\nxyzt")

        def test05(self):
            "Verbatim file-like behaviour: can retrieve content using readline"
            f = Verbatim(mock.Stream("abcde\nabcde\n12345\nxyzt\n"))
            self.assertEqual(f.readline(), 'abcde\n')
            self.assertEqual(f.readline(), 'abcde\n')
            self.assertEqual(f.readline(), '12345\n')
            self.assertEqual(f.readline(), 'xyzt\n')

    class DeletingItemsFromFile(unittest.TestCase):
        "it is possible to remove items from a sobek.File"
        input = mock.Stream("""\
GLIN fi 0 fr '(null)'
FLIN nm '' ss 0 id '-1' ci '-1' lc 999990 q_ lq 0 0 999990 ty 1 lv ll 0 44 999990 flin glin
FLIN nm 'initial' ss 0 id '1' ci '1' lc 999990 q_ lq 0 0 999990 ty 1 lv ll 0 -0.2 999990 flin
FLIN nm 'initial' ss 0 id '2' ci '2' lc 999990 q_ lq 0 0 999990 ty 1 lv ll 0 -0.2 999990 flin
FLIN nm 'initial' ss 0 id '3' ci '3' lc 999990 q_ lq 0 0 999990 ty 1 lv ll 0 -0.2 999990 flin
""")

        def test01(self):
            "delete one item by type and number - existing"
            f = File(self.input)
            flins = len(f['FLIN'])
            del f['FLIN', 0]
            self.assertEqual(len(f['FLIN']), flins - 1)

        def test02(self):
            "delete one item by type and number - out of range - IndexError"
            f = File(self.input)
            self.assertRaises(IndexError, f.__delitem__, ('FLIN', 5))

        def test03(self):
            "delete one item by type and id - existing"
            f = File(self.input)
            flins = len(f['FLIN'])
            del f['FLIN', '2']
            self.assertEqual(len(f['FLIN']), flins - 1)

        def test04(self):
            "delete one item by type and id - not existing - KeyError"
            f = File(self.input)
            self.assertRaises(KeyError, f.__delitem__, ('FLIN', '4'))

        def test05(self):
            "delete all items by type - existing or not - ValueError"
            f = File(self.input)
            self.assertRaises(ValueError, f.__delitem__, 'FLIN')
            self.assertRaises(ValueError, f.__delitem__, 'NOPE')

    class CreatingFileFromScratch(unittest.TestCase):
        def test01(self):
            "create File object without a source"
            f = File(None)
            self.assertTrue(f != None)

        def test11(self):
            "create File object from non existing file"
            f = File('struct.def')
            self.assertTrue(f != None)

    class NoneValuesAreConvertedInOutput(unittest.TestCase):
        def test01(self):
            "a field receiving None stores it using a global setting"
            f = Object("PT12 id '2' nm '2' ci '1' lc 0 pt12")
            f['mc'] = None
            self.assertEqual(f['mc'], [NoneValue])

        def test02(self):
            "a field receiving '' stores it verbatim"
            f = Object("PT12 id '2' nm '2' ci '1' lc 0 pt12")
            f['mc'] = ''
            self.assertEqual(f['mc'], [''])

    class ReadingAttributesWithDoubleName(unittest.TestCase):
        def test01(self):
            "can read a sobek string with long attribute names"
            f = Object("STFR id 'fr_KBR_1' mf 1 mt cp 0 71 mr cp 71 s1 6 s2 6 sf 1 st cp 71 sr cp 71 stfr")
            self.assertEqual(f['mf'], [1])
            self.assertEqual(f['mt cp'], [0, 71])
            self.assertEqual(f['mr cp'], [71])

    class Ticket319(unittest.TestCase):
        input_no_seps = "D121.0|DOMN id 'Dummy9' nm 'Dummy9' |  GFLS nc 31 nr 36 x0 124878.21251062 y0 486580.70841546 dx 25 dy 25 cp 0 fnm '../WORK/grid/ahn25_dm.asc' gfls |  PT12 id '1' nm '1' ci '' lc 0 px 125230.9669999 py 486354.027000174 mc 15 mr 10 pt12|  PT12 id '183647_1' nm '183647_1' ci '183647' lc 34.3695294843414 px 125253.704736949 py 486379.622994496 mc 16 mr 9 pt12|  PT12 id '183647_2' nm '183647_2' ci '183647' lc 68.7390589695179 px 125276.126426661 py 486405.671563959 mc 16 mr 8 pt12|domn"

        def test01(self):
            "reading versioned file with line separators DOS style"

            f = File(mock.Stream(self.input_no_seps.replace('|', '\n\r')))
            self.assertEqual(f.keys(), ['DOMN'])

        def test02(self):
            "reading versioned file with line separators unix style"

            f = File(mock.Stream(self.input_no_seps.replace('|', '\r')))
            self.assertEqual(f.keys(), ['DOMN'])

        def test03(self):
            "reading versioned file with line separators Mac style"

            f = File(mock.Stream(self.input_no_seps.replace('|', '\n')))
            self.assertEqual(f.keys(), ['DOMN'])

    class HISFileFunctions(unittest.TestCase):
        input = 'SOBEK                                   History at calculation points           TITLE :Model_BG                         T0: 2000.01.01 00:00:00  (scu=      20s)\x01\x00\x00\x00\x02\x00\x00\x00     Waterdepth  (m)\x01\x00\x00\x00183184_8            \x02\x00\x00\x00183190_22           \x00\x00\x00\x00\x85\xeb\xd1\xbe\\\x8f\x02\xbf\x84\x03\x00\x00\xaeG\xe1\xbe\x00\x00\x00\xbf\x08\x07\x00\x00ff\xe6\xbe\\\x8f\x02\xbf'

        def test01(self):
            "HISFile: reading file"

            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.dtstart, datetime.datetime(2000, 1, 1))
            self.assertEqual(f.nrof_parameters, 1)
            self.assertEqual(f.nrof_locations, 2)
            self.assertEqual(f.locations(), ['183184_8', '183190_22'])
            self.assertEqual(f.parameters(), ['Waterdepth  (m)'])
            self.assertEqual(f.size(), 3)

        def test03(self):
            "HISFile: get_values for one location/parameter"
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_values('183184_8', 'Waterdepth  (m)'), [-0.41, -0.44, -0.45])

        def test05(self):
            "HISFile: get_timestamps for one location/parameter"
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_timestamps(),
                             [datetime.datetime(2000, 1, 1, 0, 0, 0),
                              datetime.datetime(2000, 1, 1, 5, 0, 0),
                              datetime.datetime(2000, 1, 1, 10, 0, 0),
                              ])

        def test07(self):
            "HISFile: get_timeseries for one location/parameter, complete"
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_timeseries('183184_8', 'Waterdepth  (m)'),
                             {datetime.datetime(2000, 1, 1, 0, 0): -0.41,
                              datetime.datetime(2000, 1, 1, 5, 0): -0.44,
                              datetime.datetime(2000, 1, 1, 10, 0): -0.45})

        def test09(self):
            "HISFile: get_timeseries for one location/parameter, from second"
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_timeseries('183184_8', 'Waterdepth  (m)', 946684801),
                             {datetime.datetime(2000, 1, 1, 5, 0): -0.44,
                              datetime.datetime(2000, 1, 1, 10, 0): -0.45})

        def test11(self):
            "HISFile: get_timeseries for one location/parameter, from datetime.datetime"
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_timeseries('183184_8', 'Waterdepth  (m)', datetime.datetime(2000, 1, 1, 6, 0)),
                             {datetime.datetime(2000, 1, 1, 10, 0): -0.45})

        def test15(self):
            "HISFile: get_timeseries as a list of tuples"
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_timeseries('183184_8', 'Waterdepth  (m)', datetime.datetime(2000, 1, 1, 6, 0), result_type=list),
                             [(datetime.datetime(2000, 1, 1, 10, 0), -0.45)])

        def test51(self):
            "HISFile: get_timeseries for imprecise location/parameter issues warning"
            handler.flush()
            f = HISFile(mock.Stream(self.input))
            self.assertEqual(f.get_timeseries('183184_8', 'Waterdepth'),
                             {datetime.datetime(2000, 1, 1, 0, 0): -0.41,
                              datetime.datetime(2000, 1, 1, 5, 0): -0.44,
                              datetime.datetime(2000, 1, 1, 10, 0): -0.45})
            self.assertEqual(handler.content, ["nens.sobek|WARNING|you asked for parameter 'Waterdepth', you got 'Waterdepth  (m)'."])

    class NetworkDecoding(unittest.TestCase):
        input_str = '''\
"NTW6.6","C:\SOBEK211\TAUW.lit\CMTWORK\ntrpluv.ini","SOBEK-LITE-3B, edit network"
"WL_351_1","WL_351_1",1,1,"SBK_CHANNEL","",0,0,0,0,85.3504190152846,0,0,0,"4","","",1,12,"SBK_CHANNELCONNECTION","",181252.9,488342.074,0,0,"SYS_DEFAULT",0,"LOC_R40","LOC_R40","",1,20,"SBK_PROFILE","",181315.478165453,488379.054838942,0,85.3504190152846,"SYS_DEFAULT",0
"WL_353_1","WL_353_1",2,1,"SBK_CHANNEL","",0,0,0,0,24.0902312151046,0,0,0,"7","","",2,12,"SBK_CHANNELCONNECTION","",181753.474,488714.798,0,0,"SYS_DEFAULT",0,"LOC_201","LOC_201","",2,20,"SBK_PROFILE","",181737.652,488732.964,0,24.0902312151046,"SYS_DEFAULT",0
"WL_354_1","WL_354_1",3,1,"SBK_CHANNEL","",0,0,0,0,18.3010214195775,0,0,0,"5","","",0,12,"SBK_CHANNELCONNECTION","",181724.76,488753.474,0,0,"SYS_DEFAULT",0,"LOC_D01","LOC_D01","",3,20,"SBK_PROFILE","",181731.773,488770.378,0,18.3010214195775,"SYS_DEFAULT",0
"WL_355_1","WL_355_1",4,1,"SBK_CHANNEL","",0,0,0,0,.612875094882207,0,0,0,"8","","",0,12,"SBK_CHANNELCONNECTION","",181825.397,488850.43,0,0,"SYS_DEFAULT",0,"LOC_203","LOC_203","",4,20,"SBK_PROFILE","",181825.893202299,488850.789720948,0,.612875094882207,"SYS_DEFAULT",0
"WL_356_1","WL_356_1",5,1,"SBK_CHANNEL","",0,0,0,0,.568225085529253,0,0,0,"8","","",0,12,"SBK_CHANNELCONNECTION","",181825.397,488850.43,0,0,"SYS_DEFAULT",0,"LOC_202","LOC_202","",5,20,"SBK_PROFILE","",181825.965013713,488850.414502591,0,.568225085529253,"SYS_DEFAULT",0
"WL_357_1","WL_357_1",6,1,"SBK_CHANNEL","",0,0,0,0,.350844684788141,0,0,0,"9","","",0,12,"SBK_CHANNELCONNECTION","",181826.844,488851.479,0,0,"SYS_DEFAULT",0,"LOC_D21","LOC_D21","",6,20,"SBK_PROFILE","",181827.128049734,488851.6849314,0,.350844684788141,"SYS_DEFAULT",0
"WL_355_s1","",4,1,"SBK_CHANNEL","",0,0,0,0,.900711845416477,0,0,0,"DU_68","DU_68","",4,24,"SBK_CULVERT","",181826.114756322,488850.950336131,0,.886523449704097,"SYS_DEFAULT",0,"9","","",0,12,"SBK_CHANNELCONNECTION","",181826.844,488851.479,0,0,"SYS_DEFAULT",0
"WL_357_s1","",6,1,"SBK_CHANNEL","",0,0,0,0,44.9573115854777,0,0,0,"DU_4","DU_4","",6,24,"SBK_CULVERT","",181903.073057648,489295.266858857,0,467.811997465847,"SYS_DEFAULT",0,"DU_5","DU_5","",6,24,"SBK_CULVERT","",181898.174729063,489335.49522329,0,512.769309051325,"SYS_DEFAULT",0
"WL_357_s2","",6,1,"SBK_CHANNEL","",0,0,0,0,12.1345791425794,0,0,0,"DU_5","DU_5","",6,24,"SBK_CULVERT","",181898.174729063,489335.49522329,0,512.769309051325,"SYS_DEFAULT",0,"DU_6","DU_6","",6,24,"SBK_CULVERT","",181900.337947165,489344.306968456,0,524.903888193904,"SYS_DEFAULT",0
"WL_357_s3","",6,1,"SBK_CHANNEL","",0,0,0,0,22.614281198018,0,0,0,"DU_6","DU_6","",6,24,"SBK_CULVERT","",181900.337947165,489344.306968456,0,524.903888193904,"SYS_DEFAULT",0,"LOC_6","LOC_6","",6,20,"SBK_PROFILE","",181889.542877499,489364.161938347,0,547.518169391922,"SYS_DEFAULT",0
"WL_357_s4","",6,1,"SBK_CHANNEL","",0,0,0,0,7.6688758532049,0,0,0,"LOC_6","LOC_6","",6,20,"SBK_PROFILE","",181889.542877499,489364.161938347,0,547.518169391922,"SYS_DEFAULT",0,"10","","",6,12,"SBK_CHANNELCONNECTION","",181886.2,489371.059,0,555.187045245127,"SYS_DEFAULT",0
"WL_357_s5","",6,1,"SBK_CHANNEL","",0,0,0,0,61.0431251571269,0,0,0,"LOC_5","LOC_5","",6,20,"SBK_PROFILE","",181895.173592905,489236.837030347,0,406.768872308721,"SYS_DEFAULT",0,"DU_4","DU_4","",6,24,"SBK_CULVERT","",181903.073057648,489295.266858857,0,467.811997465847,"SYS_DEFAULT",0
"WL_351_s1","",1,1,"SBK_CHANNEL","",0,0,0,0,69.612970270265,0,0,0,"LOC_R40","LOC_R40","",1,20,"SBK_PROFILE","",181315.478165453,488379.054838942,0,85.3504190152846,"SYS_DEFAULT",0,"LOC_R43","LOC_R43","",1,20,"SBK_PROFILE","",181369.977075031,488421.706884734,0,154.96338928555,"SYS_DEFAULT",0
"WL_351_s2","",1,1,"SBK_CHANNEL","",0,0,0,0,218.178858401499,0,0,0,"LOC_R43","LOC_R43","",1,20,"SBK_PROFILE","",181369.977075031,488421.706884734,0,154.96338928555,"SYS_DEFAULT",0,"LOC_R50","LOC_R50","",1,20,"SBK_PROFILE","",181544.705711699,488490.050269125,0,373.142247687049,"SYS_DEFAULT",0
"WL_351_s3","",1,1,"SBK_CHANNEL","",0,0,0,0,42.2760490100177,0,0,0,"LOC_R50","LOC_R50","",1,20,"SBK_PROFILE","",181544.705711699,488490.050269125,0,373.142247687049,"SYS_DEFAULT",0,"LOC_R53","LOC_R53","",1,20,"SBK_PROFILE","",181573.554,488520.954,0,415.418296697066,"SYS_DEFAULT",0
"WL_351_s4","",1,1,"SBK_CHANNEL","",0,0,0,0,68.0174365247107,0,0,0,"LOC_R53","LOC_R53","",1,20,"SBK_PROFILE","",181573.554,488520.954,0,415.418296697066,"SYS_DEFAULT",0,"LOC_R56","LOC_R56","",1,20,"SBK_PROFILE","",181574.503906285,488585.523130178,0,483.435733221777,"SYS_DEFAULT",0
"WL_351_s5","",1,1,"SBK_CHANNEL","",0,0,0,0,93.6881553376135,0,0,0,"LOC_R56","LOC_R56","",1,20,"SBK_PROFILE","",181574.503906285,488585.523130178,0,483.435733221777,"SYS_DEFAULT",0,"LOC_R60","LOC_R60","",1,20,"SBK_PROFILE","",181614.35592023,488651.244970215,0,577.123888559391,"SYS_DEFAULT",0
"WL_351_s6","",1,1,"SBK_CHANNEL","",0,0,0,0,94.0130642584541,0,0,0,"LOC_R60","LOC_R60","",1,20,"SBK_PROFILE","",181614.35592023,488651.244970215,0,577.123888559391,"SYS_DEFAULT",0,"LOC_R65","LOC_R65","",1,20,"SBK_PROFILE","",181656.259,488716.423,0,671.136952817845,"SYS_DEFAULT",0
"WL_351_s7","",1,1,"SBK_CHANNEL","",0,0,0,0,74.8326200149762,0,0,0,"LOC_R65","LOC_R65","",1,20,"SBK_PROFILE","",181656.259,488716.423,0,671.136952817845,"SYS_DEFAULT",0,"LOC_R69","LOC_R69","",1,20,"SBK_PROFILE","",181719.256897851,488747.324091406,0,745.969572832821,"SYS_DEFAULT",0
"WL_351_s8","",1,1,"SBK_CHANNEL","",0,0,0,0,8.2526061930057,0,0,0,"LOC_R69","LOC_R69","",1,20,"SBK_PROFILE","",181719.256897851,488747.324091406,0,745.969572832821,"SYS_DEFAULT",0,"5","","",0,12,"SBK_CHANNELCONNECTION","",181724.76,488753.474,0,0,"SYS_DEFAULT",0
"WL_354_s1","",3,1,"SBK_CHANNEL","",0,0,0,0,125.121001711554,0,0,0,"LOC_D01","LOC_D01","",3,20,"SBK_PROFILE","",181731.773,488770.378,0,18.3010214195775,"SYS_DEFAULT",0,"LOC_D12","LOC_D12","",3,20,"SBK_PROFILE","",181825.063728081,488850.188375056,0,143.422023131132,"SYS_DEFAULT",0
"WL_357_s6","",6,1,"SBK_CHANNEL","",0,0,0,0,13.6738723393493,0,0,0,"LOC_D02","LOC_D02","",6,20,"SBK_PROFILE","",181894.157084806,489223.200993678,0,393.094999969371,"SYS_DEFAULT",0,"LOC_5","LOC_5","",6,20,"SBK_PROFILE","",181895.173592905,489236.837030347,0,406.768872308721,"SYS_DEFAULT",0
"WL_353_s1","",2,1,"SBK_CHANNEL","",0,0,0,0,24.2252711853396,0,0,0,"LOC_201","LOC_201","",2,20,"SBK_PROFILE","",181737.652,488732.964,0,24.0902312151046,"SYS_DEFAULT",0,"5","","",0,12,"SBK_CHANNELCONNECTION","",181724.76,488753.474,0,0,"SYS_DEFAULT",0
"WL_356_s1","",5,1,"SBK_CHANNEL","",0,0,0,0,.51666052002914,0,0,0,"LOC_202","LOC_202","",5,20,"SBK_PROFILE","",181825.965013713,488850.414502591,0,.568225085529253,"SYS_DEFAULT",0,"ST_3","P1695","",5,21,"SBK_WEIR","",181826.440931405,488850.541102778,0,1.08488560555839,"SYS_DEFAULT",0
"WL_355_s2","",4,1,"SBK_CHANNEL","",0,0,0,0,.273648354821889,0,0,0,"LOC_203","LOC_203","",4,20,"SBK_PROFILE","",181825.893202299,488850.789720948,0,.612875094882207,"SYS_DEFAULT",0,"DU_68","DU_68","",4,24,"SBK_CULVERT","",181826.114756322,488850.950336131,0,.886523449704097,"SYS_DEFAULT",0
"WL_357_s7","",6,1,"SBK_CHANNEL","",0,0,0,0,392.744155284583,0,0,0,"LOC_D21","LOC_D21","",6,20,"SBK_PROFILE","",181827.128049734,488851.6849314,0,.350844684788141,"SYS_DEFAULT",0,"LOC_D02","LOC_D02","",6,20,"SBK_PROFILE","",181894.157084806,489223.200993678,0,393.094999969371,"SYS_DEFAULT",0
"WL_354_s2","",3,1,"SBK_CHANNEL","",0,0,0,0,.411646432732681,0,0,0,"LOC_D12","LOC_D12","",3,20,"SBK_PROFILE","",181825.063728081,488850.188375056,0,143.422023131132,"SYS_DEFAULT",0,"8","","",0,12,"SBK_CHANNELCONNECTION","",181825.397,488850.43,0,0,"SYS_DEFAULT",0
"WL_356_s2","",5,1,"SBK_CHANNEL","",0,0,0,0,1.08668195964856,0,0,0,"ST_3","P1695","",5,21,"SBK_WEIR","",181826.440931405,488850.541102778,0,1.08488560555839,"SYS_DEFAULT",0,"9","","",0,12,"SBK_CHANNELCONNECTION","",181826.844,488851.479,0,0,"SYS_DEFAULT",0
"*"

[Reach description]

 6
"WL_351","WL_351","4","5",4,24,181252.9,488331.892,181724.76,488753.474,754.222179025827,0,50,-1
"WL_353","WL_353","7","5",6,3,181724.76,488714.798,181753.474,488753.474,48.3155024004441,0,50,-1
"WL_354","WL_354","5","8",7,4,181724.76,488753.474,181825.397,488850.43,143.833669563864,0,50,-1
"WL_355","WL_355","8","9",8,2,181825.397,488850.43,181826.844,488851.479,1.78723529512057,0,50,-1
"WL_356","WL_356","8","9",9,4,181825.397,488850.407,181826.844,488851.479,2.17156756520695,0,50,-1
"WL_357","WL_357","9","10",10,19,181826.844,488851.479,181907.686,489371.059,555.187045245127,0,50,-1

[Model connection node]
"1.00"
59,4
12,"SBK_CHANNELCONNECTION","",1,"SOBEK","4"
20,"SBK_PROFILE","",3,"SOBEK","5","SOBEK","16","SOBEK","21"
21,"SBK_WEIR","",2,"SOBEK","6","RTC","1"
24,"SBK_CULVERT","",2,"SOBEK","70","RTC","1"

[Model connection branch]
"1.00"
22,1
1,"SBK_CHANNEL","",2,"SOBEK","0","SOBEK","31"

[Nodes with calculationpoint]
"1.00"
5
"DU_68"
"DU_4"
"DU_5"
"DU_6"
"ST_3"

[Reach options]
"1.00"
0

[NTW properties]
"1.00"
3
v1=4
v2=0
v3=970
'''
        value = {'SBK_CULVERT': {('DU_4', '181903.073057648', '489295.266858857'): True,
                                 ('DU_68', '181826.114756322', '488850.950336131'): True,
                                 ('DU_6', '181900.337947165', '489344.306968456'): True,
                                 ('DU_5', '181898.174729063', '489335.49522329'): True,
                                 },
                 'SBK_PROFILE': {('LOC_R69', '181719.256897851', '488747.324091406'): True,
                                 ('LOC_D01', '181731.773', '488770.378'): True,
                                 ('LOC_R53', '181573.554', '488520.954'): True,
                                 ('LOC_R60', '181614.35592023', '488651.244970215'): True,
                                 ('LOC_201', '181737.652', '488732.964'): True,
                                 ('LOC_5', '181895.173592905', '489236.837030347'): True,
                                 ('LOC_203', '181825.893202299', '488850.789720948'): True,
                                 ('LOC_R40', '181315.478165453', '488379.054838942'): True,
                                 ('LOC_D12', '181825.063728081', '488850.188375056'): True,
                                 ('LOC_R56', '181574.503906285', '488585.523130178'): True,
                                 ('LOC_6', '181889.542877499', '489364.161938347'): True,
                                 ('LOC_R65', '181656.259', '488716.423'): True,
                                 ('LOC_R50', '181544.705711699', '488490.050269125'): True,
                                 ('LOC_D02', '181894.157084806', '489223.200993678'): True,
                                 ('LOC_D21', '181827.128049734', '488851.6849314'): True,
                                 ('LOC_R43', '181369.977075031', '488421.706884734'): True,
                                 ('LOC_202', '181825.965013713', '488850.414502591'): True,
                                 },
                 'SBK_WEIR': {('ST_3', '181826.440931405', '488850.541102778'): True,
                              },
                 'SBK_CHANNELCONNECTION': {('4', '181252.9', '488342.074'): True,
                                           ('5', '181724.76', '488753.474'): True,
                                           ('7', '181753.474', '488714.798'): True,
                                           ('8', '181825.397', '488850.43'): True,
                                           ('9', '181826.844', '488851.479'): True,
                                           ('10', '181886.2', '489371.059'): True,
                                           },
                 }

        def test01(self):
            "Network: object behaves as a dictionary"

            nn = Network(mock.Stream(self.input_str))
            for key, value in self.value.items():
                self.assertEqual(nn[key], value)

        def test11(self):
            "Network: crash on non existing file"

            self.assertRaises(IOError, Network, '/bin/not.existing.file.test')

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(RepresentingFloats))
    suite.addTest(unittest.makeSuite(ReadingAtomsTest))
    suite.addTest(unittest.makeSuite(ReadingComplexTest))
    suite.addTest(unittest.makeSuite(ReadingListsTest))
    suite.addTest(unittest.makeSuite(ReadingFromFile))
    suite.addTest(unittest.makeSuite(RepresentingAsText))
    suite.addTest(unittest.makeSuite(AddingRowsToATable))
    suite.addTest(unittest.makeSuite(ObjectLikeHandling))
    suite.addTest(unittest.makeSuite(AddingObjectsToFiles))
    suite.addTest(unittest.makeSuite(VerbatimDoesNothing))
    suite.addTest(unittest.makeSuite(DictionaryLikeAccess))
    suite.addTest(unittest.makeSuite(ReadingAndAlteringTables))
    suite.addTest(unittest.makeSuite(WritingToFile))
    suite.addTest(unittest.makeSuite(VerbatimFunctions))
    suite.addTest(unittest.makeSuite(DeletingItemsFromFile))
    suite.addTest(unittest.makeSuite(CreatingFileFromScratch))
    suite.addTest(unittest.makeSuite(NoneValuesAreConvertedInOutput))
    suite.addTest(unittest.makeSuite(ReadingAttributesWithDoubleName))
    suite.addTest(unittest.makeSuite(Ticket319))
    suite.addTest(unittest.makeSuite(HISFileFunctions))
    suite.addTest(unittest.makeSuite(NetworkDecoding))
    return suite


if __name__ == '__main__':
    # perform some unit tests...

    from nens import mock
    import unittest
    mock.lint(__file__)

    import sys
    print "testing with python %s" % sys.version

    unittest.TextTestRunner(verbosity=2).run(testsuite())
