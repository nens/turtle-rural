#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the nens library.
#
# the nens library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# the nens library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2008, 2009 Nelen & Schuurmans
#*
#***********************************************************************
#* Library    : defines grids
#*
#* Project    : various
#*
#* $Id: tests.py 13769 2010-09-17 08:55:55Z Mario $
#*
#* initial programmer :  Reinout van Rees
#* initial date       :  2010-01-15
#**********************************************************************

"""Collection of all unittests in the pynens library.

Run the tests with the python you used to install this library as it uses
absolute imports.

this script tests the INSTALLED modules, not the current directory.

"""
import sys
import unittest

import xmlrunner


def suite_all():
    suite = unittest.TestSuite()
    import nens
    for module in [__import__("nens." + i, fromlist=[nens]) for i in nens.__all__]:
        try:
            suite.addTest(module.testsuite())
        except AttributeError, e:
            print module.__name__, ":", e
    return suite


def xml_test_all():
    result = xmlrunner.XMLTestRunner(
        output='xmltestresults').run(suite_all())
    if not result.wasSuccessful():
        sys.exit(1)


if __name__ == '__main__':
    result = unittest.TextTestRunner().run(suite_all())
    if not result.wasSuccessful():
        sys.exit(1)
