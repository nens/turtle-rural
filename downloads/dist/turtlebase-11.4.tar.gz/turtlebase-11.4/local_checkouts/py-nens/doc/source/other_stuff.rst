mock
----

mock objects useful for testing

.. automodule:: nens.mock
   :members:

uuid
----

possibly not needed in recent python version

.. automodule:: nens.uuid
   :members:


