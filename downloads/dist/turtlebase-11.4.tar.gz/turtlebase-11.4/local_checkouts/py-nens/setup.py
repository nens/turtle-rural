#!/usr/bin/env python
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the nens library.
#
# the nens library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# the nens library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2008, 2009 Mario Frasca
#**********************************************************************

#* $Id: setup.py 21650 2011-06-09 12:41:26Z coen.nengerman $
#* $Rev: 21650 $

from setuptools import setup

long_description = u'\n'.join([
        open('README.rst').read(),
        open('CHANGES.rst').read(),
        ])

install_requires = [
    # 'GDAL',  # GDAL refuses to install properly on OSX and Windows.
    'PIL >= 1.1.6',
    'matplotlib',
    'networkx >= 0.99',
    'numpy >= 1.3.0',
    'scipy >= 0.7.0',
    'shapely',
    ],

setup(name="nens",
      version='1.5dev',
      description='the NenS collection',
      long_description=long_description,
      author="Mario Frasca & al.",
      author_email="mario.frasca@nelen-schuurmans.nl",
      url="http://twiki.nelen-schuurmans.nl",
      license="GPL",
      packages=["nens"],
      zip_safe=False,
      install_requires=install_requires,
      )
