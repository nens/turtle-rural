Turtle library
==============

This package provides


Installation
------------

Run ``python setup.py install`` to install it.


Usage
-----

TODO: do we need to explain the usage here?


Developer installation
----------------------

While developing, ``python setup.py develop`` does the same as ``install``,
but keeps track of the changes you make.  (Only new ``.py`` files need a new
``setup.py develop``).

For an isolated environment *with test runner*, run ``python bootstrap.py``
followed by ``bin/buildout``.

Run the tests with ``bin/test``.
