#!/usr/bin/python
# -*- coding: utf-8 -*-
#******************************************************************************
#
# This file is part of the turtle_base library.
#
# The turtle_base library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# This library is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# the turtle_base library.  If not, see <http://www.gnu.org/licenses/>.
#
# Copyright 2010 Nelen & Schuurmans
#
#******************************************************************************
#
# Initial programmer: Pieter Swinkels
# Initial date:       2010-11-12
#
#******************************************************************************

import copy
import os

from subprocess import Popen

import logging
logger = logging.getLogger(__name__)


class ExternalToolException(Exception):

    def __init__(self, tool_name):
        self.tool_name = tool_name


def retrieve_records_from_mdb(mdb_filename):
    """Return the area and connection records in the given Access file.

    The return value is a tuple whose first element is the list of area records
    and whose second element is the list of connection records.

    This function depends on Python module pyodbc to be able to read from the
    Access file. If this function cannot import the right elements of this
    module, it throws an ImportError.

    Parameters:
    * mdb_filename -- name of the Access file with the area and connection info

    Note that mdb_filename should contain the complete filename, that is,
    include path and extension.

    """

    from pyodbc import connect
    from pyodbc import ProgrammingError

    connection_string = "DRIVER={Microsoft Access Driver (*.mdb)};DBQ="
    connection_string += mdb_filename
    connection = connect(connection_string)
    cursor = connection.cursor()

    SQL_statement = "SELECT * FROM RR_Afvoer"
    logger.debug("cursor.execute(\"%s\"" % SQL_statement)
    cursor.execute(SQL_statement)

    connection_records = []
    for row in cursor.fetchall():
        record = (row.AFVOER_VN, row.AFVOER_NR)
        logger.debug("src: %s, dst: %s" % record)
        connection_records.append({'src': record[0],
                                   'dst': record[1]})

    SQL_statement = "SELECT * FROM RR_Oppervlak"
    logger.debug("cursor.execute(\"%s\"" % SQL_statement)
    cursor.execute(SQL_statement)

    area_records = []
    for row in cursor.fetchall():
        record = (row.GPGIDENT, row.HECTARES, row.OPENWAT_HA)
        logger.debug("label: %s, surface: %f, water_surface: %f" % record)
        area_records.append({'label': record[0],
                             'surface': record[1],
                             'water_surface': record[2]})

    # we collect those nodes in connections for which no areas exist
    logger.debug("nodes in connections for which no areas exist:")
    area_labels = [area_record['label'] for area_record in area_records]
    for connection_record in connection_records:
        if not connection_record['src'] in area_labels:
            logger.debug("label: %s" % connection_record['src'])
            area_record = {'label': connection_record['src']}
            area_records.append(area_record)
            area_labels.append(area_record)
        if not connection_record['dst'] in area_labels:
            logger.debug("label: %s" % connection_record['dst'])
            area_record = {'label': connection_record['dst']}
            area_records.append(area_record)
            area_labels.append(area_record)

    if len(area_records) > 0:
        try:
            cursor.execute("SELECT * FROM RR_Resultaten")
            for row in cursor.fetchall():
                for area_record in area_records:
                    if area_record['label'] == row.GPGIDENT:
                        area_record['T_I'] = row.T_I
                        area_record['T_O'] = row.T_O
                        break
        except ProgrammingError:
            # there does not seem to be a table named RR_Resultaten
            pass

    return area_records, connection_records


def generate_raw_picture(areas, connections, backend):
    """Passes the given area and connection records to the given backend.

    Parameters:

    * areas -- list of dictionaries, where each dict specifies an area

    * connections -- list of dictionaries, where each dict specifies a
      connection

    * backend -- creates the block schema for te given areas and connections

    Each area should have a key named 'label' that uniquely identifies the
    area. Each connection should have a key named 'src' and a key named 'dst'
    that identify the labels of the source area and destination area
    respectively.

    """
    for area in areas:
        kwargs = copy.copy(area)
        del kwargs['label']
        backend.add_node(area.get('label', ''), **kwargs)

    for connection in connections:
        backend.add_edge(connection.get('src', ''), connection.get('dst', ''))
    backend.store()


def generate_picture(areas, connections, backend):
    """Passes the given area and connection records to the given backend.

    Parameters:

    * areas -- list of dictionaries, where each dict specifies an area

    * connections -- list of dictionaries, where each dict specifies a
      connection

    * backend -- creates the block schema for te given areas and connections

    Each area should have a key named 'label' that uniquely identifies the
    area. Each connection should have a key named 'src' and a key named 'dst'
    that identify the labels of the source area and destination area
    respectively.

    """
    for area in areas:
        kwargs = {}
        surface = area.get('surface', 0)
        if surface > 0:
            water_surface = area.get('water_surface', 0)
            kwargs = {'surface': "%.1fha" % surface,
                      'percentage': "%.2f%%" % (100 * (water_surface /
                                                       surface))}
        if 1 == int(area.get('T_O', 0)):
            kwargs['color'] = 'yellow'
        if 1 == int(area.get('T_I', 0)):
            kwargs['color'] = 'red'
        backend.add_node(area.get('label', ''), **kwargs)
    for connection in connections:
        backend.add_edge(connection.get('src', ''), connection.get('dst', ''))
    backend.store()


def generate_urban_picture(areas, connections, backend):
    """Passes the given area and connection records to the given backend.

    Parameters:

    * areas -- list of dictionaries, where each dict specifies an area

    * connections -- list of dictionaries, where each dict specifies a
      connection

    * backend -- creates the block schema for te given areas and connections

    Each area should have a key named 'label' that uniquely identifies the
    area. Each connection should have a key named 'src' and a key named 'dst'
    that identify the labels of the source area and destination area
    respectively.

    """
    for area in areas:
        kwargs = {}
        inhabitants = area['Aantal inwoners']
        if inhabitants is None:
            kwargs['Inwoners'] = "-"
        else:
            kwargs['Inwoners'] = "%d" % int(inhabitants)
        # the surfaces are specified in [m2] but we want them in [ha]
        roof_surface = area['Dakafvoer']
        if roof_surface is None:
            kwargs['Oppervlak daken'] = "-"
        else:
            kwargs['Oppervlak daken'] = "%.2f ha" % \
                                        round(roof_surface / 10000.0, 2)
        kwargs['Oppervlak totaal'] = "%.2f ha" % \
                                     round(area['Oppervlak'] / 10000.0, 2)
        lowest_overflow_level = area['Laagste overstortdrempel']
        if lowest_overflow_level is None:
            kwargs['Laagste overstortdrempel'] = "-"
        else:
            kwargs['Laagste overstortdrempel'] = "%.1f m NAP" % \
                                                 lowest_overflow_level
        backend.add_node(area.get('label', '-'), **kwargs)
    for connection in connections:
        backend.add_edge(connection.get('src', ''), connection.get('dst', ''))
    backend.store()


def retrieve_extension(filename):
    root, extension = os.path.splitext(filename)
    # the filename should contain an extension: as the extension starts with a
    # dot, its length should be at least 2
    assert len(extension) > 1
    return extension[1:]


class SchemaRawBackendGraphviz:
    """Creates a PNG of a block schema.

    The client should supply the SchemaBackendGraphviz the areas and
    connections that make up the block schema. Then, to actually generate the
    PNG, the SchemaBackendGraphviz uses the external tool 'dot' to actually
    generate the PNG. 'dot' is part of Graphviz, which can be found at
    http://www.graphviz.org/.

    Instance variables:
    * self.output_filename -- name of the file to save the block schema to
    * self.dot_filename -- name of the dot file to save the block schema to
    * self._lines -- internal list of lines with the contents of the .dot file

    """
    def __init__(self, filename):
        self.output_filename = filename
        self.extension = retrieve_extension(filename)
        self.dot_filename = filename.replace('.' + self.extension, '.dot')
        self._lines = ["digraph G {", "rankdir=LR", "nodesep=0.5"]

        # Initially we specified the dpi of the output to 300 as the default
        # value of 96 does not allow for much zooming. However, a test with a
        # large (but still practical) block schema showed that dot would run
        # for several minutes and consume more than half a GByte of memory. We
        # was considered that to be too long and therefore we do not specify
        # the dpi setting.
        #
        # Why 300 dpi? To determine a suitable value, we used a block schema of
        # 1241 nodes and 1220 lines - in general, block schemas are much
        # smaller. It turned out that a value higher than 300 did not result in
        # a higher quality image when zooming.

        # It might be better to let the user specify the dpi setting or use a
        # dynamic dpi setting scheme.

        # if self.extension != "svg":
        #     # dot does not create a svg when we specify the dpi of the
        #     # output. Other resolution-independent formats such as .eps and
        #     # .pdf do not have this problem.
        #     self._lines.append("dpi=300")

    def add_node(self, area_label, **kwargs):
        if len(kwargs) == 0:
            label = None
        else:
            label = self._create_label(kwargs)
        color = kwargs.get("color", None)
        if color is None:
            color_label = ""
        else:
            color_label = ", fillcolor=%s, style=filled, color=black" % color
        if label is None:
            line = "\"%s\" [shape=box%s]" % (area_label, color_label)
        else:
            title = self._create_title(area_label)
            line = "\"%s\" [shape=record%s, label=\"%s\\n%s\"]" % \
                   (area_label, color_label, title, label)
        self._lines.append(line)

    def add_edge(self, src_label, dst_label, **kwargs):
        line = "\"%s\" -> \"%s\"" % (src_label, dst_label)
        self._lines.append(line)

    def store(self):
        """Creates the PNG of the current block schema.

        """
        self._lines.append("}")
        self._write_lines(self._lines, self.dot_filename)
        self._call_dot(self.dot_filename, self.output_filename)

    def _create_title(self, label):
        return label

    def _create_label(self, kwargs):
        assert len(kwargs) > 0
        label = ""
        for key, value in kwargs.items():
            label += "%s: %s\\l" % (key, value)
        return label

    def _write_lines(self, lines, filename):
        """Write the given lines to a file with the given filename.

        Parameters:
        * lines -- list of lines to write
        * filename -- name of the file to write to

        This method writes a newline after each line written. This means that
        the client does not have to append each line with a newline.

        """
        try:
            file = open(filename, 'w')
            for line in lines:
                file.write(line + '\n')
        finally:
            file.close()

    def _call_dot(self, dot_filename, output_filename):
        """Call the external tool 'dot' to create the PNG.

        Parameters:
        * dot_filename -- filename of the input file for dot
        * output_filename -- filename of the destination file

        This method returns True if and only the destination file could be
        created.

        """
        external_tool = "dot"
        try:
            file = open(output_filename, 'w')
            args = [external_tool,
                    "-T%s" % self.extension.lower(),
                    dot_filename]
            p = Popen(args, stdout=file)
            p.wait()
        finally:
            file.close()


class SchemaBackendGraphviz(SchemaRawBackendGraphviz):
    """Creates a PNG of a block schema.

    The client should supply the SchemaBackendGraphviz the areas and
    connections that make up the block schema. Then, to actually generate the
    PNG, the SchemaBackendGraphviz uses the external tool 'dot' to actually
    generate the PNG. 'dot' is part of Graphviz, which can be found at
    http://www.graphviz.org/.

    Instance variables:
    * self.dot_filename -- name of the dot file
    * self.png_filename -- name of the PNG file
    * self._lines -- internal list of lines with the contents of the .dot file

    """

    def _create_label(self,  kwargs):
        assert len(kwargs) > 0
        unknown_value = "--"
        surface = kwargs.get("surface", unknown_value)
        percentage = kwargs.get("percentage", unknown_value)
        if surface == unknown_value and percentage == unknown_value:
            label = None
        else:
            label = "%s; Ow %s" % (surface, percentage)
        return label


class UrbanSchemaBackendGraphviz(SchemaRawBackendGraphviz):
    """Creates a PNG of a block schema for urban.

    The client should supply the SchemaBackendGraphviz the areas and
    connections that make up the block schema. Then, to actually generate the
    PNG, the SchemaBackendGraphviz uses the external tool 'dot' to actually
    generate the PNG. 'dot' is part of Graphviz, which can be found at
    http://www.graphviz.org/.

    Instance variables:
    * self.dot_filename -- name of the dot file
    * self.png_filename -- name of the PNG file
    * self._lines -- internal list of lines with the contents of the .dot file

    """

    def _create_title(self, label):
        return "Peilvak: %s" % label
