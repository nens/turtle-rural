# Import modules
import os

try:
    import arcgisscripting
    gp = arcgisscripting.create()
except ImportError:
    arcgisscripting = None
    gp = None

import logging
logger = logging.getLogger(__name__)

#import collections
import nens.geom
import nens.gp
import turtlebase.network
import turtlebase.arcgis
import turtlebase.areacombiner


class defaultdict(dict):

    def __init__(self, default_factory=None, *a, **kw):
        if (default_factory is not None and
            not hasattr(default_factory, '__call__')):
            raise TypeError('first argument must be callable')
        dict.__init__(self, *a, **kw)
        self.default_factory = default_factory

    def __getitem__(self, key):
        try:
            return dict.__getitem__(self, key)
        except KeyError:
            return self.__missing__(key)

    def __missing__(self, key):
        if self.default_factory is None:
            raise KeyError(key)
        self[key] = value = self.default_factory()
        return value

    def __reduce__(self):
        if self.default_factory is None:
            args = tuple()
        else:
            args = self.default_factory,
        return type(self), args, None, None, self.items()

    def copy(self):
        return self.__copy__()

    def __copy__(self):
        return type(self)(self.default_factory, self)

    def __deepcopy__(self, memo):
        import copy
        return type(self)(self.default_factory,
                          copy.deepcopy(self.items()))

    def __repr__(self):
        return 'defaultdict(%s, %s)' % (self.default_factory,
                                        dict.__repr__(self))


def create_points(gp, line_fc, line_ident):
    """
    warning: does not work for a multipart feature
    """
    points = {}
    check_points = {}

    inDesc = gp.describe(line_fc)

    row = gp.SearchCursor(line_fc)
    for item in nens.gp.gp_iterator(row):
        feat = item.GetValue(inDesc.ShapeFieldName)
        item_id = item.GetValue(line_ident)
        part = feat.getpart(0)
        pnt_list = [(round(pnt.x, 5), round(pnt.y, 5)) for pnt in
                    nens.gp.gp_iterator(part)]

        key1 = pnt_list[0], pnt_list[1]
        key2 = pnt_list[1], pnt_list[0]
        if key1 in check_points or key2 in check_points:
            pass
        else:
            check_points[key1] = {}

            pnt_list = turtlebase.voronoi.change_start_and_end_point(pnt_list)
            pnt_list = turtlebase.network.densify_multiline(pnt_list,
                                                            density=5)
            points[item_id] = pnt_list

    return points


def create_line_voronoi(point_dict):
    """
    """
    points = []

    for k, v in point_dict.items():
        for i in v:
            points.append(i)

    (vertices,
     lines,
     edges,
     polygons_dict,
     clip) = nens.geom.computeVoronoiDiagram(points, clip=20000)
    result_dict = collect_polygons_for_lines(polygons_dict, point_dict)
    logger.debug("create merged polygons")

    return result_dict


def create_polygon_from_points(polygons_dict, idfield, outputfile):
    """
    """
    logger.debug(" - create feature class for output")
    linearray = gp.CreateObject("ARRAY")
    point = gp.CreateObject("POINT")
    file_name = os.path.basename(outputfile)
    directory = os.path.dirname(outputfile)

    gp.CreateFeatureClass_management(directory, file_name, "POLYGON")
    gp.addfield(outputfile, idfield, "TEXT")

    rows_ic = gp.InsertCursor(outputfile)
    for k, v in polygons_dict.items():
        for polygon in v['polygon_list']:

            for item in polygon:
                point.X = float(item[0])
                point.Y = float(item[1])
                linearray.Add(point)
                newfeature = rows_ic.NewRow()

            newfeature.shape = linearray
            newfeature.SetValue(idfield, k)

            rows_ic.InsertRow(newfeature)
            linearray.RemoveAll()


def create_multiple_polygon_from_points(
    list_of_polygons, idfield, id_name, outputfile):
    """
    """
    logger.debug(" - create feature class for output")
    linearray = gp.CreateObject("ARRAY")
    point = gp.CreateObject("POINT")
    file = os.path.basename(outputfile)
    directory = os.path.dirname(outputfile)

    gp.CreateFeatureClass_management(directory, file, "POLYGON")
    gp.addfield(outputfile, idfield, "TEXT")
    rows_ic = gp.InsertCursor(outputfile)
    for polygon in list_of_polygons:

        for item in polygon:
            point.X = float(item[0])
            point.Y = float(item[1])
            linearray.Add(point)
            newfeature = rows_ic.NewRow()

        newfeature.shape = linearray
        newfeature.SetValue(idfield, id_name)

        rows_ic.InsertRow(newfeature)
        linearray.RemoveAll()


def collect_polygons_for_lines(point_dict, line_dict):
    """
    """
    result = defaultdict(dict)
    float_formatter = turtlebase.arcgis.FormatFloat()
    mapping = {}
    for line_id, point_ids in line_dict.items():
        for point_id in point_ids:
            point_id = '%s, %s' % (float_formatter.format(point_id[0]),
                                   float_formatter.format(point_id[1]))
            mapping[point_id] = line_id

    for point_id, polygons in point_dict.items():
        point_id = '%s, %s' % (float_formatter.format(point_id[0]),
                               float_formatter.format(point_id[1]))

        result[mapping[point_id]].update({point_id: polygons})

    return result


def create_point_voronoi(input_fc, output_fc, calculation_point_id):
    """
    """
    rows = gp.SearchCursor(input_fc)
    points = []
    for row in nens.gp.gp_iterator(rows):
        xy = row.Shape.Centroid.split(" ")
        x = xy[0].replace(",", ".")
        y = xy[1].replace(",", ".")
        points.append((float(x), float(y)))

    logger.debug((" - create voronoi polygon"))
    (vertices,
     lines,
     edges,
     polygons_dict,
     clip) = nens.geom.computeVoronoiDiagram(points, clip=20000)
    logger.debug(polygons_dict)

    create_multiple_polygon_from_points(polygons_dict.values(),
                                        calculation_point_id,
                                        "test",
                                        output_fc)


def create_merged_polygons(voronoi_dict, workspace_gdb, line_ident='OVKIDENT'):
    """
    verzin beter naam voor deze functie deze functie verzameld tekent 1
    "voronoi" polygoon per lijn op basis van de verzameling voronoi polygonen

    dict = {"ovk_ident": {"id1": [polygon], "id2": [polygon]}}

    """
    ovk_ids = []
    polygon_dict = {}

    for line_id, polygons in voronoi_dict.items():
        ovk_ids.append(line_id)
        logger.debug(" -- create polygons for %s" % line_id)
        combiner = turtlebase.areacombiner.AreaCombiner(
            polygons, print_debug_output=True)
        output = combiner.combined_areas()
        list_of_polygons = []
        list_of_polygons.append(output)
        logger.debug("coordinaten voor polygon: %s" % output)
        polygon_dict[line_id] = {"polygon_list": list_of_polygons}

    outputfile = turtlebase.arcgis.get_random_file_name(workspace_gdb, ".shp")
    create_polygon_from_points(polygon_dict, line_ident, outputfile)

    return outputfile


## TODO:
## compare with network.create_station_point and decide which one to remove
def create_station_point(P0, P1, d):
    """gegeven P0 en P1 (twee punten) en het afstand d, berekent P op segment
    P0->P1 op afstand d uit P0.

    P0 en P1 zijn 2-tuples.

    >>> create_station_point((0, 0), (2, 2), 0)
    (0.0, 0.0)
    >>> create_station_point((0, 0), (3, 4), 10)
    (6.0, 8.0)
    >>> create_station_point((0, 0), (6, 8), 5)
    (3.0, 4.0)
    """
    import math
    x0, y0 = P0
    x1, y1 = P1

    # vector P0->P1
    vx = x1 - x0
    vy = y1 - y0

    # unit vector u op P0->P1
    l = math.sqrt(vx * vx + vy * vy)
    ux = vx / l
    uy = vy / l

    return (x0 + ux * d, y0 + uy * d)


def change_start_and_end_point(pnt_list):
    """
    input is a list with tuples (x, y). changes start and end point in the list

    """
    O = pnt_list[0]
    P = pnt_list[1]
    start_length = turtlebase.network.distance(O, P)

    if start_length < 0.5:
        d = 0.1 * start_length
    else:
        d = 0.1

    pnt_list.pop(0)
    pnt_list.insert(0, create_station_point(O, P, d))

    O = pnt_list[-1]
    P = pnt_list[-2]
    end_length = turtlebase.network.distance(O, P)

    if end_length < 0.5:
        d = 0.1 * end_length
    else:
        d = 0.1

    pnt_list.pop(-1)
    pnt_list.insert(-1, create_station_point(O, P, d))

    return pnt_list


def create_voronoi(input_calc_points, calculation_point_id, input_polygon,
                   polygon_id, output_afv_oppervlak, workspace_gdb):
    """
    Create voronoi polygons for each calculation point, search for voronoi
    within borders of input_polygon
    """
    fieldmappings = gp.createobject("FieldMappings")
    fldmap_GPG_ID = gp.createobject("FieldMap")

    point_layer = turtlebase.arcgis.get_random_layer_name()
    gp.MakeFeatureLayer(input_calc_points, point_layer)

    row = gp.SearchCursor(input_polygon)
    polygon_list = []
    for item in nens.gp.gp_iterator(row):
        item_id = item.GetValue(polygon_id)
        logger.info("Create voronoi polygons for %s" % item_id)

        logger.info(" - make feature layer")
        huidig_peilgebied_lyr = turtlebase.arcgis.get_random_layer_name()
        gp.MakeFeatureLayer(input_polygon,
                            huidig_peilgebied_lyr,
                            "%s = '%s'" % (polygon_id, item_id))

        logger.info(" - select by location")
        gp.SelectLayerByLocation_management(point_layer,
                                            "COMPLETELY_WITHIN",
                                            huidig_peilgebied_lyr)

        record_count = turtlebase.arcgis.fc_records(gp, point_layer)
        if record_count > 2:
            logger.info(" - create voronoi polygons")
            voronoi_polygons = turtlebase.arcgis.get_random_file_name(
                workspace_gdb, ".shp")
            create_point_voronoi(point_layer,
                                 voronoi_polygons,
                                 calculation_point_id)

            # Intersect voronoi polygons met het peilgebied
            logger.info(" - intersect with level area")
            intersect_voronoi = turtlebase.arcgis.get_random_file_name(
                workspace_gdb)
            gp.Intersect_analysis(
                voronoi_polygons + ";" + huidig_peilgebied_lyr,
                intersect_voronoi)

            logger.info(" - export area %s" % item_id)
            polygon_list.append(intersect_voronoi)
        elif record_count > 0:
            logger.warning(
                "level area %s doesn't have enough calculation points!",
                item_id)
            polygon_list.append(huidig_peilgebied_lyr)

        else:
            logger.warning(
                "level area %s doesn't have any calculation points!",
                item_id)
            polygon_list.append(huidig_peilgebied_lyr)

    merge_str = ";".join(polygon_list)

    for fc in polygon_list:
        fldmap_GPG_ID.AddInputField(fc, polygon_id)

    fieldmappings.AddFieldMap(fldmap_GPG_ID)

    logger.info("Merge voronoi polygons")
    tmp_afv_oppervlak = turtlebase.arcgis.get_random_file_name(workspace_gdb)
    gp.Merge_management(merge_str, tmp_afv_oppervlak, fieldmappings)

    fieldmappings2 = gp.createobject("FieldMappings")
    fldmap2_GPG_ID = gp.createobject("FieldMap")
    fldmap2_CP_ID = gp.createobject("FieldMap")

    fldmap2_GPG_ID.AddInputField(tmp_afv_oppervlak, polygon_id)
    fldmap2_CP_ID.AddInputField(input_calc_points, calculation_point_id)
    fieldmappings2.AddFieldMap(fldmap2_GPG_ID)
    fieldmappings2.AddFieldMap(fldmap2_CP_ID)

    logger.info("Join ID's to voronoi polygons")
    gp.SpatialJoin_analysis(tmp_afv_oppervlak, input_calc_points,
                            output_afv_oppervlak, "JOIN_ONE_TO_ONE", "#",
                            fieldmappings2, "INTERSECTS")

    return output_afv_oppervlak
