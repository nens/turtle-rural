# Copyright Nelen & Schuurmans
# GPL licensed, see LICENSE.txt
"""Find the outer edge of voronoi areas"""

import logging

#try:
#    import pylab
#except ImportError:
pylab = None

logger = logging.getLogger(__name__)


def num_changes(points, matching):
    """Return number of different matching/not matching sequences"""
    items = [(point in matching) for point in points]
    latest = None
    sequence = []
    for item in items:
        if item != latest:
            sequence.append(item)
        latest = item
    return len(sequence)


def cut(points, cut_this_out):
    """Split points into a list before and after the cut-out

    Both first and second (before and after the cut-off point) keep track of
    the cut-off point on both of their sides.

    """
    before_first = None
    first = []
    after_first = None
    before_second = None
    second = []
    after_second = None

    current_state = 'include'
    previous_point = None
    collect_into = first
    for point in points:
        state = (point in cut_this_out) and 'cut' or 'include'
        if state != current_state:
            current_state = state
            if state == 'cut':
                if collect_into is first:
                    collect_into = second
                    after_first = point
                    previous_point = point
                    continue
                if collect_into is second:
                    after_second = point
                    previous_point = point
                    continue
            if state == 'include':
                # switching on second.
                before_second = previous_point
        previous_point = point
        if state == 'include':
            collect_into.append(point)

    if before_first is None:
        if first:
            # Make the start point findable.
            before_first = first[0]

    return ((before_first, first, after_first),
            (before_second, second, after_second))


class AreaCombiner(object):
    """Combine areas defined by lists of points into one"""

    def __init__(self, areas, print_debug_output=False):
        if print_debug_output and pylab:
            self.make_graphs = True
        else:
            self.make_graphs = False
        assert isinstance(areas, dict)
        self.areas = areas
        self.area_sets = {}
        for area_id in self.areas:
            self.area_sets[area_id] = set(self.areas[area_id])
        self.already_combined = []
        self.bounding_points = []
        self.imagecount = 0

    @property
    def _first_area_id(self):
        # Sorted to get reliable test results, btw.
        return sorted(self.areas.keys())[0]

    def next_adjacent_area(self):
        """Return ID of next adjacent area and set of matching points"""
        still_todo = set(self.areas.keys()) - set(self.already_combined)
        for area_id in still_todo:
            matching = set(self.bounding_points).intersection(
                self.area_sets[area_id])
            if len(matching) >= 2:
                if (num_changes(self.bounding_points, matching) > 3 or
                    num_changes(self.areas[area_id], matching) > 3):
                    logger.debug("More than one matching line segment, "
                              "Trying to find another area.")
                    continue

                return (area_id, matching)
        # Nothing found
        return (None, None)

    def combined_areas(self):
        """Return list of points that bound the areas"""
        logger.debug("Starting combining %s areas", len(self.areas))
        if len(self.areas) == 0:
            return []
        # We take the first area and extend it from there.
        self.bounding_points = self.areas[self._first_area_id]
        self.already_combined.append(self._first_area_id)
        while True:
            area_id, matching = self.next_adjacent_area()

            if area_id is None:
                # No further adjacent areas found. Break while loop.
                break
            item1, item2 = cut(self.bounding_points, matching)
            item3, item4 = cut(self.areas[area_id], matching)
            # Every item is a tuple (before, points, after).
            items = [item for item in [item1, item2, item3, item4]
                     if item[1]]
            if len(items) == 2:
                # Corner case, our main loop was cut by something completely
                # touched/matched by us. Stitch ourselves back together.
                items = [(None, items[0][1], items[0][2]),
                         (items[0][2], [items[1][0]] + items[1][1],
                          items[1][2])]
            if len(items) == 1:
                # Make sure the starting item is used, too.
                start, middle, end = items[0]
                items = [(None, [start] + middle, end)]
            self.bounding_points = []
            added = items[0][1]
            after = items[0][2]
            while True:
                found = False
                if (self.bounding_points and
                    (added[0] == self.bounding_points[-1])):
                    # Corner case, remove the start of added.
                    added.pop(0)
                self.bounding_points += added
                if after is None:
                    after = self.bounding_points[-1]
                if after != self.bounding_points[-1]:
                    self.bounding_points += [after]
                for item in items[1:]:
                    if item[0] == after:
                        added = list(item[1])
                        found = True
                        after = item[2]
                if not found:
                    break

            if self.bounding_points[-1] != self.bounding_points[0]:
                self.bounding_points += [self.bounding_points[0]]

            self.already_combined.append(area_id)
            self.intermediate_debug_output(matching)

        unused_areas = set(self.areas.keys()) - set(self.already_combined)
        if unused_areas:
            self.report_unused_areas(unused_areas)
        logger.debug("Returning combined area (%s bounding points)",
                 len(self.bounding_points))
        return self.bounding_points

    def intermediate_debug_output(self, matching):
        logger.debug("Info on retained/removed points in step %s",
                  self.imagecount)
        logger.debug("Number of current bounding points: %s",
                  len(self.bounding_points))
        removed = matching - set(self.bounding_points)
        retained = matching - removed
        x = []
        y = []
        for point in self.bounding_points:
            x.append(point[0])
            y.append(point[1])
        if self.make_graphs:
            pylab.plot(x, y, marker='o', markersize=10, hold=False)
        for point in retained:
            logger.debug("Retained point %s", repr(point))
            if self.make_graphs:
                pylab.plot(point[0], point[1],
                           marker='D', markersize=8, hold=True)
        for point in removed:
            logger.debug("Removed point %s", repr(point))
            if self.make_graphs:
                pylab.plot(point[0], point[1],
                           marker='*', markersize=10, hold=True)
        if self.make_graphs:
            pylab.savefig('%02d.png' % self.imagecount)
            logger.debug("Printed image #%s", self.imagecount)
        self.imagecount += 1

    def report_unused_areas(self, unused_areas):
        logger.debug("%s unused areas %r", len(unused_areas), unused_areas)
        for area_id in unused_areas:
            logger.debug("Unused area: %s", area_id)
            x = []
            y = []
            for point in self.areas[area_id]:
                x.append(point[0])
                y.append(point[1])
                if point not in self.bounding_points:
                    logger.debug("Not in bounding points: %r", repr(point))
                    if self.make_graphs:
                        pylab.plot(point[0], point[1],
                                   marker='D', markersize=8, hold=True)
            if self.make_graphs:
                pylab.plot(x, y, marker='o', markersize=4,
                           linestyle='--', hold=True)
                pylab.savefig('%02d.png' % self.imagecount)
                logger.debug("Wrote image #%s", self.imagecount)
            self.imagecount += 1
