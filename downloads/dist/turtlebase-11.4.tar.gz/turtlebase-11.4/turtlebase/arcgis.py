# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-

import csv
import locale
import logging
import os
import random
import string
import sys
import time

from turtlebase.network import read_coordinates_from_string
import nens.gp
import turtlebase.general

try:
    import arcgisscripting
    gp = arcgisscripting.create()
    # TODO ^^^: don't instantiate globally but pass it to methods.
except ImportError:
    arcgisscripting = None
    gp = None

TEMP_NAME = 'turtlework'

logger = logging.getLogger(__name__)


class FormatFloat:
    """
    input float
    output rounded string with 5 decimales and a ','
    when Dutch language settings
    """
    def __init__(self):
        lang_name, lang_code = locale.getdefaultlocale()
        if lang_name is None:
            self.decimal_point = '.'
        elif lang_name[:2] == 'nl':
            self.decimal_point = ','
        else:
            self.decimal_point = '.'

    def format(self, input):
        return ('%.5f' % input).replace('.', self.decimal_point)


def remove_multiple_fields(gp, fc, list_of_fields):
    """
    function to remove multiple fields in an attribute table
    at the same time to increase computational speed
    uses the arcgis function deletefield.
    input is a feature class with several columns
    output is a feature class with the columns that are in the list of fields
    list removed.
    does nothing if the fields in the list are not in the attribute table
    """
    # First check whether the fields exist, if not remove them from the
    # list_of_fields.
    for field in list_of_fields:
        if is_fieldname(gp, fc, field) == False:
            list_of_fields.remove(field)

    fields_to_remove_statement = ';'.join(list_of_fields)
    logger.info('fields_to_remove_statement %s' % fields_to_remove_statement)
    if fields_to_remove_statement != "":
        gp.DeleteField_management(fc, fields_to_remove_statement)


def rename_field(gp, fc, fieldname_old, fieldname_new):
    """
    Arcgis doesn't know a function for renaming field names. the only way
    is to add the new fieldname, copy paste the contents and then deleting
    the old fieldname input is the fc with the old field name
    output is the same fc with the new field name instead of the old field name
    """
    # check whethe the new field name doesn't already exist
    if is_fieldname(gp, fc, fieldname_new) == True:
        logger.warning("New field name %s already exists" % fieldname_new)
    #create the new field name with of the same type as the old field name
    else:
        fieldnames_dict = read_fieldnames(gp, fc)
        fieldtype = convert_arcgis_field_type(fieldnames_dict[fieldname_old])
        gp.AddField_management(fc, fieldname_new, fieldtype)
        #now copy paste the values

        row = gp.UpdateCursor(fc)
        for item in nens.gp.gp_iterator(row):
            content = item.getValue(fieldname_old)
            if content != None:
                item.SetValue(fieldname_new, content)
                row.UpdateRow(item)

        # now delete the old field
        gp.DeleteField_management(fc, fieldname_old)


def convert_arcgis_field_type(field_type):
    """
    Input is an arcgis field type when reading in a field type.  Strangely
    enough, the same field type can sometimes not be used to create a
    field. this function is written to overcome this malfunction. returns a
    proper field_type to be used in arcgus for the Addfield function
    """
    # convert string to TEXT because arcgis is an inconsistent program (reads
    # in stringtype als fieldtype but does not allow that for adding fields)
    if field_type.lower() == 'string':
        field_type = 'TEXT'
    # convert integer to short because arcgis is an inconsistent program
    # (reads in stringtype als fieldtype but does not allow that for adding
    # fields)
    if field_type.lower() == 'integer':
        field_type = 'LONG'
    if field_type.lower() == 'smallinteger':
        field_type = 'LONG'
    if field_type.lower() == 'single':
        field_type = 'DOUBLE'
    return field_type


def create_line_from_dict(gp, dict_with_points, field_id, fields_to_add,
                          outputfile, type="POLYLINE", workspace_gdb=None):
    """"Deze functie maakt een lijnobject aan in ArcGIS op basis van punten in
    een dictionary. De punten in de dictionary zijn met een unieke code aan
    elkaar gekoppeld example: ('key1':[x1 y1,x2 y])"""

    if workspace_gdb is None:
        workspace_gdb = gp.Workspace
    linearray = gp.CreateObject("ARRAY")
    point = gp.CreateObject("POINT")
    file = os.path.basename(outputfile)
    logger.debug('%s ' % (outputfile))
##    gp.Workspace = workspace_gdb
    logger.debug('%s %s' % (workspace_gdb, file))
    gp.CreateFeatureClass_management(workspace_gdb, file, type)
    file = workspace_gdb + os.sep + file
    gp.AddField_management(file, field_id, "TEXT")

    for k, v in fields_to_add.items():
        if turtlebase.arcgis.is_fieldname(gp, file, k) == True:
            gp.DeleteField_management(file, k)
            logger.debug("Adding field " + str(k))
            gp.AddField_management(file, k, v)
        else:
            logger.info("Adding field " + str(k))
            gp.AddField_management(file, k, v)

    rows_ic = gp.InsertCursor(file)
    if type == 'Point':
        logger.debug(dict_with_points)
        for ovkident in dict_with_points.iterkeys():
            split_items = dict_with_points[ovkident].split(' ')

            point.X = split_items[0]
            point.Y = split_items[1]

            newfeature = rows_ic.NewRow()
            newfeature.shape = point
            newfeature.SetValue(field_id, ovkident)
            rows_ic.InsertRow(newfeature)

    elif type == 'Polyline':
        logger.debug(dict_with_points)
        for ovkident in dict_with_points.iterkeys():
            for item in dict_with_points[ovkident]:

                #logger.info(str(item))
                item_sp = item.split(' ')
                point.X = item_sp[0]
                point.Y = item_sp[1]
                linearray.Add(point)
            newfeature = rows_ic.NewRow()
            newfeature.shape = linearray
            newfeature.SetValue(field_id, ovkident)

            #newfeature.SetValue(leidingidkolom,key)
            rows_ic.InsertRow(newfeature)
            linearray.RemoveAll()
    else:
        logger.error("Unkown type %s" % type)
        sys.exit()


def is_file_of_type(gp, file, type):
    """
    input is a file and the type if should be. type can be polygon, polyline
    or point rturns True when the file is of the type.
    """
    desc = gp.Describe(file)
    if desc.ShapeType == type:
        return True
    else:
        return False


def get_random_file_name(temp_dir, suffix=None):
    """ geeft naam die nog niet voorkomt in de directory"""
    if (os.path.splitext(temp_dir)[1] == '.gdb'
        or os.path.splitext(temp_dir)[1] == '.mdb'):
        suffix = None
        # inside a file geodatabase, overwrite suffix to None
    if suffix == None:
        random_filename = temp_dir + "/" + "".join(
            random.sample(string.ascii_lowercase, 8))
    else:
        random_filename = temp_dir + "/" + "".join(
            random.sample(string.ascii_lowercase, 8)) + suffix
    return random_filename


def get_random_layer_name():
    """
    creates a unique name for an arcgis feature layer
    """
    return "".join(random.sample(string.ascii_lowercase, 8))


def generate_column_with_area(gp, shapefile, field):
    """
    voegt aan de shapefile een field toe met daarin de oppervlaktes van de
    shapes
    """
    gp.AddField_management(shapefile, field, "DOUBLE")

    row = gp.UpdateCursor(shapefile)
    for item in nens.gp.gp_iterator(row):
        area = item.Shape.Area
        # wegschrijven naar veld
        item.setValue(field, area)
        row.UpdateRow(item)


def calculate_area(gp, shapefile, field):
    """
    rekent het oppervlak uit in een bestaande kolom
    """
    row = gp.UpdateCursor(shapefile)
    for item in nens.gp.gp_iterator(row):
        area = item.Shape.Area
        # wegschrijven naar veld
        item.setValue(field, area)
        row.UpdateRow(item)


def calculate_ident(gp, shapefile, input_field1, input_field2, output_field):
    """
    berekent een unieke ident door waarden uit 2 velden aan elkaar te plakken.

    """
    row = gp.UpdateCursor(shapefile)
    for item in nens.gp.gp_iterator(row):
        field1 = getattr(item, input_field1)
        field2 = getattr(item, input_field2)
        output_str = '%s_%s' % (field1, field2)
        item.setValue(output_field, output_str)
        row.UpdateRow(item)


# def extract_feature(gp, fc, select_column, select_id, workspace_gdb):
#     """
#     selects an object from a shapefile or featureclass and returns a
#     featureclass with the selected object
#     """
#     if os.path.dirname(fc)[-4:] == '.mdb':
#         whereclause = "[%s] = '%s'" % (select_column, select_id)
#     else:
#         whereclause = "%s = '%s'" % (select_column, select_id)
#     time_str = time.strftime("%H%M%S")
#     gp.MakeFeatureLayer_management(fc, "layer_%s" % time_str, whereclause)
#     polygon_fc = get_random_file_name(workspace_gdb)
#     gp.Select_analysis("layer_%s" % time_str, polygon_fc)
#     return polygon_fc


def field_availability(gp, config, table, type_of_table):
    """
    Checks a table, and depending on the type checks whether all the required
    fields are available.

    Input is the config object containing the specific fields, the table to
    check and the type of table to check

    Output is a list of missing fields
    """
    missing_fields = []

    if type_of_table == 'input_shapefile':
        required_fields = ['local_area_urban', 'local_area_rural',
                           'ovkident', 'from_x', 'from_y', 'to_x', 'to_y']
        section = 'Columns'

    if type_of_table == 'input_shape_flip':
        required_fields = ['local_area_urban', 'local_area_rural', 'ovkident',
                           'from_x', 'from_y', 'to_x', 'to_y', 'flip_column']
        section = 'Columns'

    # now check whether the required fields are avaible in the table
    tablelist = nens.gp.get_table(gp, table, no_shape=True)
    for required_field in required_fields:
        col_required_field = config.get(section,
                                        required_field).split(',')[0].lower()
        #if not tablelist[0].has_key(col_required_field):
        if col_required_field not in tablelist[0]:
            missing_fields.append(col_required_field)

    return missing_fields


def is_fieldname(gp, tabel, fieldname):
    """checkt of de veldnaam voorkomt in een tabel, return boolean true or
    false"""
    fields = gp.ListFields(tabel)
    fields.reset()
    field = fields.next()
    while field:
        field_name_in_tabel = field.Name
        # check op lower field names to compensate for arcgis <-> python
        # translations to lowercase.
        if field_name_in_tabel.lower() == fieldname.lower():
            return True
        else:
            pass
        field = fields.next()
    return False


def check_deleteFile(gp, logger, filename, attempt=0):
    try:
        if gp.exists(filename):
            gp.delete(filename)

    except Exception, e:
        if attempt < 5:
            logger.debug("deleting temp file %s failed (%s), "
                         "try again (attempt %s)", filename, e, attempt)
            attempt += 1
            check_deleteFile(gp, logger, filename, attempt)
        else:
            logger.warning("deleting temp file %s failed" % filename)
            pass


def remove_tempfiles(gp, logger, list_of_tempfiles):
    """
    removes tempfiles based on a list of filenames.
    """
    for tempfile in list_of_tempfiles:
        logger.debug("Removing ... " + str(tempfile))
        check_deleteFile(gp, logger, tempfile)


def create_temp_geodatabase(gp, workspace):
    time_str = time.strftime("%H%M%S")
    db_name = "%s_%s.gdb" % (TEMP_NAME, time_str)

    workspace_gdb = os.path.join(workspace, db_name)
    try:
        gp.CreateFileGDB_management(workspace, db_name)
        errorcode = 0
    except:
        errorcode = 1
        return workspace_gdb, errorcode

    return workspace_gdb, errorcode


def delete_old_workspace_gdb(gp, workspace):
    """
    search for file geodatabases in the workspace and delete them
    """
    workspace_list = os.listdir(workspace)
    for item in workspace_list:
        if item.startswith(TEMP_NAME) and item.endswith('.gdb'):
            try:
                gp.delete(os.path.join(workspace, item))
                logger.info("%s deleted", item)

            except Exception, e:
                logger.debug("failed to delete %s: %s" % (item, str(e)))


def fc_records(gp, fc):
    """
    counts the amount of records in a shapefile
    """
    count = 0
    row = gp.SearchCursor(fc)
    for item in nens.gp.gp_iterator(row):
        count += 1

    return count

def remove_duplicate_keys(gp, table, field_key):
	"""
	Removes duplicate keys from an attribute table
	"""
	list_keys = []
	row= gp.UpdateCursor(table)
	for item in nens.gp.gp_iterator(row):
		key = item.getValue(field_key)
		if not key in list_keys:
			list_keys.append(key)
		else:
			row.DeleteRow(item)
	


# Used to be called remove_duplicate_records().
def remove_identical_centroid_locations(gp, shapefile):
    """
    Removes duplicate polygons from a shapefile, based on a common centroid.

    This function only checks the centroid, theoretically this could erase
    overlapping polygons which are not equal but do have common centroids.
    """
    duplicate_shape = {}
    float_formatter = FormatFloat()
    row = gp.UpdateCursor(shapefile)
    for item in nens.gp.gp_iterator(row):
        (centroid_x,
         centroid_y) = read_coordinates_from_string(item.shape.centroid)
        centroid_shape = '%s %s' % (float_formatter.format(centroid_x),
                                    float_formatter.format(centroid_y))
        logger.debug("Removing duplicates")

        #if duplicate_shape.has_key(centroid_shape):
        if centroid_shape in duplicate_shape:
            row.DeleteRow(item)
        else:
            duplicate_shape[centroid_shape] = 1


def check_whether_shapefile_has_empty_attribute_table(gp, shapefile):
    """
    deprecated, use fc_is_not_empty
    """
    logger.warning("this function is deprecated, use fc_is_not_empty instead")
    return fc_is_not_empty(gp, shapefile)


def fc_is_not_empty(gp, shapefile):
    """ checks whether shapefile is empty. if empty then it returns a boolean
    False.
    """
    count = 0
    rows = gp.Searchcursor(shapefile)

    row = rows.Next()
    while row:
        count = 1
        # break toevoegen
        break
        row = rows.Next()

    if count == 1:
        return False
    if count == 0:
        return True


def intersect_from_list_of_files(gp, workspace, list_of_files_to_intersect,
                                 output_intersect_file):
    """
    input:
    output:
    usage:
    """
    count = 1
    for file in list_of_files_to_intersect:
        if count == 1:
            merge_list = file
            count = 2
        else:
            merge_list = file + ";" + merge_list

    merge_tempfile = get_random_file_name(workspace, ".shp")

    gp.Merge_management(merge_list, merge_tempfile)
    #in ArcGIS version 9.3 a repair geometry is needed.
    gp.RepairGeometry_management(merge_tempfile)
    gp.Intersect_analysis(merge_tempfile, output_intersect_file)
    del merge_tempfile


def create_select_statement_from_config_for_arcgis(select_field, string):
    """
    Input is a string, directly read with the configparser from an ini file.
    it looks like: 'test, test2, test3'. the select_field is the header of
    column from which the selection has to work.

    output is a where_clause that can be used in arcgis statements like
    select, maketableview, etc

    output example: "type" = 'test' OR "type" = 'test'

    please note that the " and ' in the previous mentioned example are
    required for arcgis. arcgis is very sensitive for syntax errors, leaving
    these " and ' out will be a sure failure for the function:

      >>> print create_select_statement_from_config_for_arcgis('type',
      ...     'test1, test2, test3') # returns previous attractor
      "type" = 'test1' OR "type" = 'test2' OR "type" = 'test3'

    """
    # make a list from the string for iteration purposes
    string_split = string.split(', ')
    select_list = []
    # loop and insert where clause
    for statement in string_split:
        select_list.append('"' + select_field + '"' + ' = ' + "'" +
                           str(statement) + "'")

    #create statement from list
    where_clause = " OR ".join(select_list)
    return where_clause


# als omgeschreven naar algemeen dan naar turtle.arcgis, anders naar
# turtle.urban gp verwijderen als input doctest toevoegen
def create_select_statement_for_use_in_arcgis(gp, duplicate_knp, select_field):
    """
    Creates a select statement that the user can use in arcgis.
    Input is a dictionary like this: duplicate_knp[knp_id][leidingtype] = count

    Knp_id can be many, leidingtype is between 1 and 10, the count is import,
    if ocunt is more than 1, it means it is needed for the select statement.
    """
    where_clause = ""
    count_where_clause = 1
    for knopen in duplicate_knp.keys():
        count = 0
        for knoop in duplicate_knp[knopen].iterkeys():
            count += 1
        if count > 1:
            #meerdere leidingtype per knoop
            #creeer select statements:
            if count_where_clause == 1:
                where_clause = ('\"' + select_field + '\"' + '=' + "'" +
                                str(knopen) + "'")
                count_where_clause += 1
            else:
                where_clause = ('\"' + select_field + '\"' + '=' + "'" +
                                str(knopen) + "'" + " OR " + where_clause)
    return where_clause


# turtlebase.arcgis
# "; ".join(list) toeveogen.
def select_layer(gp, input_shape, select_field, dictionary, key, output_shape,
                 inverse_select=None):
    """ selecteert mbv de sleect tool van arcgis uit een input_shape uit
    select_field de waardes die in de dictionaary onder de layername(key vd
    dictionary) staan in sring als: "xxxx, xxxx, xxx"

    """
    items = dictionary[key]
    count = 1
    splititems = items.split(', ')
    for item in splititems:
        #voeg OR statement toe aan where_clause
        if count == 1:
            count = count + 1
            #eerste statement heeft geen repeterende where_clause
            if inverse_select == 'True':
                where_clause = ('\"' + select_field + '\"' + '<>' + "'" +
                                str(item) + "'")
            else:
                where_clause = ('\"' + select_field + '\"' + '=' + "'" +
                                str(item) + "'")

        else:
            if inverse_select == 'True':
                where_clause = ('\"' + select_field + '\"' + '<>' + "'" +
                                str(item) + "'" + " AND " + where_clause)
            else:
                where_clause = ('\"' + select_field + '\"' + '=' + "'" +
                                str(item) + "'" + " OR " + where_clause)

        #input_file = str(os.path.basename(input_shape))

    gp.Select_analysis(input_shape, output_shape, where_clause)


# turtlebase.arcgis
def read_fieldnames(gp, table):
    """ reads in the headers of a table. returns a dictionary with the headers
    names as keys and the type as value of the dictionary
    """
    output_dict = {}
    fields = gp.ListFields(table)
    fields.reset()
    field = fields.next()
    while field:
        field_name = field.Name
        field_type = field.Type
        # convert field names to lower case
        field_name_lower = field_name.lower()
        output_dict[field_name_lower] = field_type
        field = fields.next()
    return output_dict


def schrijf_centroides_weg_naar_dictionary(gp, nens_gp, polygon_shape,
                                           field_containing_key,
                                           field_containing_key2=None):
    """Leest centroides in uit een vlakkenshape en stopt ze in een dictionary
    met de key uit een veld zoals meegegevens, optioneel kan er op 2 keys
    weggeschreven worden naar een dictionarty. bijvoorbeeld als je per
    peilgebied nog verschillende punten wilt onderscheiden

    """
    dict = {}
    # TODO: rename 'dict': it is a build-in!
##    float_formatter = FormatFloat()
    if field_containing_key2 == None:
        row = gp.SearchCursor(polygon_shape)
        for item in nens_gp.gp_iterator(row):
            key = item.getValue(field_containing_key)
            centroid = item.shape.centroid
            if key not in dict:
                dict[key] = {}
                dict[key]['centroid'] = centroid
        return dict
    else:
        row = gp.SearchCursor(polygon_shape)
        for item in nens_gp.gp_iterator(row):
            key1 = item.getValue(field_containing_key)
            key2 = item.getValue(field_containing_key2)
            centroid = item.shape.centroid
            if key1 not in dict:
                dict[key1] = {}
            dict[key1][key2] = centroid
        return dict


# # turtlebase.urban usage: 1.1.4 and 1.2.1
def reading_line_features_vertices_and_centroids(
    gp, inputFC, field_with_unique_leiding_id, field_peilgebied_id,
    peilgebieden_centroides_dict):
    """ leest de vertices en centroides van een line feature en plaatst de
    coordinaten in een dictionary. per peilgebied worden de knopen
    afzonderlijk opgeslagen:

    outputdictionary = { GPGIDENT: {1:'x1 y1',2:x2 y2'}}
    """
    vertex_dict = {}
    inDesc = gp.describe(inputFC)
    inRows = gp.searchcursor(inputFC)
    inRow = inRows.next()
    count = 0
    logger.debug(inDesc.ShapeType)
    if inDesc.ShapeType == "Point" or inDesc.ShapeType == "Polygon":
        while inRow:
            pntID = inRow.getValue(field_with_unique_leiding_id)
            peilgebied_shapefile = inRow.getValue(field_peilgebied_id)

            #if peilgebieden_centroides_dict.has_key(peilgebied_shapefile):
            if peilgebied_shapefile in peilgebieden_centroides_dict:
                # now read in the centroids
                centroid_line = inRow.Shape.Centroid

                # add to dictionary
                #if not vertex_dict.has_key(peilgebied_shapefile):
                if peilgebied_shapefile not in vertex_dict:
                    vertex_dict[peilgebied_shapefile] = {}
                #if not vertex_dict[peilgebied_shapefile].has_key(pntID):
                if pntID not in vertex_dict[peilgebied_shapefile]:
                    vertex_dict[peilgebied_shapefile][pntID] = []
                vertex_dict[peilgebied_shapefile][pntID].append(centroid_line)

            inRow = inRows.next()

    if inDesc.ShapeType == "Polyline":
        while inRow:
            pntID = inRow.getValue(field_with_unique_leiding_id)
            peilgebied_shapefile = inRow.getValue(field_peilgebied_id)
            #if peilgebieden_centroides_dict.has_key(peilgebied_shapefile):
            if peilgebied_shapefile in peilgebieden_centroides_dict:
                #de gpgident uit de waterlijnenshape komt voor in de
                #dictionary peilgebieden met centroides

                feat = inRow.GetValue(inDesc.ShapeFieldName)
                partnum = 0
                partcount = feat.partcount
                while partnum < partcount:

                    part = feat.getpart(partnum)
                    part.reset()
                    pnt = part.next()
                    pnt_count = 0
                    while pnt:
                        count += 1
                        if peilgebied_shapefile not in vertex_dict:
                            vertex_dict[peilgebied_shapefile] = {}
                        if pntID not in vertex_dict[peilgebied_shapefile]:
                            vertex_dict[peilgebied_shapefile][pntID] = []
                        new_pnt = str(pnt.x) + " " + str(pnt.y)
                        # Sometimes a line in arcgis has multiple points on
                        # the exact same location.

                        if new_pnt not in vertex_dict[
                            peilgebied_shapefile][pntID]:
                            vertex_dict[peilgebied_shapefile][pntID].append(
                                new_pnt)
                        pnt_count += 1
                        pnt = part.next()

                    partnum += 1

                # now read in the centroids
                #centroid_line = inRow.Shape.Centroid
                (centroid_x,
                 centroid_y) = read_coordinates_from_string(
                    inRow.Shape.Centroid)
                centroid_shape = '%s %s' % (str(centroid_x).replace(',', '.'),
                                            str(centroid_y).replace(',', '.'))
                # add to dictionary
                vertex_dict[peilgebied_shapefile][pntID].append(centroid_shape)

            inRow = inRows.next()

    return vertex_dict


#GP
def write_result_to_output(output_table, output_ident, result_dict):
    """replace existing data in output_table
    """
    logger.info("Updating existing records...")
    insert_count, update_progress = turtlebase.arcgis.update_records(
        gp, output_table, output_ident, result_dict)
    logger.info(" - " + str(insert_count) + " records have been updated")

    #put new data in output_table
    logger.info("Inserting new records...")
    update_count, update_progress = turtlebase.arcgis.insert_records(
        gp, output_table, result_dict, update_progress)
    logger.info(" - " + str(update_count) + " records have been inserted")


def update_records(gp, table_name, field_name_id, data, update_progress={}):
    """data: {'1': {'field_name1': 'value1', 'fieldname2': 'value2'}, '2':
    {'field_name3': 'value3', 'fieldname4': 'value4'}} update_progress:
    dictionary that keeps count of the data being inserted {'1': 1, '2': 1}
    use try: except: construction when using this function
    """
    update_count = 0
    rows = gp.UpdateCursor(table_name)
    for row in nens.gp.gp_iterator(rows):
        id = row.GetValue(field_name_id)
        #one row of data
        if str(id) in data:
            for field_name, value in data[str(id)].items():
                if value is not None:
                    row.SetValue(field_name, value)
            update_progress[str(id)] = 1
            update_count = update_count + 1
            rows.UpdateRow(row)

    return update_count, update_progress


def insert_records(gp, table_name, data, update_progress={}):
    """data: {'1': {'field_name1': 'value1', 'fieldname2': 'value2'}, '2':
    {'field_name3': 'value3', 'fieldname4': 'value4'}} update_progress:
    dictionary that keeps count of the data being inserted {'1': 1, '2': 1}
    use try: except: construction when using this function
    """
    update_count = 0
    nsertCursor = gp.InsertCursor(table_name)
    for key, dict_items in data.items():
        if str(key) not in update_progress:
            #new row
            newRow = nsertCursor.NewRow()
            for field_name, value in dict_items.items():
                if value is not None:
                    newRow.SetValue(field_name, value)

            nsertCursor.InsertRow(newRow)
            update_count = update_count + 1
            update_progress[str(key)] = 1
    return update_count, update_progress


def convert_dict_to_csv(table_dict, output_csv):
    """Converts a dictionary with primary key (nens.gp.get_table) to csv file
    """
    # ziet er nogal ingewikkeld uit, maar op deze manier worden alle veldnamen
    # van het eerste object opgehaald uit de dict en weggeschreven als
    # kolomnaam in de csv
    turtlebase.general.add_to_csv(output_csv,
                                  [tuple(table_dict.values()[0].keys())],
                                  "wb")

    csv_file = open(output_csv, 'ab')

    csv_dict = csv.DictWriter(csv_file, table_dict.values()[0])
    for row in table_dict.values():
        csv_dict.writerow(row)
    csv_file.close()

    return output_csv
