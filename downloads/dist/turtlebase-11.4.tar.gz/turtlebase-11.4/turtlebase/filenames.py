# Copyright Nelen & Schuurmans
# GPL licensed, see LICENSE.txt
r"""Checker for filename correctness

(Technical note on the doctest: python's backslash is a real backslash in this
doctest as the strings have an 'r' in front of them, which makes it a
so-called 'raw string'.  So you do not need to escape the backslash by typing
a double \\.)

(Technical note 2: this whole docstring itself ALSO has an 'r' in front of the
triple quotes to prevent the doctest itself from escaping the backslashes
before treating it as a raw string.)

Use this package by importing check_filename and calling the method with a
filename.  If everything's OK, nothing happens.  If there's an error, you'll
get an exception.

If everything's ok, nothing happens:

    >>> from turtlebase.filenames import check_filename
    >>> check_filename(r'c:\turtle\work\shape.shp')

Directory name starts with a digit:

    >>> check_filename(r'c:\1turtle\work\shape.shp'
    ...     ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: '1turtle' starts with a digit: 1
    (c:\1turtle\work\shape.shp)

Filename itself starts with a digit:

    >>> check_filename(r'c:\turtle\work\1shape.shp'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: '1shape.shp' starts with a digit: 1
    (c:\turtle\work\1shape.shp)

Space in the filename or directory name is normally OK:

    >>> check_filename(r'c:\turtle\work\s hape.shp') # doctest:+ELLIPSIS
    >>> check_filename(r'c:\tu rtle\work\shape.shp') # doctest:+ELLIPSIS

But in certain cases, we do not allow spaces:

    >>> check_filename(r'c:\turtle\work\s hape.shp',
    ...                allow_spaces=False
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 's hape.shp' contains a space
    (c:\turtle\work\s hape.shp)

Similary no space in a directory name if we ask for that check:

    >>> check_filename(r'c:\tu rtle\work\shape.shp',
    ...                allow_spaces=False
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 'tu rtle' contains a space
    (c:\tu rtle\work\shape.shp)

Plus or something else strange in the filename:

    >>> check_filename(r'c:\turtle\work\s+hape.shp'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 's+hape.shp' has illegal characters: '+'
    (c:\turtle\work\s+hape.shp)

Some strange character in a directory name:

    >>> check_filename(r'c:\tu^rtle\work\shape.shp'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 'tu^rtle' has illegal characters: '^'
    (c:\tu^rtle\work\shape.shp)

Actual filename (so, the last part) should not be longer than 28 characters:

    >>> check_filename(r'c:\turtle\_23456789012345678901234.678')
    >>> check_filename(r'c:\turtle\_23456789012345678901234.6789'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: '_23456789012345678901234.6789' is longer than
    28 characters (c:\turtle\_23456789012345678901234.6789)

Some combinations are out:

    >>> check_filename(r'c:\turtle\sh--ape.shp'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 'sh--ape.shp' has an illegal combination: '--'
    (c:\turtle\sh--ape.shp)
    >>> check_filename(r'c:\turtle\sh_-_ape.shp'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 'sh_-_ape.shp' has an illegal combination: '_-_'
    (c:\turtle\sh_-_ape.shp)
    >>> check_filename(r'c:\turtle\sh__ape.shp'
    ...                ) # doctest:+ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    InvalidFilenameError: 'sh__ape.shp' has an illegal combination: '__'
    (c:\turtle\sh__ape.shp)

TODO: possibly add logging?

"""

import re
import ntpath  # Note: not os.path, but the windows implementation.
import sys

DIGITS = '0123456789'
FILTER_ALLOWED_CHARS = re.compile(r"""
[     # Start of allowed matches for one character.
a-z   # Lowercase letters.
A-Z   # Uppercase letters.
0-9   # All digits.
_     # Underscore.
\-    # Dash.
\.    # Dot (with a backslash in front as '.' matches everything in a regex).
]     # End of allowed matches for one character.
+     # We want one or more.
""", re.VERBOSE)
MAX_FILE_LENGTH = 28
INVALID_COMBINATIONS = ('--', '__', '_-_')


class InvalidFilenameError(Exception):
    """Custom error, raised for arcgis-invalid filenames"""
    pass


def check_filename(filename, allow_spaces=True):
    """Raise error if filename can cause arcgis errors.

    If you want to check for spaces, too, set allow_spaces to False.

    """
    drive, path = ntpath.splitdrive(filename)
    path_elements = path.split('\\')
    path_elements = [element for element in path_elements
                     if element]
    for path_element in path_elements:
        # Don't start with a digit.
        if path_element[0] in DIGITS:
            msg = "%r starts with a digit: %s (%s)" % (
                path_element, path_element[0], filename)
            raise InvalidFilenameError(msg)
        # Just a-z, numbers, underscore, dot.
        illegal_chars = FILTER_ALLOWED_CHARS.sub('', path_element)
        illegal_chars = [repr(char) for char in illegal_chars]
        if illegal_chars:
            msg = "%r has illegal characters: %s (%s)" % (
                path_element,
                ' and '.join(illegal_chars),
                filename)
            raise InvalidFilenameError(msg)
        # Check for spaces if they're not allowed.
        if not allow_spaces:
            if ' ' in path_element:
                msg = "%r contains a space (%s)" % (path_element, filename)
                raise InvalidFilenameError(msg)
        # Check for some invalid combinations (like double dashes).
        for invalid_combination in INVALID_COMBINATIONS:
            if invalid_combination in path_element:
                msg = "%r has an illegal combination: %r (%s)" % (
                    path_element, invalid_combination, filename)
                raise InvalidFilenameError(msg)

    # Check filename length.
    actual_filename = ntpath.basename(filename)
    if len(actual_filename) > MAX_FILE_LENGTH:
        msg = "%r is longer than %s characters (%s)" % (
            actual_filename, MAX_FILE_LENGTH, filename)
        raise InvalidFilenameError(msg)


def check_cmdline_filenames(allow_spaces=True):
    """Check all filenames specified on the command line

    Warning: only use this if you have no '--help'-like options but really
    only filenames.

    """
    for filename in sys.argv[1:]:
        check_filename(filename, allow_spaces=allow_spaces)
