# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-
"""Goal: make the normal main() method in turtle scripts small.

Before this module, the turtle scripts contained lots of snippets of code that
got repeated in every file. Those snippets are collected here.

"""

import logging
import os
import sys
import ConfigParser

import mock  # Note: 'mock' from pypi, not one of our own custom ones!

arcgisscripting = None
try:
    import arcgisscripting
except:
    pass

logger = logging.getLogger(__name__)


class CaseInsensitiveConfigParser(ConfigParser.SafeConfigParser):
    """Case insensitive section/option ConfigParser.

    Note: only the ``get()`` method is overridden.

    """
    def get(self, wanted_section, wanted_option):
        wanted_section = wanted_section.lower()
        wanted_option = wanted_option.lower()
        section = None
        option = None
        for s in self.sections():
            if s.lower() == wanted_section:
                section = s
        if section is None:
            return None
        for o in self.options(section):
            if o.lower() == wanted_option:
                option = o
        if option is None:
            return None
        return ConfigParser.SafeConfigParser.get(self, section, option)


class ChainedConfigParser(CaseInsensitiveConfigParser):
    """Extends a ConfigParser to retrieve its settings from multiple files.

    """
    def __init__(self, *args, **argv):
        """Set the location of the file that lists the Config directories.

        The master file contains the list of directories that contain Config
        files. This list is ordered, that is, a Config file in a directory in
        this list overrules the Config file with the same name in a directory
        lower in the list.

        Instance parameter argv should contains a keyword argument 'master'
        which should contain the complete path to the master file.

        """
        self.master_filename = argv["master"]
        del argv["master"]
        CaseInsensitiveConfigParser.__init__(self, *args, **argv)

    def read(self, filename):
        """Create and return a ConfigParser for the given Config file.

        This method parses every occurrence of the given file in the
        directories listed in the master file.

        """
        master_file = open(self.master_filename)
        dirs = master_file.readlines()
        master_file.close()

        filenames = [os.path.join(d[:-1], filename) for d in dirs]
        filenames.reverse()

        return CaseInsensitiveConfigParser.read(self, filenames)


def create_geoprocessor():
    """Return an arcgis geoprocessing instance.

    If arcgisscripting is not importable (osx/linux), a mock object is
    returned. "Mock" means http://www.voidspace.org.uk/python/mock/, btw.

    If another mock class is needed (nens also has one!), you can monkeypatch
    ``turtlebase.mainutils.arcgisscripting``.

    """
    arcgisscripting_module = arcgisscripting
    if arcgisscripting is None:
        logger.critical("Arcgisscripting is not available (osx/linux?), "
                        "using a mock instead.")
        arcgisscripting_module = mock.Mock()
    gp = arcgisscripting_module.create()
    gp.OverwriteOutput = 1
    logger.debug("Created arcgis geoprocessing instance.")
    return gp


def read_config(script, ini_filename):
    """Return python ConfigParser instance for the ini file.

    Note that our own case-insensitive config parser is used in the hope that
    that prevents errors from customers that don't stick to the non-obvious
    mix of upper/lowercase letters used in the official section/option names.

    Parameters:

    - **script**: your script's ``__file__`` value.

    - **ini_filename**: something like ``turtle.ini``.

    """
    ini_file = os.path.join(
            os.path.abspath(os.path.dirname(script)),
            ini_filename)
    config = CaseInsensitiveConfigParser()
    config.read(ini_file)
    config.ini_filename = ini_file
    return config


def read_chained_config(filename):
    """Return a ConfigParser with the definitions in the named config file.

    Parameter *filename* is the name of a config file and does not include path
    information. A config file can be present in multiple directories and this
    function tries to read every occurrence to retrieve the definitions. For
    more information, see the docstrings of class ChainedConfigParser

    """
    # We retrieve the directory that contains the master INI file. For a
    # version that cares about local and roaming application directories, see
    # http://snipplr.com/view/7354/get-home-directory-path--in-python-win-lin-other/
    master_filename = os.path.join(os.path.expanduser('~'), "master.txt")
    config = ChainedConfigParser(master_filename)
    config.read(filename)
    return config


def log_filename(config):
    """Return the logging's filename from the config file's parameters."""
    location_temp = config.get('general', 'location_temp')
    filename_log = config.get('general', 'filename_log')
    if filename_log is None:
        filename_log = config.get('general', 'log_file')
    if location_temp is None:
        logger.warn("general:location_temp is not found in config file.")
        return None
    if filename_log is None:
        logger.warn("general:filename_log is not found in config file.")
        return None
    filename = os.path.abspath(os.path.join(location_temp, filename_log))
    return filename


def debuglogging_about_environment():
    """Log info about path locations and environment.

    Lots of errors are/were due to mis-installed copies of the code. Logging
    information about code locations and the os environment helps in debugging
    many installation problems.

    """
    logger.debug("sys.path: %s", sys.path)
    logger.debug("os.environ: %s", os.environ)
    for package in [
        'nens',
        'turtlebase',
        'turtle_urban',
        'turtle_rural',
        'networkx',
        'matplotlib',
        'pyodbc',
        'numpy',
        'scipy',
        'shapely',
        'dbfpy',
        ]:
        try:
            module = __import__(package)
            logger.debug("Location of package %s: %s",
                         package, module.__file__)
        except ImportError:
            logger.debug("Package %s is not available.", package)


def log_info_about_script(name):
    """Log a copyright header and script and argument information.

    Parameter ``name``: just pass in ``__name__`` in your script.

    """
    logger.info("*********************************************************")
    logger.info(name)
    logger.info("This python script is developed by "
             "Nelen & Schuurmans B.V. and is a part of 'Turtle'.")
    logger.info("*********************************************************")
    logger.debug("arguments: %s", sys.argv)
    logger.debug("*********************************************************")


def log_header(name):
    """Combine debuglogging_about_environment() and log_info_about_script().

    Parameter ``name``: just pass in ``__name__`` in your script.

    """
    debuglogging_about_environment()
    log_info_about_script(name)


def log_footer():
    """Log a distinctive 'footer' log message."""
    logger.info("*********************************************************")
    logger.info("Finished")
    logger.info("*********************************************************")
