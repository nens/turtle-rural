# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-

import copy
import logging
import os
import nens.asc
import math

logger = logging.getLogger(__name__)


def _boundaries(waterdiepte, boundaries):
    """Return boundary index below and above waterdiepte.

    >>> boundaries = [-0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.4]
    >>> _boundaries(-20, boundaries)
    (0, 0)
    >>> _boundaries(20, boundaries)
    (7, 7)
    >>> _boundaries(0.4, boundaries)
    (7, 7)
    >>> _boundaries(0, boundaries)
    (3, 3)
    >>> _boundaries(0.05, boundaries)
    (3, 4)

    """
    reversed_boundaries = copy.copy(boundaries)
    reversed_boundaries.reverse()
    below = boundaries[0]
    above = boundaries[-1]
    for boundary in boundaries:
        if boundary <= waterdiepte:
            below = boundary
    for boundary in reversed_boundaries:
        if boundary >= waterdiepte:
            above = boundary
    assert not below > above  # Making sure.
    return boundaries.index(below), boundaries.index(above)


def calculate_schadefactor(waterdiepte, schadefuncties, lgncode):
    """
    """
##    boundaries = []
##    for i in range(9):
##        wlevel = (schadefuncties[0]['sr%s' % (i + 2)]) / 10
##        boundaries.append(wlevel)
    boundaries = [-0.4, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3]
    index_below, index_above = _boundaries(waterdiepte, boundaries)
    value_below = boundaries[index_below]
    code_below = 'sr%d' % (index_below + 1)
    code_above = 'sr%d' % (index_above + 1)
    schadefactor_below = schadefuncties[lgncode][code_below]
    schadefactor_above = schadefuncties[lgncode][code_above]
    perc = abs(waterdiepte - value_below)
    schadefactor1 = (1 - perc) * schadefactor_below
    schadefactor2 = perc * schadefactor_above
    schadefactor = schadefactor1 + schadefactor2
    return schadefactor


def schade_per_gridcel(lgncode, waterstand, streefpeil,
                       maaiveld, schadefuncties, surface_gridcel):
    """
    """
    if waterstand > streefpeil:
        waterdiepte = waterstand - maaiveld

        schadefactor = calculate_schadefactor(
            waterdiepte, schadefuncties, lgncode)

        max_schade_per_ha = schadefuncties[lgncode]['maxschade']
        max_schade_per_gridcel = max_schade_per_ha * surface_gridcel

        schade_totaal = schadefactor * max_schade_per_gridcel
        if waterdiepte > 0:
            schade_inundatie = schadefactor * max_schade_per_gridcel
        else:
            schade_inundatie = 0

        return schade_totaal, schade_inundatie

    else:
        return 0, 0


def exceedence(x0, beta, level):
    p_exc = 1.0 - math.exp(- (math.exp(- ((level - x0) / beta))))

    return p_exc


def p_exc(x0, beta, level):

    try:
        y = exceedence(x0, beta, (level))
    except:
        logger.debug("x0: %s" % x0)
        logger.debug("beta: %s" % beta)
        logger.debug("level: %s" % level)
        y = 0

    return y


def calculate_risk(x0, beta, streefpeil, afkaphoogte, mv10,
           lgncode, schadefuncties, cellsize, maaiveld):
    """
    """
    level = (mv10 + streefpeil) / 2
    risico_gridcel = 0
    risico_inundatie_gridcel = 0

    surface_gridcel = (float(cellsize) ** 2) / 10000.0
    step = 0.05
    k = p_exc(float(x0), float(beta), float(level))
    calc_kans = 0
    while level <= afkaphoogte:
        level += step
        if level >= afkaphoogte:
            calc_kans = k
            calc_level = afkaphoogte
        else:
            calc_kans = k - p_exc(float(x0), float(beta), float(level))
            k = p_exc(float(x0), float(beta), float(level))
            calc_level = level - 0.5 * step

        gevolg, gevolg_inundatie = schade_per_gridcel(
            lgncode, calc_level, streefpeil,
            maaiveld, schadefuncties, surface_gridcel)

        risk = calc_kans * gevolg
        risk_inundation = calc_kans * gevolg_inundatie
        risico_gridcel += risk
        risico_inundatie_gridcel += risk_inundation

    return risico_gridcel, risico_inundatie_gridcel


def create_risk_grid(ahn, lgn, peilgebied, rr_peilgebied, rr_maaiveld,
                     hymstat, gpg_conv, schadefuncties,
                     output_risico_asc, output_risico_in_asc, cellsize):
    """
    """

    ahn_asc = nens.asc.AscGrid(file(ahn))
    number_of_cols = ahn_asc.ncols
    number_of_rows = ahn_asc.nrows
    number_of_cells = number_of_cols * number_of_rows

    lgn_asc = nens.asc.AscGrid(file(lgn))
    peilgeb_asc = nens.asc.AscGrid(file(peilgebied))

    risico_asc = ahn_asc.copy()
    risico_asc.srcname = os.path.basename(output_risico_asc)
    risico_inundation_asc = ahn_asc.copy()
    risico_inundation_asc.srcname = os.path.basename(output_risico_in_asc)
    cell = 0
    counter = 0

    risico_tbl = {}

    logger.info(" - start calculation")
    for col_index in range(number_of_cols):

        col = col_index + 1  # index is base 0, col is base 1
        for row_index in range(number_of_rows):
            cell += 1
            counter += 1
            if counter == 100000:
                logger.info(" - processed %s of %s cells",
                            cell, number_of_cells)
                counter = 0

            row = row_index + 1  # index is base 0, row is base 1

            try:
                id_int = int(peilgeb_asc[col, row])
            except:
                id_int = None
            if id_int is None:
                continue

            try:
                maaiveld = float(ahn_asc[col, row] / 100)
                int(maaiveld)
            except:
                maaiveld = None
            if maaiveld is None:
                continue

            try:
                lgncode = int(lgn_asc[col, row])
            except:
                lgncode = None
            if lgncode is None:
                continue

            if lgncode not in range(47):
                logger.debug("lgncode not in range 1-47, using lgncode = 1")
                lgncode = 1

            if id_int in gpg_conv:
                gpgident = gpg_conv[id_int]['gpgident']
                x0 = hymstat[gpgident]['Location par. x0']
                beta = hymstat[gpgident]['Scale par. beta']
                streefpeil = float(rr_peilgebied[gpgident]['zomerpeil'])
                # wd = streefpeil - maaiveld
                afkaphoogte = float(rr_peilgebied[gpgident]['afkap'])
                mv10 = float(rr_maaiveld[gpgident]['mv_hgt_10'])

                if beta > 0.000001:
                    risico_value, risico_inundation_value = calculate_risk(
                        x0, beta, streefpeil,
                        afkaphoogte, mv10,
                        lgncode, schadefuncties,
                        cellsize, maaiveld)
                else:
                    risico_value = 0
                    risico_inundation_value = 0

                # Write risc_values to output ascii files
                risico_asc[col, row] = risico_value
                risico_inundation_asc[col, row] = risico_inundation_value

                # Write risc_values to dictionary
                if gpgident in risico_tbl:
                    if lgncode in risico_tbl[gpgident]:
                        risico_tbl[gpgident][lgncode][
                            'risico_gw'] += risico_value
                        risico_tbl[gpgident][lgncode][
                            'risico_in'] += risico_inundation_value
                    else:
                        risico_tbl[gpgident][lgncode] = {
                            'risico_gw': risico_value,
                            'risico_in': risico_inundation_value}

                else:
                    risico_tbl[gpgident] = {lgncode: {
                            'risico_gw': risico_value,
                            'risico_in': risico_inundation_value}}

    logger.info(" - write output to ascii")
    risico_asc.save(destdir=os.path.dirname(output_risico_asc))
    risico_inundation_asc.save(destdir=os.path.dirname(output_risico_in_asc))
    return risico_tbl


def create_risico_dict(input_risico_tbl, schadefuncties,
                       primary_key='gpgident'):
    """convert
    {'gpgident': {'lgncode': {'risico_gw': 'value', 'risico_in': 'value'}
    to:
    {'gpgident': {risk_gw: value, risk_gw_st: value}
    """
    risico_result = {}
    for k, v in input_risico_tbl.items():
        if k not in risico_result:
            risico_result[k] = {primary_key: k, 'ris_gw': 0, 'ris_gw_st': 0,
                                'ris_gw_hl': 0, 'ris_gw_ak': 0,
                                'ris_gw_gr': 0, 'ris_gw_nt': 0,
                                'ris_in': 0, 'ris_in_st': 0,
                                'ris_in_hl': 0, 'ris_in_ak': 0,
                                'ris_in_gr': 0, 'ris_in_nt': 0,
                                }

        for lgncode in v.keys():
            risico_result[k]['ris_gw'] += input_risico_tbl[k][lgncode][
                'risico_gw']
            risico_result[k]['ris_in'] += input_risico_tbl[k][lgncode][
                'risico_in']

            nbwklasse = schadefuncties[lgncode]['k5']
            lgncode_risico = input_risico_tbl[k][lgncode]
            if nbwklasse == 1:
                risico_result[k]['ris_gw_st'] += lgncode_risico['risico_gw']
                risico_result[k]['ris_in_st'] += lgncode_risico['risico_in']
            if nbwklasse == 2:
                risico_result[k]['ris_gw_hl'] += lgncode_risico['risico_gw']
                risico_result[k]['ris_in_hl'] += lgncode_risico['risico_in']
            if nbwklasse == 3:
                risico_result[k]['ris_gw_ak'] += lgncode_risico['risico_gw']
                risico_result[k]['ris_in_ak'] += lgncode_risico['risico_in']
            if nbwklasse == 4:
                risico_result[k]['ris_gw_gr'] += lgncode_risico['risico_gw']
                risico_result[k]['ris_in_gr'] += lgncode_risico['risico_in']
            if nbwklasse == 5:
                risico_result[k]['ris_gw_nt'] += lgncode_risico['risico_gw']
                risico_result[k]['ris_in_nt'] += lgncode_risico['risico_in']

    return risico_result
