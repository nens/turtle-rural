# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-

import os

from turtlebase.mainutils import ChainedConfigParser

if __name__ == '__main__':

    master_filename = os.path.join(os.getcwd(), "master.ini")
    config = ChainedConfigParser(master=master_filename)
    config.read("pieterbase.ini")

    print config.items("main")
