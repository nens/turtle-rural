#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
# this program is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# this program is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
#***********************************************************************
#* Library    : turtle.general
#* Purpose    : turtle library for general tools
#* Function   : general.main
#* Usage      : from turtle import general
#*
#* Project    : Turtle
#*
#* $Id: general.py 19705 2011-04-01 09:38:28Z reinout.vanrees $
#* <Id Rev must be added to svn:keywords>
#*
#* initial programmer :  Jonas van Schrojenstein Lantman
#* initial date       :  20100303
#**********************************************************************
__revision__ = "$Rev: 9663 $"[6:-2]


try:
    import arcgisscripting
    gp = arcgisscripting.create()
except ImportError:
    arcgisscripting = None
    gp = None

import logging
import os
import sys

from turtlebase.mainutils import CaseInsensitiveConfigParser

logger = logging.getLogger(__name__)


def read_ini_headers(filename):
    """\
    ini-file, where parameters belong to subheaders like [hello]
    return 2d dictionary
     '#' and ';;' is comment
    voorbeeld nieuwe header maken: settings['TURTLE'] = {}
    voorbeeld nieuwe variable: settings['SETTINGS']['Nieuw'] = 5
    voorbeeld variable aanpassen: settings['SETTINGS']['OpenwCurve'] = 5

    maybe should switch to the standard configparser
    """
    settings = {}
    section_name = ''
    # dictionary for nameless section - removed before returning
    settings[section_name] = {}

    # read lines
    ini_file = open(filename, "r")
    lines = ini_file.readlines()
    ini_file.close()

    # parse lines and put into settings
    for line in lines:
        line = line.split(';')[0]  # discard all that follows comment tag
        line = line.split('#')[0]  # discard all that follows comment tag
        line_parts = [i.strip() for i in line.split('=')]
        # "a = b = c = d" => ["a", "b", "c", "d"]

        if (len(line_parts) == 1) and (line_parts[0] != ''):
            # it must be a header
            section_name = line_parts[0][1:-1]  # remove []
            settings[section_name] = {}  # initialize section
        if len(line_parts) == 2:
            settings[section_name][line_parts[0]] = line_parts[1]

    # done parsing.  remove nameless section and return object
    del settings['']
    return settings


def extend_options_for_turtle(options, section_name,
                              gpHandlerLevel=logging.INFO,
                              fileHandlerLevel=logging.INFO,
                              consoleHandlerLevel=None,
                              root_settings='turtle-settings.ini',
                              turtletype='rural'):
    """grouping actions always needed when starting a turtle script

    starts logging, reads the standard turtle ini file, sets
    attributes in 'options'.

    returns None in case of error (check options.errorcode for details).
    returns the options object otherwise.
    """
    options.logger = logging.getLogger('nens.%s' % section_name)
    turtleLogger = logging.getLogger('nens')
    turtleLogger.setLevel(logging.DEBUG)
    # log everything - handlers will filter

    if gpHandlerLevel is not None:
        import nens.gp
        hdlr = nens.gp.GpHandler(
            logging.INFO,
            gp,
            format='%(message)s ... %(relativeCreatedSeconds)0.1f seconds')
        hdlr.setLevel(gpHandlerLevel)
        turtleLogger.addHandler(hdlr)

    if consoleHandlerLevel is not None:
        console = logging.StreamHandler()
        console.setLevel(consoleHandlerLevel)
        turtleLogger.addHandler(console)

    try:
        # settings for all turtle tools
        script_full_path = sys.argv[0]
        script_location = (os.path.abspath(os.path.dirname(script_full_path)) +
                           "\\")
        options.turtle_settings_all = read_ini_headers(
            script_location + root_settings)
        if turtletype == 'rural':
            options.turtle_ini = options.turtle_settings_all["GENERAL"]
            options.ini = options.turtle_settings_all[section_name]
        if turtletype == 'urban':
            options.turtle_ini = options.turtle_settings_all["General"]
            options.def_leitype = options.turtle_settings_all[
                "DefinitieLeidingtypes"]
            options.sufhyd = options.turtle_settings_all["Sufhyd"]
            options.dwa_aank = options.turtle_settings_all["DWA_aankoppeling"]
            options.bm = options.turtle_settings_all["BrabantseMethode"]
            options.verhard_opp_huis = options.turtle_settings_all[
                "VerhardOppervlakHuisDefinitie"]

    except RuntimeError:
        options.logger.error("Error reading turtle-settings.ini file, "
                             "does the header [GENERAL] exist?")
        options.errorcode = 5
        return None

    if turtletype == 'rural':
        if missing_keys(options.turtle_ini, ['location_temp', 'filename_log']):
            options.errorcode = 1
            return None

    # -----------------------------------------------------------------------
    # check temporary folder (workspace)
    if not os.path.isdir(options.turtle_ini['location_temp']):
        os.makedirs(options.turtle_ini['location_temp'])

    if fileHandlerLevel is not None:
        if turtletype == 'rural':
            filehandler = (logging.FileHandler(
                    options.turtle_ini['location_temp'] +
                    os.sep +
                    options.turtle_ini['filename_log']))
        else:
            filehandler = logging.FileHandler(
                options.turtle_ini['location_temp'] + os.sep +
                options.turtle_ini['log_file'])
        filehandler.setLevel(fileHandlerLevel)
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        filehandler.setFormatter(formatter)
        # add the handler to the top turtle logger
        turtleLogger.addHandler(filehandler)

    return options


def sort_dict_items_into_list(dictionary, key):
    """
    input: dictionary =
    output: list =

    ## TODO
    ## these doctest lines to not test the function

    >>> adict = {'first':1, 'second':2,'third':3, 'fourth': 4}
    >>> adict
    {'second': 2, 'fourth': 4, 'third': 3, 'first': 1}
    >>> sorted(adict.iteritems(), key=lambda (k,v):(v,k))
    [('first', 1), ('second', 2), ('third', 3), ('fourth', 4)]
    >>> sorted(adict.iteritems(), key=lambda (k,v):(v,k), reverse=True)
    [('fourth', 4), ('third', 3), ('second', 2), ('first', 1)]
    """
    list = sorted(dictionary[key].iteritems(), key=lambda (k, v): (v, k))
    return list


def convert_ini_settings_to_dictionary(input_list_ini_settings):
    output_dict = {}
    for items in input_list_ini_settings:
        for item in items:
            if item[0] not in output_dict:
                output_dict[str(item[0])] = item[1]
    return output_dict


def add_to_csv(output_csv, csv_data, write_or_append):
    """
    Will create a csv file when write_or_append = 'wb'. Choose binairy! Adds a
    line to an existing csv file when write_or_append = 'ab'.
    output_csv = "c:\\test\\output.csv" (output location of the csv file)
    (list with tuples, will be added to csv)
    """
    import csv
    csv_file = open(output_csv, write_or_append)
    logger.debug((" - add tuple %s to csv" % csv_data))
    writer = csv.writer(csv_file)
    writer.writerows(csv_data)
    csv_file.close()


def read_ini_file(ini_file, section):
    """ Read the ini file and return the ini settings as a dictionary"""
    config = CaseInsensitiveConfigParser()
    config.read(ini_file)
    ini_settings = []
    ini_settings.append(config.items(section))
    return ini_settings


def missing_keys(dictionary, expected_keys):
    """ini file validation: are all necessary fields present?

    input: dictionary (from ini file), expected_keys (a list)
    output: list of all missing keys (empty means OK)
    """

    return [k for k in expected_keys if k not in dictionary]
