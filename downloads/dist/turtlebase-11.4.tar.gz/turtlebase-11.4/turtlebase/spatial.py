# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-

import logging
import os

try:
    import arcgisscripting
    gp = arcgisscripting.create()
except ImportError:
    arcgisscripting = None
    gp = None

import nens.asc
import nens.gp
import turtlebase.arcgis
import turtlebase.corestats

logger = logging.getLogger(__name__)
float_formatter = turtlebase.arcgis.FormatFloat()


def check_spatial_analyst(gp):
    if gp.CheckExtension("Spatial") == 'Available':
        gp.addmessage("Spatial Analyst is available and will be checked out")
        gp.CheckOutExtension("Spatial")
    else:
        gp.adderror("Spatial Analyst is not available")


def reclass_lgn_k5(input_ascii, output_ascii, reclass_dict=None):
    """
    changes lgn classes to 5 nbw subclasses
    (0= water, 1= urban, 2= greenhouse, 3= rural, 4= grass, 5=nature)
    """
    if reclass_dict is None:
        reclass_dict = {
            1: {'k5': 4}, 2: {'k5': 3}, 3: {'k5': 3}, 4: {'k5': 3},
            5: {'k5': 3}, 6: {'k5': 3}, 7: {'k5': 3}, 8: {'k5': 2},
            9: {'k5': 2}, 10: {'k5': 2}, 11: {'k5': 5}, 12: {'k5': 5},
            16: {'k5': 0}, 17: {'k5': 0}, 18: {'k5': 1}, 19: {'k5': 1},
            20: {'k5': 5}, 21: {'k5': 5}, 22: {'k5': 1}, 23: {'k5': 5},
            24: {'k5': 1}, 25: {'k5': 1}, 26: {'k5': 1}, 30: {'k5': 5},
            31: {'k5': 5}, 32: {'k5': 5}, 33: {'k5': 5}, 34: {'k5': 5},
            35: {'k5': 5}, 36: {'k5': 5}, 37: {'k5': 5}, 38: {'k5': 5},
            39: {'k5': 5}, 40: {'k5': 5}, 41: {'k5': 5}, 42: {'k5': 5},
            43: {'k5': 5}, 44: {'k5': 4}, 45: {'k5': 5}, 46: {'k5': 5}}

    grid = nens.asc.AscGrid(file(input_ascii))
    number_of_cols = grid.ncols
    number_of_rows = grid.nrows

    new_ascii = grid.copy()
    new_ascii.srcname = os.path.basename(output_ascii)

    cursor_col = 1
    while cursor_col < (number_of_cols + 1):
        cursor_row = 1
        while cursor_row < (number_of_rows + 1):
            add_value = grid[cursor_col, cursor_row]
            if add_value in reclass_dict:
                new_ascii[cursor_col, cursor_row] = (
                            reclass_dict[add_value]['k5'])
            cursor_row += 1
        cursor_col += 1
    new_ascii.save(destdir=os.path.dirname(output_ascii))


def calculcate_toetspunten(ahn_ascii, lgn_k5_ascii, id_int_ascii,
                           toetspunten_fields, target_level_dict,
                           onderbemaling="#"):
    """
    """
    field_range = [1, 5, 10]
    scurve_urban_dict = surface_level_statistics(
            ahn_ascii, id_int_ascii, target_level_dict,
            field_range, lgn_ascii=lgn_k5_ascii, lgn_klasse=1)
    scurve_agriculture_dict = surface_level_statistics(
        ahn_ascii, id_int_ascii, target_level_dict,
        field_range, lgn_ascii=lgn_k5_ascii, lgn_klasse=2)
    scurve_rural_dict = surface_level_statistics(
        ahn_ascii, id_int_ascii, target_level_dict,
        field_range, lgn_ascii=lgn_k5_ascii, lgn_klasse=3)
    scurve_grass_dict = surface_level_statistics(
        ahn_ascii, id_int_ascii, target_level_dict,
        field_range, lgn_ascii=lgn_k5_ascii, lgn_klasse=4)

    toetspunten_dict = {}
    for area_id, values in target_level_dict.items():
        gpgident = values['gpgident']
        toetspunten_dict[gpgident] = {'gpgident': gpgident}
        for fieldname in toetspunten_fields:
            streefpeil = values['targetlevel']
            toetspunt = -999
            if gpgident in scurve_urban_dict:
                if fieldname == "DFLT_I_ST" or fieldname == 'MTGMV_I_ST':
                    toetspunt = scurve_urban_dict[gpgident]['MV_HGT_1']
                elif fieldname == "DFLT_O_ST" or fieldname == 'MTGMV_O_ST':
                    maaiveld_10_proc = scurve_urban_dict[gpgident]['MV_HGT_10']
                    toetspunt = (maaiveld_10_proc + streefpeil) / 2
            if gpgident in scurve_agriculture_dict:
                if fieldname == "DFLT_I_HL" or fieldname == 'MTGMV_I_HL':
                    toetspunt = scurve_agriculture_dict[gpgident]['MV_HGT_1']
                elif fieldname == "DFLT_O_HL" or fieldname == 'MTGMV_O_HL':
                    maaiveld_10_proc = scurve_agriculture_dict[gpgident][
                        'MV_HGT_10']
                    toetspunt = (maaiveld_10_proc + streefpeil) / 2
            if gpgident in scurve_rural_dict:
                if fieldname == "DFLT_I_AK" or fieldname == 'MTGMV_I_AK':
                    toetspunt = scurve_rural_dict[gpgident]['MV_HGT_1']
                elif fieldname == "DFLT_O_AK" or fieldname == 'MTGMV_O_AK':
                    maaiveld_10_proc = scurve_rural_dict[gpgident]['MV_HGT_10']
                    toetspunt = (maaiveld_10_proc + streefpeil) / 2
            if gpgident in scurve_grass_dict:
                if fieldname == "DFLT_I_GR" or fieldname == 'MTGMV_I_GR':
                    toetspunt = scurve_grass_dict[gpgident]['MV_HGT_5']
                elif fieldname == "DFLT_O_GR" or fieldname == 'MTGMV_O_GR':
                    maaiveld_10_proc = scurve_grass_dict[gpgident]['MV_HGT_10']
                    toetspunt = (maaiveld_10_proc + streefpeil) / 2
            toetspunten_dict[gpgident][fieldname] = toetspunt
    return toetspunten_dict


def surface_level_statistics(ahn_ascii, id_int_ascii, target_level_dict,
                             field_range, lgn_ascii=None, lgn_klasse=None):
    """Return a dictionary with surface level statistics.

    output: dict with gpgidents as key and as value fieldrange/percentile.

    """
    id_int = nens.asc.AscGrid(file(id_int_ascii))
    ahn = nens.asc.AscGrid(file(ahn_ascii))
    number_of_cols = id_int.ncols
    number_of_rows = id_int.nrows
    logger.debug("id_int's dimensions: %s, %s.",
                 number_of_cols, number_of_rows)

    if not lgn_ascii is None:
        lgn = nens.asc.AscGrid(file(lgn_ascii))

    area_values = {}

    for cursor_col_index in range(number_of_cols):
        cursor_col = cursor_col_index + 1
        # ^^^ Something somewhere doesn't start counting at 0 but at 1...
        for cursor_row_index in range(number_of_rows):
            cursor_row = cursor_row_index + 1
            if lgn_klasse is not None:
                try:
                    lgn_value = int(lgn[cursor_col, cursor_row])
                    if lgn_value == lgn_klasse:
                        try:
                            id_int_value = int(id_int[cursor_col, cursor_row])
                        except:
                            id_int_value = None
                        if id_int_value is None:
                            continue
                        if not id_int_value in area_values:
                            area_values[id_int_value] = {'values': []}
                        try:
                            ahn_value = float(ahn[cursor_col, cursor_row])
                        except:
                            ahn_value = None
                        if ahn_value is None:
                            continue
                        area_values[id_int_value]['values'].append(
                            ahn_value)
                except:
                    continue
            else:
                try:
                    id_int_value = int(id_int[cursor_col, cursor_row])
                except:
                    id_int_value = None
                if id_int_value is None:
                    continue
                if not id_int_value in area_values:
                    area_values[id_int_value] = {'values': []}
                try:
                    ahn_value = float(ahn[cursor_col, cursor_row])
                except:
                    ahn_value = None
                if ahn_value is None:
                    continue
                area_values[id_int_value]['values'].append(
                    ahn_value)

    scurve_dict = {}
    logger.debug("Found %s values.", len(area_values))
    for area_int_id, v in area_values.items():
        area_id = target_level_dict[area_int_id]['gpgident']
        scurve_dict[area_id] = {'gpgident': area_id}
        if len(v['values']) > 0:
            targetlevel = target_level_dict[area_int_id]['targetlevel']
            stat_list = []

            missing_grid = 0
            total_grid = len(v['values'])

            for level in v['values']:
                if float(level) >= (100 * float(targetlevel)):
                    stat_list.append(float(level))
                else:
                    missing_grid += 1

            percentage = (float(missing_grid) * 100) / float(total_grid)
            scurve_dict[area_id][
                'comments'] = '%0.1f procent beneden streefpeil' % percentage

            if len(stat_list) > 0:
                grid_stats = turtlebase.corestats.Stats(stat_list)
                for mv in field_range:
                    if float(mv) == 0:
                        scurve_dict[area_id]['MV_HGT_%s' % mv] = (
                            grid_stats.min() / 100)
                    elif float(mv) < 100:
                        scurve_dict[area_id]['MV_HGT_%s' % mv] = (
                            grid_stats.percentile(float(mv)) / 100)
                    elif float(mv) == 100:
                        scurve_dict[area_id]['MV_HGT_%s' % mv] = (
                            grid_stats.max() / 100)

            else:
                for mv in field_range:
                    scurve_dict[area_id]['MV_HGT_%s' % mv] = float(targetlevel)
        else:
            scurve_dict[area_id] = {'comments': ''}
            for mv in field_range:
                scurve_dict[area_id]['MV_HGT_%s' % mv] = -999

    return scurve_dict


def create_freeboard_raster(input_ahn_ascii, input_targetlevel_ascii,
                            output_freeboard_ascii):
    """
    creates a new ascii raster with the freeboard level (ahn+targetlevel)/2
    """
    ahn = nens.asc.AscGrid(file(input_ahn_ascii))
    number_of_cols = ahn.ncols
    number_of_rows = ahn.nrows

    targetlevel = nens.asc.AscGrid(file(input_targetlevel_ascii))

    freeboard = ahn.copy()
    freeboard.srcname = os.path.basename(output_freeboard_ascii)

    cursor_col = 1
    while cursor_col < (number_of_cols + 1):
        cursor_row = 1
        while cursor_row < (number_of_rows + 1):
            try:
                ahn_value = float(ahn[cursor_col, cursor_row])
            except:
                ahn_value = None
            if ahn_value is None:
                continue

            try:
                target_level = float(targetlevel[cursor_col, cursor_row])
            except:
                target_level = None
            if target_level is None:
                continue

            target_cm = target_level * 100
            freeboard_value = (ahn_value + target_cm) / 2
            freeboard[cursor_col, cursor_row] = freeboard_value
            cursor_row += 1
        cursor_col += 1
    freeboard.save(destdir=os.path.dirname(output_freeboard_ascii))


def create_inundation_raster(lgn_k5_ascii, ahn_ascii, waterlevel, lgn_klasse,
                             value_if_true, output_ascii, workspace,
                             use_lgn=True):
    """
    if waterlevel > ahn and lgn_class = x:
        value = y
    """
    waterlevel_ascii = turtlebase.arcgis.get_random_file_name(
        workspace, ".asc")
    logger.debug("waterlevel ascii: %s" % waterlevel_ascii)
    gp.RasterToASCII_conversion(waterlevel, waterlevel_ascii)

    lgn = nens.asc.AscGrid(file(lgn_k5_ascii))
    number_of_cols = lgn.ncols
    number_of_rows = lgn.nrows

    ahn = nens.asc.AscGrid(file(ahn_ascii))
    waterlevel = nens.asc.AscGrid(file(waterlevel_ascii))

    inundation = lgn.copy()
    inundation.srcname = os.path.basename(output_ascii)

    cursor_col = 1
    while cursor_col < (number_of_cols + 1):
        cursor_row = 1
        while cursor_row < (number_of_rows + 1):
            if use_lgn == True:
                value_lgn = float_formatter.format(lgn[cursor_col, cursor_row])
                if value_lgn is not None:
                    if value_lgn == float(lgn_klasse):
                        value_waterlevel = float_formatter.format(
                            waterlevel[cursor_col, cursor_row])
                        value_ahn = float_formatter.format(ahn[cursor_col,
                                                               cursor_row])
                        if (value_ahn is not None and
                            value_waterlevel is not None):
                            if (value_waterlevel * 100) > value_ahn:
                                inundation[cursor_col,
                                           cursor_row] = int(value_if_true)

            elif use_lgn == False:
                value_waterlevel = float_formatter.format(
                    waterlevel[cursor_col, cursor_row])
                value_ahn = float_formatter.format(ahn[cursor_col, cursor_row])
                if value_ahn is not None and value_waterlevel is not None:
                    if (value_waterlevel * 100) > value_ahn:
                        inundation[cursor_col, cursor_row] = int(value_if_true)

            cursor_row += 1
        cursor_col += 1
    inundation.save(destdir=os.path.dirname(output_ascii))


def merge_ascii(ascii_list, output_max_grid, workspace):
    """Merge grids by taking the first grid's size and finding minimum values.
    """
    ascii_grids = [nens.asc.AscGrid(file(ascii)) for ascii in ascii_list]

    # We take the first grid file as basis
    number_of_cols = ascii_grids[0].ncols
    number_of_rows = ascii_grids[0].nrows
    output_ascii = ascii_grids[0].copy()
    max_ascii_file = turtlebase.arcgis.get_random_file_name(workspace, ".asc")
    output_ascii.srcname = os.path.basename(max_ascii_file)

    check_if_output_is_empty = []
    for column_index in range(number_of_cols):
        column = column_index + 1  # index is base 0, column is base 1
        for row_index in range(number_of_rows):
            row = row_index + 1  # index is base 0, row is base 1
            values = [ascii_grid[column, row] for ascii_grid in ascii_grids]
            values = [value for value in values if value is not None]
            if len(values) > 0:
                check_if_output_is_empty.append(min(values))
                output_ascii[column, row] = min(values)

    output_ascii.save(destdir=os.path.dirname(max_ascii_file))

    if len(check_if_output_is_empty) != 0:
        gp.ASCIIToRaster_conversion(max_ascii_file, output_max_grid)
        return 0
    else:
        logger.warning("there is no output: %s, because there are no values",
                       output_max_grid)
        return 1


def create_nbw_raster(lgn_k5_ascii, inundatie_ascii, output_ascii):
    """
    """
    lgn_k5 = nens.asc.AscGrid(file(lgn_k5_ascii))
    number_of_cols = lgn_k5.ncols
    number_of_rows = lgn_k5.nrows

    inundatie = nens.asc.AscGrid(file(inundatie_ascii))

    new_ascii = lgn_k5.copy()
    new_ascii.srcname = os.path.basename(output_ascii)

    cursor_col = 1
    while cursor_col < (number_of_cols + 1):
        cursor_row = 1
        while cursor_row < (number_of_rows + 1):
            k5 = lgn_k5[cursor_col, cursor_row]
            hhtijd = inundatie[cursor_col, cursor_row]
            if k5 == 1 and hhtijd < 101 and hhtijd > 0:
                new_ascii[cursor_col, cursor_row] = 1
            elif k5 == 2 and hhtijd < 51 and hhtijd > 0:
                new_ascii[cursor_col, cursor_row] = 2
            elif k5 == 3 and hhtijd < 26 and hhtijd > 0:
                new_ascii[cursor_col, cursor_row] = 3
            elif k5 == 4 and hhtijd < 11 and hhtijd > 0:
                new_ascii[cursor_col, cursor_row] = 4
            else:
                pass
            cursor_row += 1
        cursor_col += 1
    new_ascii.save(destdir=os.path.dirname(output_ascii))


# turtlebase.spatial
def create_euclidean_allocation_polygon_around_line(
    gp, workspace, line_features, unique_field_to_base_eucl_on,
    output_polygon, output_cell_size, extent, range='200'):
    """ creates a eucldiean allocation polygon around a line_feature
    """
    #check out spatial analyst
    check_spatial_analyst(gp)
    tempfile = workspace + "/euc_raster"
    gp.Extent = extent

    gp.EucAllocation_sa(line_features, tempfile, range, "", output_cell_size,
                        unique_field_to_base_eucl_on)

    gp.RasterToPolygon_conversion(tempfile, output_polygon, "SIMPLIFY")
    gp.Delete(tempfile)
    gp.CheckinExtension("spatial")


def cut_out_onderbemaling(input_file, cutout_file, workspace):
    """
    if value in cutout_asc == 1, cutout value of input_asc
    """
    input_asc = nens.asc.AscGrid(file(input_file))
    number_of_cols = input_asc.ncols
    number_of_rows = input_asc.nrows

    cutout_asc = nens.asc.AscGrid(file(cutout_file))

    output_asc = input_asc.copy()
    output_file = turtlebase.arcgis.get_random_file_name(workspace, ".asc")
    output_asc.srcname = os.path.basename(output_file)

    for column_index in range(number_of_cols):
        column = column_index + 1  # index is base 0, column is base 1
        for row_index in range(number_of_rows):
            row = row_index + 1  # index is base 0, row is base 1
            if cutout_asc[column, row] != 1:
                output_asc[column, row] = input_asc[column, row]

    output_asc.save(destdir=os.path.dirname(output_file))

    return output_file
