#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
# this program is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# this program is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
#***********************************************************************
#* Library    : turtle.network
#* Purpose    : turtle library for network analysis tools
#* Function   : network.main
#* Usage      : from turtle import network
#*
#* Project    : <code of the project for budget>
#*
#* $Id: network.py 16262 2010-12-16 14:26:35Z reinout.vanrees $
#* <Id Rev must be added to svn:keywords>
#*
#* initial programmer :  Coen Nengerman
#* initial date       :  20100125
#**********************************************************************
__revision__ = "$Rev: 16262 $"[6:-2]

import logging
logger = logging.getLogger(__name__)
logger.debug('loading module')
import copy
import networkx
import math

FROM = 0
TO = 1

LOCAL_COMMODITY = 0
CUMUL_COMMODITY = 1
ENTERING_EDGES_COUNT = 2
INTWIS_EDGE_ID = 3


def cumulate_commodity(accumulator, operand, divider):
    """takes two commodity vectors and a divider

    returns the accumulator incremented by operand/divider

    >>> cumulate_commodity((0,0,0), (1,1,1), 1)
    (1.0, 1.0, 1.0)
    >>> cumulate_commodity((0,2,4), (2,0,0), 2)
    (1.0, 2.0, 4.0)
    >>> cumulate_commodity((1,2,4), (4,8,0), 4)
    (2.0, 4.0, 4.0)
    """

    return tuple([a_i + float(o_i) / divider for (a_i, o_i) in
                  zip(accumulator, operand)])


# turtlebase.network check usage, not used in turtleurban. left as is.
def create_station_point_string(P0, P1, d):
    """gegeven P0 en P1 (twee punten) en het afstand d, berekent P op segment
    P0->P1 op afstand d uit P0.

    P0 en P1 zijn ArcGIS punten, misschien hebben ze een .x en .y field,
    anders gezien als strings.

    >>> create_station_point_string('0.0 0.0', '2.0 2.0', 0)
    '0.0 0.0'
    >>> create_station_point_string('0 0', '3 4', 10)
    '6.0 8.0'
    >>> create_station_point_string('0 0', '6 8', 5)
    '3.0 4.0'
    """
    try:
        x0, y0 = P0.x, P0.y
    except:
        x0, y0 = read_coordinates_from_string(P0)
    try:
        x1, y1 = P1.x, P1.y
    except:
        x1, y1 = read_coordinates_from_string(P1)

    # vector P0->P1
    vx = x1 - x0
    vy = y1 - y0

    # unit vector u op P0->P1
    l = math.sqrt(vx * vx + vy * vy)
    ux = vx / l
    uy = vy / l

    result = str(x0 + ux * d) + ' ' + str(y0 + uy * d)
    return result


def create_station_point(P0, P1, d):
    """gegeven P0 en P1 (twee punten) en het afstand d, berekent P op segment
    P0->P1 op afstand d uit P0.

    P0 en P1 zijn 2-tuples.

    >>> create_station_point((0, 0), (2, 2), 0)
    (0.0, 0.0)
    >>> create_station_point((0, 0), (3, 4), 10)
    (6.0, 8.0)
    >>> create_station_point((0, 0), (6, 8), 5)
    (3.0, 4.0)
    >>> create_station_point((6, 8), (0, 0), 5)
    (3.0, 4.0)
    """
    x0, y0 = P0
    x1, y1 = P1

    # vector P0->P1
    vx = x1 - x0
    vy = y1 - y0

    # unit vector u op P0->P1
    l = math.sqrt(vx * vx + vy * vy)
    ux = vx / l
    uy = vy / l

    return (x0 + ux * d, y0 + uy * d)


def distance(O, P):
    """cartesian distance

    >>> distance((0,0), (3,4))
    5.0
    >>> distance((-3,-4), (3,4))
    10.0
    >>> distance((-1,-3), (4,9))
    13.0
    """

    return math.sqrt(sum([pow(o_i - p_i, 2) for (o_i, p_i) in zip(O, P)]))


def densify_segment(O, P, density):
    """gets a segment and returns it densified

    a minimal amount of points is added on the segment P-O so that
    each point is at no more than density from the next one

    >>> densify_segment((0, 0), (10, 0), 10)
    [(0.0, 0.0), (10.0, 0.0)]
    >>> densify_segment((0, 0), (10, 0), 9)
    [(0.0, 0.0), (5.0, 0.0), (10.0, 0.0)]
    >>> densify_segment((0, 0), (60, 0), 20)
    [(0.0, 0.0), (20.0, 0.0), (40.0, 0.0), (60.0, 0.0)]
    >>> densify_segment((0, 0), (70, 0), 20)
    [(0.0, 0.0), (17.5, 0.0), (35.0, 0.0), (52.5, 0.0), (70.0, 0.0)]
    >>> densify_segment((0, 0), (0, 0), 20)
    [(0.0, 0.0)]
    >>> densify_segment((0, 0), (0, 1e-27), 5000000)
    [(0.0, 0.0), (0.0, 1e-27)]
    """

    segment_length = distance(O, P)
    if segment_length == 0:
        return [tuple(float(i) for i in O)]
    desired_amount = int(math.ceil(segment_length / density))
    step = segment_length / desired_amount
    return [create_station_point(O, P, step * i)
            for i in range(desired_amount + 1)]


def densify_multiline(pnt_list, density=10.0):
    """gets a list of points and returns it densified

    the path described by input and output is the same.

    in the returned list no two points are at distance more than the
    given density.  per segment, the added points are equally spaced.
    a minimal amount of points is added.

    >>> densify_multiline([(0,0), (40,0)])
    [(0.0, 0.0), (10.0, 0.0), (20.0, 0.0), (30.0, 0.0), (40.0, 0.0)]
    >>> densify_multiline([(0,0), (40,0), (40, 20)])
    [(0.0, 0.0), (10.0, 0.0), (20.0, 0.0), (30.0, 0.0), (40.0, 0.0), (40.0, 10.0), (40.0, 20.0)]
    >>> densify_multiline([(0,0), (35,0), (35, 20)])
    [(0.0, 0.0), (8.75, 0.0), (17.5, 0.0), (26.25, 0.0), (35.0, 0.0), (35.0, 10.0), (35.0, 20.0)]
    """

    result = [tuple(float(x) for x in pnt_list[0])]
    segments = zip(pnt_list, pnt_list[1:])
    for origin, destination in segments:
        result.extend(densify_segment(origin, destination, density)[1:])

    return result


class MagneticPointsPool:
    """a magnetic 2D points pool

    >>> pool = MagneticPointsPool(0.5)
    >>> pool((0,0)) # defines new attractor and returns it
    '(0.000,0.000)'

    >>> pool((1.5,0)) # defines new attractor and returns it
    '(1.500,0.000)'

    >>> pool((0.3,0)) # returns previous attractor
    '(0.000,0.000)'

    >>> pool((1.4,0)) # returns previous attractor
    '(1.500,0.000)'

    # (0.3, 0.0) in class (0.0, 0.0) is nearer than 0.5 but keep it
    # simple and choose not to look for it
    >>> pool((0.6,0))
    '(0.600,0.000)'
    """

    def __init__(self, tolerance):
        logger.debug("tolerance: type=%s, value=%s" % (type(tolerance),
                                                       tolerance))
        self.tolerance = tolerance
        self.attractors = {}
        self.format = "(%0.3f,%0.3f)"

    def __call__(self, point):
        logger.debug(point)
        if not self.attractors:
            this_point = self.format % point
            self.attractors[point] = True
        else:
            d, closest_point = min([(distance(x, point), x)
                                    for x in self.attractors.keys()])
            if d < self.tolerance:
                this_point = self.format % closest_point
            else:
                self.attractors[point] = True
                this_point = self.format % point
        logger.debug(this_point)
        return this_point


def import_dbf_into_graph(config, dbf_name, tolerance):
    """reads a dbf and returns a networkx directed graph
    uses the config object to collect the correct field names

    the information associated to each edge is:
    0: the directely linked commodity
    1: the cumulative commodity
    2: the amount of edges entering the 'from' node.
    3: edges unique identifer within intwis

    """
    # dbfpy.py wordt alleen in deze functie gebruikt.
    import dbfpy.dbf

    result = networkx.DiGraph()
    table = dbfpy.dbf.Dbf(dbf_name, readOnly=True)
    pool = MagneticPointsPool(tolerance)

    col_som_sted = config.get('Columns', 'local_area_urban').split(',')[0]
    col_som_land = config.get('Columns', 'local_area_rural').split(',')[0]
    col_from_x = config.get('Columns', 'from_x').split(',')[0]
    col_from_y = config.get('Columns', 'from_y').split(',')[0]
    col_to_x = config.get('Columns', 'to_x').split(',')[0]
    col_to_y = config.get('Columns', 'to_y').split(',')[0]
    col_ovkident = config.get('Columns', 'ovkident').split(',')[0]

    for rowno in range(len(table)):
        row = table[rowno]

        commodity = (row[col_som_sted], row[col_som_land])
        node_from = pool((row[col_from_x], row[col_from_y]))
        node_to = pool((row[col_to_x], row[col_to_y]))
        intwis_id = row[col_ovkident]

        result.add_edge(node_from, node_to, {
                LOCAL_COMMODITY: commodity,
                CUMUL_COMMODITY: commodity,
                INTWIS_EDGE_ID: intwis_id})

    for node_from, node_to in result.edges():
        result[node_from][node_to][ENTERING_EDGES_COUNT] = len(
            result.predecessors(node_from))

    return result


def create_test_graph(l):
    """creates a graph from l

    l contains a list of 3-tuples: from, to, local_commodity

    >>> G = create_test_graph([('a', 'b', 4), ('a', 'c', 4), ('b', 'c', 5),
    ...     ('c', 'd', 3)])
    >>> G.edges()
    [('a', 'c'), ('a', 'b'), ('c', 'd'), ('b', 'c')]
    >>> G.edges(data=True)
    [('a', 'c', {0: (1, 4, 0), 1: (1, 4, 0), 2: 0, 3: 'a.c'}), ('a', 'b', {0: (1, 4, 0), 1: (1, 4, 0), 2: 0, 3: 'a.b'}), ('c', 'd', {0: (1, 3, 0), 1: (1, 3, 0), 2: 2, 3: 'c.d'}), ('b', 'c', {0: (1, 5, 0), 1: (1, 5, 0), 2: 1, 3: 'b.c'})]
    """

    G = networkx.DiGraph()
    for node_from, node_to, value in l:
        G.add_edge(node_from, node_to, {
                LOCAL_COMMODITY: (1, value, 0),
                INTWIS_EDGE_ID: node_from + '.' + node_to,
                CUMUL_COMMODITY: (1, value, 0)})
    for node_from, node_to in G.edges():
        G[node_from][node_to][ENTERING_EDGES_COUNT] = len(
            G.predecessors(node_from))
    return G


def let_it_stream(g):
    """computes cumulative commodity for all edges

    picks up an edge with no incoming edges and sums its commodity to
    its downstream edges.

    >>> G = create_test_graph([('a', 'b', 4), ('a', 'c', 4), ('b', 'c', 5), ('c', 'd', 3)])
    >>> let_it_stream(G)
    ([('c', 'd')], [])
    >>> G.edges(data=True)
    [('a', 'c', {0: (1, 4, 0), 1: (1, 4, 0), 2: 0, 3: 'a.c'}), ('a', 'b', {0: (1, 4, 0), 1: (1, 4, 0), 2: 0, 3: 'a.b'}), ('c', 'd', {0: (1, 3, 0), 1: (4.0, 16.0, 0.0), 2: 0, 3: 'c.d'}), ('b', 'c', {0: (1, 5, 0), 1: (2.0, 9.0, 0.0), 2: 0, 3: 'b.c'})]

    # what happens in case of a loop with entering and leaving edges?
    # the function localizes the loop and informs us which edges have
    # are downstream of the loop
    >>> G = create_test_graph([('0', 'a', 4), ('a', 'b', 4), ('c', 'a', 4),
    ...     ('b', 'c', 5), ('c', 'd', 3)])
    >>> let_it_stream(G)
    ([('c', 'd')], [('a', 'b'), ('c', 'a'), ('c', 'd'), ('b', 'c')])

    # this is easier, because there are no downstream edges.
    >>> G = create_test_graph([('a', 'b', 4), ('c', 'a', 4), ('b', 'c', 5),
    ...     ('d', 'c', 3), ('e', 'd', 3), ('f', 'e', 3)])
    >>> let_it_stream(G)
    ([], [('a', 'b'), ('c', 'a'), ('b', 'c')])
    """

    todo = [(node_from, node_to)
            for node_from, node_to in g.edges()
            if g[node_from][node_to][ENTERING_EDGES_COUNT] == 0]

    while todo:
        node_from, node_to = todo.pop()
        downstream_nodes = g.successors(node_to)
        for downstream in downstream_nodes:
            g[node_to][downstream][CUMUL_COMMODITY] = cumulate_commodity(
                g[node_to][downstream][CUMUL_COMMODITY],
                g[node_from][node_to][CUMUL_COMMODITY],
                len(downstream_nodes))
            g[node_to][downstream][ENTERING_EDGES_COUNT] -= 1
            if g[node_to][downstream][ENTERING_EDGES_COUNT] == 0:
                todo.append((node_to, downstream))

    terminals = [e for e in g.edges() if g.successors(e[TO]) == []]
    remaining = [e for e in g.edges()
                 if g[e[FROM]][e[TO]][ENTERING_EDGES_COUNT] != 0]

    return terminals, remaining


def follow_upstream(g, terminals, remaining):
    """make an attempt to follow the upstream

    for all downstream nodes with no exit and with incoming edges,
    face the problem recursively stream up.

    # what happens in case of a loop from which an edge leaves?
    >>> G = create_test_graph([('a', 'b', 4), ('c', 'a', 4), ('b', 'c', 5),
    ...     ('d', 'c', 3), ('e', 'd', 3), ('f', 'e', 3)])
    >>> t, r = let_it_stream(G)
    >>> follow_upstream(G, t, r)
    ([], [('a', 'b'), ('c', 'a'), ('b', 'c')])
    """

    still_todo = set(remaining)
    for e in terminals:
        if g[e[FROM]][e[TO]][ENTERING_EDGES_COUNT] == 0:
            continue

        still_todo.remove(e)
        g[e[FROM]][e[TO]][CUMUL_COMMODITY] = sum_upstream(g, e, still_todo)

    terminals = [e for e in g.edges() if g.successors(e[TO]) == []]
    remaining = [e for e in g.edges()
                 if g[e[FROM]][e[TO]][ENTERING_EDGES_COUNT] != 0]

    return terminals, remaining


def sum_upstream(g, edge, still_todo):
    """recursively add all upstream commodity in the set still_todo
    """

    node_from, node_to = edge
    result = g[node_from][node_to][LOCAL_COMMODITY]
    for downstream in g.successors(node_to):
        g[node_to][downstream][ENTERING_EDGES_COUNT] -= 1
    for upstream in g.predecessors(node_from):
        if (upstream, node_from) not in still_todo:
            continue
        still_todo.remove((upstream, node_from))
        result += sum_upstream(g, (upstream, node_from), still_todo)
    return result


def print_terminals(g, terminals):
    for f, t in terminals:
        print t, g[f][t][CUMUL_COMMODITY]


def print_below_threshold(g, threshold):
    for f, t in g.edges():
        info = g[f][t]
        if info[ENTERING_EDGES_COUNT] != 0:
            continue
        if info[CUMUL_COMMODITY] < threshold:
            print f, t, info[LOCAL_COMMODITY], info[CUMUL_COMMODITY]


def save_result_shapefile(gp, config, g, output_shapefile):
    '''saves the result as a shape file

    # joint de waterlijnen op OVKIDENT
    recall that the result is a graph, we save its edges.
    it uses the config object to get the correct column names

    for each edge, the columns are:
    from_x, from_y: the from-point of the edge
    to_x, to_y: the to-point of the edge
    cumulative: the calculated value
    examined: if it has been considered in the solution
    terminal: if its to-point is a terminal in the flow
    ovkident: edges unique identifer within intwis
    '''

    import nens.gp
    row = gp.UpdateCursor(output_shapefile)

    col_som_sted = config.get('Columns', 'som_sted').split(',')[0]
    col_som_land = config.get('Columns', 'som_land').split(',')[0]
    col_ovkident = config.get('Columns', 'ovkident').split(',')[0]
    col_examined = config.get('Columns', 'examined').split(',')[0]
    col_terminal = config.get('Columns', 'terminal').split(',')[0]
    col_incoming = config.get('Columns', 'incoming').split(',')[0]

    for item in nens.gp.gp_iterator(row):
        ovkident = item.getValue(col_ovkident)

        # loop door de edges om de juiste ovk ident te vinden
        # zie ticket #1233
        for f, t in g.edges():
            if ovkident == g[f][t][INTWIS_EDGE_ID]:
                info = g[f][t]
                item.SetValue(col_examined, info[ENTERING_EDGES_COUNT] == 0)
                item.SetValue(col_terminal, g.successors(t) == [])
                item.SetValue(col_som_sted, info[CUMUL_COMMODITY][0])
                item.SetValue(col_som_land, info[CUMUL_COMMODITY][1])
                item.SetValue(col_incoming, len(g.predecessors(f)))

                row.UpdateRow(item)


# turtlebase.network, used in 1.2.1.
def creating_extra_point_on_vertex_start_and_end_point(logger,
                                                       vertex_dict,
                                                       distance):
    """
    vertex dictionary ziet er als volgt uit:

    waterlijnen_vertex_dict{'EINDHOVEN_88':
        {'00-K20036_00-K2004T': ['164092.889995 381836.100043',
                                 '164133.009995 381895.400043',
                                 '164112.949995481 381865.750043474'],
         '00-J19906_00-J19910': ['163686.879995 382131.460043',
                                 '163679.329995 382100.430043',
                                 '163683.104995481 382115.945043474']}

    bij ieder begin en eindpunt moet een extra punt op de lijn komen op een
    variabele afstand van het begin of eindpunt.  distance is in procenten
    """
    vertex_dict2 = copy.deepcopy(vertex_dict)
    lines = tupleify_area(vertex_dict2)

    for gebied in vertex_dict.keys():

        for leiding in vertex_dict[gebied].keys():
            # read in begin and end point of line and remove them from the list
            logger.debug('vertex_dict[gebied][leiding] %s ',
                         vertex_dict[gebied][leiding])

            point_1 = vertex_dict[gebied][leiding].pop(0)
            point_2 = vertex_dict[gebied][leiding].pop(0)
            # convert to floats
            x1, y1 = read_coordinates_from_string(point_1)
            x2, y2 = read_coordinates_from_string(point_2)
            # calculate line density, the number of points to be put on the
            # line
            density = float(calculate_distance(x1, y1, x2, y2)) / 6
            # 6 is an arbitrary choice.  trial and error suggests this gives
            #the best results for turtle urban

            # Normally in urban sewer there are no multilines. however, in
            # case of 'bad data' it is possible that lines are crossing this
            # can be calculated like a 'normal' waterbody as in rural
            # area. hence multiline
            if len(lines[gebied][leiding]) > 2:
                line_with_extra_point = densify_multiline(
                    lines[gebied][leiding], density)
            else:
                line_with_extra_point = densify_segment(
                    lines[gebied][leiding][0],
                    lines[gebied][leiding][1], density)

            distance_line = (float(calculate_distance(x1, y1, x2, y2)) *
                             (float(distance) / 100))

            extra_point = create_station_point_string(
                point_1, point_2, distance_line)
            vertex_dict[gebied][leiding].append(extra_point)
            extra_point = create_station_point_string(
                point_2, point_1, distance_line)

            vertex_dict[gebied][leiding].append(extra_point)
            # remove original begin and end point (which are at position 0 and
            # 1 in the list

            for point in line_with_extra_point:
                point_string = '%s %s' % (point[0], point[1])
                vertex_dict[gebied][leiding].append(point_string)

    return vertex_dict


def calculate_distance(x1, y1, x2, y2):
    """ berekent de afstand tussen x1 y1 en x2 y2. input zijn de coordinaten
    als floating point """
    import math
    x_kwadraat = math.pow((x1 - x2), 2)
    y_kwadraat = math.pow((y1 - y2), 2)
    distance = math.sqrt(x_kwadraat + y_kwadraat)
    return distance


# turtlebase.network
def floats_from_coordstring(string):
    """Return tuple (x, y) of floats from space-separated string"""
    coords = string.split()
    coords_spl = []
    for coord in coords:
        coords_spl.append(coord.replace(',', '.'))
    return tuple([float(coord) for coord in coords_spl])


# turtlebase.network
def tupleify_area(lines):
    """Return new lines dictionary to contain x, y floats instead of strings
    """
    lines = copy.deepcopy(lines)
    for area in lines.values():
        for lineid in area:
            area[lineid] = tuple([floats_from_coordstring(coords)
                                  for coords in area[lineid]])
    return lines


# turtlebase.network
def candidates(lines, area_id, x, y, search_radius):
    """Return candidates (line ids) for closest lines"""
    #search_radius = 200
    # TODO: ^^^ make this a constant at the top of the file later on
    all_lines = lines[area_id]
    min_x = x - search_radius
    min_y = y - search_radius
    max_x = x + search_radius
    max_y = y + search_radius
    for line_id, line_points in all_lines.items():

        line_x, line_y = line_points[0]
        if not min_x < line_x < max_x:
            continue
        if not min_y < line_y < max_y:
            continue
        yield line_id


# turtlebase.network
def calculate_minimal_distance_between_points(
    vlakken_centroides_dict, waterlijnen_vertex_dict, logger, search_radius):
    """Berekent de afstand tussen 2 punten, de centroide en 1 van de punten
    uit de waterlijnen_punten_dict.  Bewaart het punt met de kortste afstand
    tussen waterlijnen en de centroide_dict

    waterlijnen_vertex_dict= 'RG_ALK_18': {0:
        {0: ['112303.141839 519745.416664'], 1: ['112320.023 519752.125']}
    vlakken_centroides_dict = {
        0: {'centroid': '112677.137948559 520079.397447521'},
        1: {'centroid': '112660.519903 519888.899390734'},

    """
    output_dict = {}

    lines = tupleify_area(waterlijnen_vertex_dict)
    for area_id in vlakken_centroides_dict:
        if not area_id in waterlijnen_vertex_dict:
            continue
        for point_id in vlakken_centroides_dict[area_id]:
            x, y = floats_from_coordstring(
                vlakken_centroides_dict[area_id][point_id])
            closest = 999999999
            found = None

            for candidate in candidates(lines, area_id, x, y, search_radius):
                points = lines[area_id][candidate]
                #logger.info(candidate)
##                if candidate == '0-24R0104_0-24R0102':
##                    logger.info("x %s en y %s" %(x,y))

                for (line_x, line_y) in points:
                    distance = calculate_distance(x, y, line_x, line_y)
##                    logger.info("distance %s candidate %s X %s y %s"
##                    %(distance, candidate, x,y))

                    if distance < closest:
                        closest = distance
                        found = candidate
            if area_id not in output_dict:
                output_dict[area_id] = {}
            output_dict[area_id][point_id] = found

    return output_dict


def read_coordinates_from_string(coord_string):
    """ the coordinates are in a string as follows: 'x y'
        returns de x en y as floating point
        """

    coord_spl = coord_string.split(' ')
    if len(coord_spl) != 2:
        raise IndexError('Number of coordinates must be two')
    x = float(coord_spl[0].replace(',', '.'))
    y = float(coord_spl[1].replace(',', '.'))
    return x, y
