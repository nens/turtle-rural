#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
# this program is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# this program is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the nens libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
#***********************************************************************
#* Library    : turtle.extent
#* Purpose    : Extent checking helper functions
#*
#* Project    : K0115
#*
#* $Id: spatial.py 10141 2010-03-22 13:09:37Z Reinout $
#*
#* initial programmer :  Reinout van Rees
#* initial date       :  2010-03-22
#**********************************************************************
__revision__ = "$Rev: 10141 $"[6:-2]

import logging
import types

logger = logging.getLogger(__name__)

VALID_CUTOUT_EXTENT = 'valid'
EQUAL_CUTOUT_EXTENT = 'equal'


class ExtentError(Exception):
    pass


def check_extent_inclusion(base_extent, cutout_extent):
    """Check whether cutout_extend falls within (or matches) base_extent.

    Areas need to be cut out of a base area.  The cutouts need to be
    completely within the base area for the operation to be valid.  This
    method checks whether at least the cutout extend is within or equal to the
    base extent.

    base_extent and cutout_extent are strings with 4 space-separated numbers:
    xmin, ymin, xmax, ymax.

    If the cutout extent falls within the base extent, VALID_CUTOUT_EXTENT is
    returned.  If equal, EQUAL_CUTOUT_EXTENT.  Make sure to import those two
    codes instead of relying on their string value 'valid' and 'equal'.

    Errors are raised when the cutout falls outside the base.

    Doctest: see ``extent.txt``.

    """
    assert isinstance(base_extent,
                      types.StringTypes), "Base_extent must be a string"
    assert isinstance(cutout_extent,
                      types.StringTypes), "Cutout_extent must be a string"
    base_extent = base_extent.replace(',', '.')
    cutout_extent = cutout_extent.replace(',', '.')
    base_xyxy = [float(item.strip()) for item in base_extent.split()]
    cutout_xyxy = [float(item.strip()) for item in cutout_extent.split()]
    assert len(base_xyxy) == 4, (
        "Base extent %r must consist of 4 items (result: %r)" % (
            base_extent, base_xyxy))
    assert len(cutout_xyxy) == 4, (
        "Cutout extent %r must consist of 4 items (result: %r)" % (
            cutout_extent, cutout_xyxy))

    base_xmin, base_ymin, base_xmax, base_ymax = base_xyxy
    cutout_xmin, cutout_ymin, cutout_xmax, cutout_ymax = cutout_xyxy
    assert base_xmin < base_xmax, "Base x min must be smaller than max"
    assert base_ymin < base_ymax, "Base y min must be smaller than max"
    assert cutout_xmin < cutout_xmax, "Cutout x min must be smaller than max"
    assert cutout_xmin < cutout_xmax, "Cutout x min must be smaller than max"

    # First check equality to get that corner case out of the way.
    if (base_xmin == cutout_xmin and
        base_xmax == cutout_xmax and
        base_ymin == cutout_ymin and
        base_ymax == cutout_ymax):
        logger.debug("Base and cutout extent are equal.")
        return EQUAL_CUTOUT_EXTENT

    # If any cutout min point is greater/equal than a base max point, the
    # whole cutout lies outside it.  Similar for max points smaller/equal than
    # base min points.
    if (cutout_xmin >= base_xmax or
        cutout_ymin >= base_ymax or
        cutout_xmax <= base_xmin or
        cutout_xmax <= base_xmin):
        raise ExtentError("Cutout extent %r is fully outside of the base "
                          "extent %r" % (cutout_extent, base_extent))

    # After the previous check we're sure there's *some* overlap.  Check if
    # cutout falls within the base extent.
    if (cutout_xmin > base_xmin and
        cutout_ymin > base_ymin and
        cutout_xmax < base_xmax and
        cutout_ymax < base_ymax):
        logger.debug("Cutout is fully enclosed in the base extent.")
        return VALID_CUTOUT_EXTENT

    # We're not equal and not fully outside and not fully inside, so we must
    # have a partial overlap.
    raise ExtentError("Cutout extent %r is not completely enclosed by the "
                      "base extent %r" % (cutout_extent, base_extent))
