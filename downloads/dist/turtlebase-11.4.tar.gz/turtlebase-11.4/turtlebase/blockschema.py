#!/usr/bin/python
# -*- coding: utf-8 -*-
#***********************************************************************
#
# This file is part of the turtlebase library.
#
# the turtlebase library is free software: you can redistribute it
# and/or modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation, either version 3 of
# the License, or (at your option) any later version.
#
# the turtlebase library is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the turtlebase libraray.  If not, see
# <http://www.gnu.org/licenses/>.
#
# Copyright 2010 Nelen & Schuurmans
#
#***********************************************************************
#*
#* initial programmer :  Mario Frasca
#* initial date       :  2010-11-04
#**********************************************************************

import logging
import sys
import tempfile
import webbrowser

# import nens.geom
from nens.turtleurbanclasses import HydroObjectFactory
from shapely.geometry.point import Point
from shapely.geometry.polygon import Polygon
from dbfpy import dbf
import nens.turtleurbanclasses
import networkx as nx

from turtlebase import shapefile
from turtlebase.blockschema_builder import generate_picture
from turtlebase.blockschema_builder import generate_urban_picture
from turtlebase.blockschema_builder import retrieve_records_from_mdb
from turtlebase.blockschema_builder import UrbanSchemaBackendGraphviz
from turtlebase.blockschema_builder import SchemaBackendGraphviz

MAX_DB_KEY_LENGTH = 10

logger = logging.getLogger(__name__)


def dictlist_to_dbf(dictlist, dbf_filename):
    """Store a list of simple dicts in a dbf file.

    Requirement: the dicts must all have the same structure.

    Example usage:

        >>> dont_care, filename = tempfile.mkstemp(suffix='.dbf')
        >>> dictlist = [
        ...     {'a': 'Amsterdam', 'b': 25, 'c': 45.7},
        ...     {'a': 'Nieuwegein', 'b': 25004, 'c': 45.0},
        ...     {'a': 'Ulmen', 'b': 3, 'c': 45344443.7},
        ...     ]
        >>> dictlist_to_dbf(dictlist, filename)

    Read it back manually:

        >>> db = dbf.Dbf(filename)
        >>> for record in db:
        ...     print record['a']
        Amsterdam
        Nieuwegein
        Ulmen

    """
    db = dbf.Dbf(dbf_filename, new=True)
    logger.debug("Creating new dbf database %s...", dbf_filename)
    for key, value in dictlist[0].items():
        keyname = key[:MAX_DB_KEY_LENGTH]
        if keyname != key:
            logger.info(
                "Column name %s is too long, it has been shortened to %s.",
                key, keyname)
        if isinstance(value, float):
            field_type = 'F'
            length = 20
        elif isinstance(value, int):
            field_type = 'N'
            length = 18
        else:
            field_type = 'C'
            length = 253
        logger.debug("Added field %s, type %s, length %s.",
                     keyname, field_type, length)
        db.addField((keyname, field_type, length))

    for dict_ in dictlist:
        record = db.newRecord()
        for key, value in dict_.items():
            record[key[:MAX_DB_KEY_LENGTH]] = value
        record.store()
    db.close()
    logger.debug("Finished adding %s records to %s.",
                 len(dictlist), dbf_filename)


def dbf_to_dictlist(dbf_filename):
    """Read database created with dictlist_to_dbf() and return dictlist.

    **Warning**: dbfpy and/or dbf files as such convert all the column names
    to uppercase.  When converting back, we turn it into lowercase.

    Example usage:

        >>> dont_care, filename = tempfile.mkstemp(suffix='.dbf')
        >>> dictlist = [
        ...     {'a': 'Amsterdam', 'B': 25, 'c': 45.7},
        ...     {'a': 'Nieuwegein', 'B': 25004, 'c': 45.0},
        ...     {'a': 'Ulmen', 'B': 3, 'c': 45344443.7},
        ...     ]
        >>> dictlist_to_dbf(dictlist, filename)
        >>> result = dbf_to_dictlist(filename)
        >>> result[1]['b']
        25004
        >>> result[2]['a']
        'Ulmen'

    """
    db = dbf.Dbf(dbf_filename)
    result = []
    for record in db:
        d = {}
        for key, value in record.asDict().items():
            d[key.lower()] = value
        result.append(d)
    return result


def find_container(geometries, node):
    """returns the key of the geometry containing the node

    >>> A = (231000, 553000)
    >>> B = (233000, 553000)
    >>> C = (234000, 552000)
    >>> D = (233000, 551000)
    >>> E = (231000, 551000)
    >>> F = (232000, 552000)

    A-----B
    | 1  / \
    |   / 2 \
    |  F-----C
    | / \ 3 /
    |/ 4 \ /
    E-----D

    >>> from shapely.geometry.polygon import Polygon
    >>> p1 = Polygon([A, B, E, A])
    >>> p2 = Polygon([B, C, F, B])
    >>> p3 = Polygon([C, D, F, C])
    >>> p4 = Polygon([D, E, F, D])
    >>> geometries = {1: p1, 2: p2, 3: p3, 4: p4}

    point falls in the inside of one geometry

    >>> find_container(geometries, {'x': F[0], 'y': 551500})
    4
    >>> find_container(geometries, {'x': F[0], 'y': 552500})
    1
    >>> find_container(geometries, {'x': D[0], 'y': 552500})
    2

    point falls on the border of one or more geometries

    >>> find_container(geometries, {'x': 231000, 'y': 552500})
    [1]
    >>> sorted(find_container(geometries, {'x': F[0], 'y': F[1]}))
    [1, 2, 3, 4]

    point outside all geometries
32
    >>> find_container(geometries, {'x': 234500, 'y': 550000})

    """

    pnt = Point(node['x'], node['y'])
    touched = []
    for geom_id, geom in geometries.items():
        if geom.contains(pnt):
            return geom_id
        if geom.touches(pnt):
            touched.append(geom_id)
    return touched or None


def make_sufhyd_graph(sufhyd_objects):
    """returns the nx.DiGraph that contains all sufhyd information

    >>> objects = HydroObjectFactory.hydroObjectListFromSUFHYD('''\
    ... *AL1
    ... *KNP 010000003092                 234338800  558899000
    ... *KNP 010000003073                 234343200  558908400
    ... *OVS 010000003092   0000003073
    ... *LEI 010000003092   0000003073''')
    >>> G = make_sufhyd_graph(objects)
    >>> sorted(G.nodes())
    ['01_0000003073', '01_0000003092']
    >>> G.edge['01_0000003092']['01_0000003073']['sufhyd_types_here']
    ['*OVS', '*LEI']
    >>> G.edge['01_0000003073']['01_0000003092']['sufhyd_types_here']
    Traceback (most recent call last):
        ...
    KeyError: '01_0000003092'
    """

    G = nx.DiGraph()
    for obj in sufhyd_objects:
        if isinstance(obj, nens.turtleurbanclasses.Vertex):
            node_id, node_info = obj.toNxTuple()
            if not G.has_node(node_id):
                G.add_node(node_id, {})
                G.node[node_id]['sufhyd_types_here'] = []
            G.node[node_id].update(node_info)
            G.node[node_id]['sufhyd_types_here'].append(node_info['ide_rec'])
        elif isinstance(obj, nens.turtleurbanclasses.Edge):
            node_from, node_to, edge_info = obj.toNxTuple()
            if not G.has_edge(node_from, node_to):
                G.add_edge(node_from, node_to, {})
                G.edge[node_from][node_to]['sufhyd_types_here'] = []
            G.edge[node_from][node_to].update(edge_info)
            # TODO: do not overwrite fields
            G.edge[node_from][node_to]['sufhyd_types_here'].append(
                edge_info['ide_rec'])

    # It turns out that are sufhyd files with edges that reference nodes that
    # are present under another ID. We do not know whether that is allowed by
    # the sufhyd specification but we have to handle the case. A quick fix is
    # to remove those nodes.
    first_warning = True
    for node in G.nodes(data=True):
        if not node[1]:
            if first_warning:
                logger.warning("There are sufhyd edges that specify nodes "
                               "that are not present. We remove these edges, "
                               "which are connected to following nodes:")
                first_warning = False
            logger.warning("- %s", node[0])
            G.remove_node(node[0])

    return G


def sanity_check(sufhyd_graph):
    ## TODO #2237
    pass


def make_turtle_graph(G_sufhyd, geometries, feedback=False):
    """given a sufhyd graph and a set of geometries, produce a graph
    where the nodes are the geometries and the links are present if
    there are sufhyd edges that connect objects in different
    geometries.

    additionally, properties from the sufhyd (node or edge) objects
    are cumulated into properties that belong to the nodes of the new
    graph.

    >>> A = (231000, 553000)
    >>> B = (233000, 553000)
    >>> Q = (235000, 553000)
    >>> C = (234000, 552000)
    >>> D = (233000, 551000)
    >>> E = (231000, 551000)
    >>> F = (232000, 552000)

    A-----B-----Q
    | 1  / \   /
    |   / 2 \ /
    |  F-----C
    | / \ 3 /
    |/ 4 \ /
    E-----D

    >>> from shapely.geometry.polygon import Polygon
    >>> p1 = Polygon([A, B, E, A])
    >>> p2 = Polygon([B, C, F, B])
    >>> p3 = Polygon([C, D, F, C])
    >>> p4 = Polygon([D, E, F, D])
    >>> p5 = Polygon([B, Q, C, B])
    >>> geometries = {1: p1, 2: p2, 3: p3, 4: p4, 5: p5}

    knp 010000003x00 falls outside all geometries!
    knp 0100000030ji falls inside geometry i!
    p5 is a geometry that does not contain points.
    inhabitants in p1 and p2

    >>> objects = HydroObjectFactory.hydroObjectListFromSUFHYD('''\
    ... *AL1
    ... *KNP 010000003001                 231500000  552000000                                                                             40
    ... *KNP 010000003011                 231500000  552100000                                                                             20
    ... *KNP 010000003021                 231500000  552200000
    ... *KNP 010000003004                 232000000  551500000
    ... *KNP 010000003003                 233000000  551500000
    ... *KNP 010000003002                 233000000  552500000                                                                             15
    ... *KNP 010000003x00                 243000000  502500000
    ... *AFV 010000003003                               12.75
    ... *LEI 010000003021   0000003002                          00
    ... *LEI 010000003011   0000003021                          01
    ... *LEI 010000003001   0000003004                          02
    ... *LEI 010000003004   0000003003
    ... *LEI 010000003004   0000003x00
    ... *AFV 010000003021   0000003002         31.25                          2.50                         31.75    13.25                 1.75
    ... *GEM 010000003001   0000003004
    ... *GEM 010000003001   0000003002
    ... *GEM 010000003004   0000003003''')
    >>> Gsh = make_sufhyd_graph(objects)

    the nodes of the resulting graph are the given geometries.

    >>> Gt = make_turtle_graph(Gsh, geometries, feedback=True)
    01_0000003001
    01_0000003002
    01_0000003003
    01_0000003004
    01_0000003011
    01_0000003021
    01_0000003x00
    01_0000003001 01_0000003002
    01_0000003001 01_0000003004
    01_0000003004 01_0000003x00
    01_0000003004 01_0000003003
    01_0000003011 01_0000003021
    01_0000003021 01_0000003002
    >>> set(Gt.nodes()) == set(geometries.values())
    True

    gebiedsoverschrijdende edges define the connections between nodes.

    >>> len(Gt.edges())
    3
    >>> (geometries[1], geometries[4]) in Gt.edges()
    True
    >>> (geometries[4], geometries[3]) in Gt.edges()
    True
    >>> (geometries[1], geometries[2]) in Gt.edges()
    True

    expected properties are set in all nodes that contain sufhyd objects.

    >>> sum([1 for n in Gt.nodes() if 'sufhyd_types_here' in Gt.node[n]])
    4
    >>> all(['inhabitants' in Gt.node[n] for n in Gt.nodes()
    ...     if 'sufhyd_types_here' in Gt.node[n]])
    True
    >>> all(['lowest overflow level' in Gt.node[n] for n in Gt.nodes()
    ...     if 'sufhyd_types_here' in Gt.node[n]])
    True

    inhabitants correctly added

    >>> Gt.node[p1]['inhabitants']
    60.0
    >>> Gt.node[p2]['inhabitants']
    15.0
    >>> Gt.node[p3]['inhabitants']
    0.0
    >>> Gt.node[p4]['inhabitants']
    0.0

    afvoerend oppervlak, per type (lei_typ)

    >>> [Gt.node[p1].get('by_type_' + t) for t in ['00', '01', '02', '99']]
    [None, 0.0, None, 0.0]
    >>> [Gt.node[p2].get('by_type_' + t) for t in ['00', '01', '02', '99']]
    [80.5, None, None, 0.0]
    >>> [Gt.node[p3].get('by_type_' + t) for t in ['00', '01', '02', '99']]
    [None, None, None, 12.75]
    >>> [Gt.node[p4].get('by_type_' + t) for t in ['00', '01', '02', '99']]
    [None, None, 0.0, 0.0]

    """

    def str_sum(accumulator, operand, default):
        try:
            operand = float(operand)
        except (ValueError, TypeError):
            operand = default
        return accumulator + operand

    def str_min(accumulator, operand, default):
        try:
            operand = float(operand)
        except (ValueError, TypeError):
            operand = default
        return min(accumulator, operand)

    def set_append(accumulator, operand, default):
        result = set(accumulator)
        return result.union(operand)

    def by_type_name(sufhyd_dict):
        return "by_type_" + (sufhyd_dict.get('lei_typ', '').strip() or '99')

    ## properties is a list of tuples, each element has the fields:
    ## the name of a property (or a function that accepts a sufhyd
    ## object and returns a name), the name of the field holding it,
    ## the aggregating function, default value and the target node
    ## (0==from, 1==to, 2==both) in case the property belongs to an
    ## edge.
    properties = [
        ('inhabitants', 'aan_inw', str_sum, 0.0, 'to'),
        ('roofs', 'dak_hel', str_sum, 0.0, 'to'),
        ('roofs', 'dak_vla', str_sum, 0.0, 'to'),
        ('roofs', 'dak_vlu', str_sum, 0.0, 'to'),
        ('other surfaces', 'gvh_hel', str_sum, 0.0, 'to'),
        ('other surfaces', 'gvh_vla', str_sum, 0.0, 'to'),
        ('other surfaces', 'gvh_vlu', str_sum, 0.0, 'to'),
        ('other surfaces', 'ovh_hel', str_sum, 0.0, 'to'),
        ('other surfaces', 'ovh_vla', str_sum, 0.0, 'to'),
        ('other surfaces', 'ovh_vlu', str_sum, 0.0, 'to'),
        ('other surfaces', 'onv_hel', str_sum, 0.0, 'to'),
        ('other surfaces', 'onv_vla', str_sum, 0.0, 'to'),
        ('other surfaces', 'onv_vlu', str_sum, 0.0, 'to'),
        (by_type_name, 'dak_hel', str_sum, 0.0, 'to'),
        (by_type_name, 'dak_vla', str_sum, 0.0, 'to'),
        (by_type_name, 'dak_vlu', str_sum, 0.0, 'to'),
        (by_type_name, 'gvh_hel', str_sum, 0.0, 'to'),
        (by_type_name, 'gvh_vla', str_sum, 0.0, 'to'),
        (by_type_name, 'gvh_vlu', str_sum, 0.0, 'to'),
        (by_type_name, 'ovh_hel', str_sum, 0.0, 'to'),
        (by_type_name, 'ovh_vla', str_sum, 0.0, 'to'),
        (by_type_name, 'ovh_vlu', str_sum, 0.0, 'to'),
        (by_type_name, 'onv_hel', str_sum, 0.0, 'to'),
        (by_type_name, 'onv_vla', str_sum, 0.0, 'to'),
        (by_type_name, 'onv_vlu', str_sum, 0.0, 'to'),
        ('lowest overflow level', 'ovs_niv', str_min, False, 'from'),
        ('sufhyd_types_here', 'sufhyd_types_here', set_append, set(), 'both'),
        ]

    G = nx.DiGraph()
    G.add_nodes_from(geometries.values())

    for node in G_sufhyd.nodes():
        if feedback:
            print node
        geom_id = find_container(geometries, G_sufhyd.node[node])
        if geom_id:
            geom = geometries[geom_id]
            G_sufhyd.node[node]['container'] = geom
            for name, field, aggregator, default, target in properties:
                if callable(name):
                    name = name(G_sufhyd.node[node])
                G.node[geom][name] = aggregator(
                    G.node[geom].get(name, default),
                    G_sufhyd.node[node].get(field),
                    default)

    for node_from, node_to in G_sufhyd.edges():
        if feedback:
            print node_from, node_to
        geom_from = G_sufhyd.node[node_from].get('container')
        geom_to = G_sufhyd.node[node_to].get('container')
        if geom_from is None or geom_to is None:
            continue
        for name, field, aggregator, default, target in properties:
            if callable(name):
                name = name(G_sufhyd.edge[node_from][node_to])
            target_geoms = {'from': [geom_from],
                            'to': [geom_to],
                            'both': [geom_from, geom_to]}[target]
            for geom in target_geoms:
                G.node[geom][name] = aggregator(
                    G.node[geom].get(name, default),
                    G_sufhyd.edge[node_from][node_to].get(field),
                    default)
        if geom_from != geom_to:
            G.add_edge(geom_from, geom_to)

    return G


def _get_geometries(shapefile_filename):
    """Return geometry dict like nens.geom.get_geometries does.

    However, use the pure-python 'python shapefile library' to do so instead
    of the apparently difficult-to-install-on-windows osgeo.org library.

    """
    result = {}
    reader = shapefile.Reader(shapefile_filename)
    extract = [(index, field[0]) for index, field in enumerate(reader.fields)]
    for index, shape_record in enumerate(reader.shapeRecords()):
        # We expect polygons here.
        if not shape_record.shape.shapeType == shapefile.POLYGON:
            logger.debug("Shape in %s is not a polygon", shapefile_filename)
            continue
        polygon = Polygon(shape_record.shape.points)
        for field_index, field_name in extract:
            try:
                polygon.__dict__[field_name] = shape_record.record[field_index]
            except IndexError:
                # The 'TYPE' field is apparently available in reader.fields,
                # but missing from the records.
                pass
        result[index] = polygon
    return result


def areas_and_connections(sufhyd_filename, shapefile_filename,
                          area_label="PEILVAKID"):
    """Return areas and connections dict from sufhyd and shapefile.

    Parameters:
      * area_label *
        label to identify the areas in the shape file

    The output must be two lists of dicts.  The area dicts must contain a
    ``label``, the connection dicts a ``src`` and ``dst``.

    """
    sufhyd_objects = HydroObjectFactory.hydroObjectListFromSUFHYD(
        open(sufhyd_filename).read())
    logger.debug("Read %s sufhyd objects from %s",
                 len(sufhyd_objects),
                 sufhyd_filename)
    sufhyd_graph = make_sufhyd_graph(sufhyd_objects)
    logger.debug("Calculated sufhyd graph")
    HydroObjectFactory.propagateGeometries(sufhyd_objects)
    # ^^^ TODO: Figure out what "propagating geometries" actually does.
    logger.debug("Propagated geometries")
    #geometries = nens.geom.get_geometries(shapefile_filename)
    geometries = _get_geometries(shapefile_filename)
    logger.debug("Read %s geometries from shapefile %s",
                 len(geometries), shapefile_filename)
    turtle_graph = make_turtle_graph(sufhyd_graph, geometries)
    logger.debug("Created turtle graph")
    areas = []
    connections = []
    first_exception = True
    for node in turtle_graph.nodes():
        area_data = turtle_graph.node[node]
        try:
            area_dict = {
                'label': getattr(node, area_label),
                'Oppervlak': node.area,
                'Aantal inwoners': area_data.get('inhabitants', None),
                'Dakafvoer': area_data.get('roofs', None),
                'Laagste overstortdrempel': area_data.get(
                    'lowest overflow level', None),
                }
            areas.append(area_dict)
        except AttributeError:
            if first_exception:
                logger.warning("We cannot find areas using attribute %s. We " +
                               "skip these areas.", area_label)
                first_exception = False
    logger.debug("Gathered data on %s areas", len(areas))
    for (src, dst) in turtle_graph.edges():
        try:
            connection_data = turtle_graph.edge[src][dst]
            connection_dict = {'src': getattr(src, area_label),
                               'dst': getattr(dst, area_label),
                               'empty_for_now': connection_data}
            connections.append(connection_dict)
        except AttributeError:
            # we already logged the attribute name error so we do not mention
            # it explicitly
            pass
    logger.debug("Gathered data on %s connections", len(connections))
    return areas, connections


def calculate_and_save_blockschema(sufhyd_filename,
                                   shapefile_filename,
                                   areas_dbf_filename,
                                   connections_dbf_filename):
    """Calculate the blockschema and store areas and connections in dbf files.

    This method is called from arcgis.
    """
    areas, connections = areas_and_connections(sufhyd_filename,
                                               shapefile_filename)
    update_incomplete_areas_for_write(areas)
    dictlist_to_dbf(areas, areas_dbf_filename)
    dictlist_to_dbf(connections, connections_dbf_filename)


def create_and_show_blockschema_png(areas_dbf_filename,
                                    connections_dbf_filename,
                                    png_output_filename=None,
                                    open_output_file=True):
    """Render the blockschema png and open it.

    This method is called from arcgis.

    """
    areas = dbf_to_dictlist(areas_dbf_filename)
    connections = dbf_to_dictlist(connections_dbf_filename)
    if png_output_filename is None:
        inode, output_filename = tempfile.mkstemp(suffix='.png')
    schema_backend = SchemaBackendGraphviz(output_filename)
    generate_picture(areas,
                     connections,
                     schema_backend)
    if open_output_file:
        # False for tests that don't want to click something open, obviously.
        webbrowser.open(output_filename)


def save_and_show_rural_blockschema(mdb_filename,
                                    output_filename=None,
                                    open_output_file=True):
    """Save a picture of the rural blockschema specified in the given database.

    Parameters:
    * mdb_filename -- Access database with the areas and connections
    * output_filename -- name of the file to save the block schema to
    * open_output_file -- holds if and only if the blockschema should be shown

    Note that both mdb_filename and output_filename should contain the complete
    filename, that is, include path and extension. If output_filename is not
    specified, this method generates a pdf.

    To determine the picture format, the extension of the output filename is
    used. Several supported extensions (and picture formats) are .png, .jpg,
    .gif, .svg and .pdf.

    """
    area_records, connection_records = retrieve_records_from_mdb(mdb_filename)

    if output_filename is None:
        inode, output_filename = tempfile.mkstemp(suffix='.pdf')
    schema_backend = SchemaBackendGraphviz(output_filename)
    generate_picture(area_records, connection_records, schema_backend)
    if open_output_file:
        webbrowser.open(output_filename)


def save_and_show_urban_blockschema(sufhyd_filename,
                                    shapefile_filename,
                                    output_filename=None,
                                    open_output_file=True):
    """Save a picture of the urban blockschema specified in the given files.

    Parameters:
    * sufhyd_filename --
    * shape_filename --
    * output_filename -- name of the file to save the block schema to
    * open_output_file -- holds if and only if the blockschema should be shown

    Note that all file names contain the complete filename, that is, include
    path and extension. If output_filename is not specified, this method
    generates a pdf.

    To determine the picture format, the extension of the output filename is
    used. Several supported extensions (and picture formats) are .png, .jpg,
    .gif, .svg and .pdf.

    """
    area_records, connection_records = areas_and_connections(
        sufhyd_filename, shapefile_filename)
    log_incomplete_areas(area_records)
    if output_filename is None:
        inode, output_filename = tempfile.mkstemp(suffix='.pdf')
    schema_backend = UrbanSchemaBackendGraphviz(output_filename)
    generate_urban_picture(area_records, connection_records, schema_backend)
    if open_output_file:
        webbrowser.open(output_filename)


def save_and_show_urban_blockschema_main():

    assert len(sys.argv[1:]) == 3
    save_and_show_urban_blockschema(sys.argv[1], sys.argv[2],
                                        output_filename=sys.argv[3],
                                        open_output_file=False)


def save_urban_blockschema_picture_and_data(sufhyd_filename,
                                            shapefile_filename,
                                            picture_filename,
                                            areas_dbf_filename,
                                            connections_dbf_filename):
    """Save a picture of the urban blockschema and export the data.

    Parameters:
      * sufhyd_filename *
      * shape_filename *
      * picture_filename *
        name of the file to save the block schema to
      * areas_dbf_filename *
        name of the dbf file to write the info of the nodes of the blockschema
      * connections_dbf_filename *
        name of the dbf file to write the info of the edges of the blockschema

    This functions uses function ``save_and_show_urban_blockschema`` to save
    the picture. The doc string of that function contains more information
    about the requirements on the filenames and the export picture format.

    """
    area_records, connection_records = \
                  areas_and_connections(sufhyd_filename, shapefile_filename)

    log_incomplete_areas(area_records)
    schema_backend = UrbanSchemaBackendGraphviz(picture_filename)
    generate_urban_picture(area_records, connection_records, schema_backend)

    update_incomplete_areas_for_write(area_records)
    dictlist_to_dbf(area_records, areas_dbf_filename)
    dictlist_to_dbf(connection_records, connections_dbf_filename)


def save_urban_blockschema_picture_and_data_main():

    parameters = sys.argv[1:]
    assert len(parameters) == 5
    save_urban_blockschema_picture_and_data(*parameters)


def log_incomplete_areas(area_records):

    for area_record in area_records:
        inhabitants = area_record['Aantal inwoners']
        roof_surface = area_record['Dakafvoer']
        lowest_overflow_level = area_record['Laagste overstortdrempel']
        if inhabitants is None or \
               roof_surface is None or lowest_overflow_level is None:
            logger.warn("The information for service level area %s is " +
                        "incomplete:", area_record['label'])
        if inhabitants is None:
            logger.warn("- the number of inhabitants will be displayed as '-'")
        if roof_surface is None:
            logger.warn("- the roof surface will be displayed as '-'")
        if lowest_overflow_level is None:
            logger.warn("- the lowest overflow level will be displayed as '-'")


def update_incomplete_areas_for_write(area_records):

    for area_record in area_records:
        if area_record['Aantal inwoners'] is None:
            area_record['Aantal inwoners'] = -1
        if area_record['Dakafvoer'] is None:
            area_record['Dakafvoer'] = -1.0
        if area_record['Laagste overstortdrempel'] is None:
            area_record['Laagste overstortdrempel'] = -1.0


if __name__ == '__main__':
    # Short temporary testing script.
    logging.basicConfig(level=logging.DEBUG)
    sufhyd_filename = sys.argv[1]
    shapefile_filename = sys.argv[2]
    dont_care, dbf_filename1 = tempfile.mkstemp(suffix='.dbf')
    dont_care, dbf_filename2 = tempfile.mkstemp(suffix='.dbf')
    calculate_and_save_blockschema(sufhyd_filename, shapefile_filename,
                                   dbf_filename1, dbf_filename2)
    create_and_show_blockschema_png(dbf_filename1, dbf_filename2)
