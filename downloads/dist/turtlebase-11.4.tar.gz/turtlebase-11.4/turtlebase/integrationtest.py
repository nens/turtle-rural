from turtlebase.blockschema_builder import generate_picture
from turtlebase.blockschema_builder import SchemaBackendGraphviz

from turtlebase.tests.blockschema_builder_tests import area_records
from turtlebase.tests.blockschema_builder_tests import connection_records


def main():
    generate_picture(area_records,
                     connection_records,
                     SchemaBackendGraphviz("afvoer.png"))

if __name__ == "__main__":
    main()
