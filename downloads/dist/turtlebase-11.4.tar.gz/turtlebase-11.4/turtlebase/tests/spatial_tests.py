# -*- coding: utf-8 -*-
from unittest import TestCase

import pkg_resources
from turtlebase.spatial import surface_level_statistics


class SurfaceLevelStatisticsTestCase(TestCase):

    def setUp(self):
        self.field_range = [
            '0', '1', '2', '3', '4', '5', '10', '15', '20', '25', '30', '35',
            '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90',
            '95', '100']
        self.target_level_dict = {
            1: {'targetlevel': -0.94999999999999996, 'gpgident': '04300-02'},
            2: {'targetlevel': -1.05, 'gpgident': '04300-01'},
            }
        self.ahn_filename = pkg_resources.resource_filename(
            'turtlebase', 'testdata/spatial/ahn.asc')
        self.id_filename = pkg_resources.resource_filename(
            'turtlebase', 'testdata/spatial/id.asc')

    def test_a(self):
        result = surface_level_statistics(
            self.ahn_filename,
            self.id_filename,
            self.target_level_dict,
            self.field_range)
        self.assertEquals(sorted(result.keys()), ['04300-01', '04300-02'])
        self.assertEquals(len(result['04300-01']), 27)
        self.assertEquals(len(result['04300-02']), 27)
        self.assertEquals(result['04300-01']['MV_HGT_10'], -0.57)
        self.assertEquals(result['04300-02']['MV_HGT_10'], -0.89)
