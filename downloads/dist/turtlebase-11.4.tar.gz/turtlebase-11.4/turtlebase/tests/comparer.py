# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-
import logging
import subprocess
import sys

MUST_CLOSE_FDS = not sys.platform.startswith('win')

logger = logging.getLogger(__name__)


class DictlistComparer(object):
    """Compare two 'dictlists' and show the difference.

    A 'dictlist' is a list with dicts with all the same keys.

    If something's wrong, an explanation (string) is returned, otherwise
    nothing.

    """

    def __init__(self, first_dictlist, second_dictlist):
        self.first = first_dictlist
        self.second = second_dictlist

    def compare(self):
        """Main comparison method."""
        for test in ['not_empty',
                     'keys_match',
                     'length_matches',
                     'compare_values',
                     ]:
            result = getattr(self, test)()
            if result:
                logger.error(result)
                return result

    def not_empty(self):
        if not len(self.first):
            return "The first dictlist is empty."
        if not len(self.second):
            return "The second dictlist is empty."

    def keys_match(self):
        keys = sorted(self.first[0].keys())
        for dictlist_index, dictlist in enumerate([self.first, self.second]):
            dictlist_number = dictlist_index + 1
            for row_index, row in enumerate(dictlist):
                row_number = row_index + 1
                row_keys = sorted(row.keys())
                if keys != row_keys:
                    msg = []
                    msg.append(
                        "The keys of row %s of dictlist %s:" % (
                            row_number, dictlist_number))
                    msg.append("  %s" % row_keys)
                    msg.append("don't match those of row 1 in dictlist 1:")
                    msg.append("  %s" % keys)
                    return '\n'.join(msg)

    def length_matches(self):
        if len(self.first) != len(self.second):
            msg = "The length of the dictlists doesn't match (%s and %s)" % (
                len(self.first), len(self.second))
            return msg

    def compare_values(self):
        for row_index in range(len(self.first)):
            row_number = row_index + 1
            row1 = self.first[row_index]
            row2 = self.second[row_index]
            if row1 != row2:
                msg = []
                msg.append("Row %s in dictlist 1:" % row_number)
                msg.append("  %s" % row1)
                msg.append("doesn't match the one in dictlist 2:")
                msg.append("  %s" % row2)
                return '\n'.join(msg)


def run_command(command, input=''):
    """commands.getoutput() replacement that also works on windows"""
    logger.debug("CMD: %r", command)
    p = subprocess.Popen(command,
                         shell=True,
                         stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         close_fds=MUST_CLOSE_FDS)
    i, o, e = (p.stdin, p.stdout, p.stderr)
    if input:
        i.write(input)
    i.close()
    result = o.read() + e.read()
    o.close()
    e.close()
    return result
