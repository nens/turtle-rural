#!/usr/bin/python
# -*- coding: utf-8 -*-
#******************************************************************************
#
# This file is part of the turtle_base library.
#
# The turtle_base library is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# This library is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# the turtle_base library.  If not, see <http://www.gnu.org/licenses/>.
#
# Copyright 2010 Nelen & Schuurmans
#
#******************************************************************************
#
# Initial programmer: Pieter Swinkels
# Initial date:       2010-11-12
#
#******************************************************************************

from unittest import TestCase

from turtlebase.blockschema_builder import SchemaBackendGraphviz
from turtlebase.blockschema_builder import generate_picture
from turtlebase.blockschema_builder import retrieve_extension
from turtlebase.tests.localmock import Mock

area_records = [
    {'label': "04060-01", 'surface': 108.699, 'water_surface':   4.472},
    {'label': "04060-02", 'surface': 247.777, 'water_surface':  12.723},
    {'label': "04060-03", 'surface':  12.112, 'water_surface':   0.596},
    {'label': "04060-04", 'surface':  66.305, 'water_surface':   2.222},
    {'label': "04060-05", 'surface': 134.159, 'water_surface':   0.737},
    {'label': "04060-06", 'surface':  18.602, 'water_surface':    1.29},
    {'label': "04060-07", 'surface':  23.294, 'water_surface':   0.625},
    {'label': "04060-08", 'surface': 104.933, 'water_surface':   4.208},
    {'label': "04060-09", 'surface':  44.589, 'water_surface':   2.161},
    {'label': "04060-10", 'surface':  59.521, 'water_surface':   1.856},
    {'label': "04060-11", 'surface':  10.388, 'water_surface':   0.489},
    {'label': "04060-12", 'surface':  41.074, 'water_surface':   1.714},
    {'label': "04060-13", 'surface':  23.887, 'water_surface':   0.216},
    {'label': "04060-14", 'surface':  27.779, 'water_surface':   1.146},
    {'label': "04060-15", 'surface':  19.214, 'water_surface':   0.103},
    {'label': "KP_04060-01"}]

connection_records = [
    {'src': "04060-11", 'dst': "04060-12"},
    {'src': "04060-13", 'dst': "04060-04"},
    {'src': "04060-04", 'dst': "04060-02"},
    {'src': "04060-02", 'dst': "04060-01"},
    {'src': "04060-05", 'dst': "04060-04"},
    {'src': "04060-12", 'dst': "04060-10"},
    {'src': "04060-03", 'dst': "04060-01"},
    {'src': "04060-01", 'dst': "KP_04060-01"},
    {'src': "04060-09", 'dst': "04060-08"},
    {'src': "04060-10", 'dst': "04060-08"},
    {'src': "04060-14", 'dst': "04060-10"},
    {'src': "04060-15", 'dst': "04060-08"},
    {'src': "04060-07", 'dst': "04060-06"},
    {'src': "04060-06", 'dst': "04060-02"},
    {'src': "04060-08", 'dst': "04060-01"},
    {'src': "04060-13", 'dst': "04060-14"},
    {'src': "04060-05", 'dst': "04060-02"}]


class buildTestSuite(TestCase):

    def setUp(self):
        self.areas = [\
            {'label': "04060-11", 'surface': 10.388, 'water_surface': 0.489},
            {'label': "04060-12", 'surface': 41.074, 'water_surface': 1.714}]
        self.connections = [{'src': "04060-11", 'dst': "04060-12"}]

    def test_a(self):
        """Test that the backend gets the right nodes."""

        backend = Mock()

        generate_picture(self.areas, self.connections, backend)

        calls = backend.mockGetNamedCalls("add_node")
        self.assertEqual(2, len(calls))
        calls[0].checkArgs("04060-11", surface="10.4ha", percentage="4.71%")
        calls[1].checkArgs("04060-12", surface="41.1ha", percentage="4.17%")

    def test_b(self):
        """Test that the backend gets the right connection node."""
        areas = [{'label': "KP_04060-01"}]
        connections = []
        backend = Mock()

        generate_picture(areas, connections, backend)

        calls = backend.mockGetNamedCalls("add_node")
        self.assertEqual(1, len(calls))
        calls[0].checkArgs("KP_04060-01")

    def test_c(self):
        """Test that the backend gets the right edges."""

        backend = Mock()

        generate_picture(self.areas, self.connections, backend)

        calls = backend.mockGetNamedCalls("add_edge")
        self.assertEqual(1, len(calls))
        calls[0].checkArgs("04060-11", "04060-12")

    def test_d(self):
        """Test the last call to the backend."""

        backend = Mock()

        generate_picture(self.areas, self.connections, backend)

        last_call = backend.mockGetAllCalls()[-1]
        self.assertEqual("store", last_call.getName())

    def test_e(self):
        """Test that the right node is red."""
        backend = Mock()

        self.areas[0]["T_I"] = 1.0

        generate_picture(self.areas, self.connections, backend)

        calls = backend.mockGetNamedCalls("add_node")
        self.assertEqual(2, len(calls))
        calls[0].checkArgs("04060-11", surface="10.4ha", percentage="4.71%",
                           color="red")
        calls[1].checkArgs("04060-12", surface="41.1ha", percentage="4.17%")

    def test_f(self):
        """Test that the right node is yellow."""
        backend = Mock()

        self.areas[0]["T_O"] = 1.0

        generate_picture(self.areas, self.connections, backend)

        calls = backend.mockGetNamedCalls("add_node")
        self.assertEqual(2, len(calls))
        calls[0].checkArgs("04060-11", surface="10.4ha", percentage="4.71%",
                           color="yellow")

    def test_y(self):
        """Test that a red node has preference over the yellow node."""
        backend = Mock()

        self.areas[0]["T_O"] = 1.0
        self.areas[0]["T_I"] = 1.0

        generate_picture(self.areas, self.connections, backend)

        calls = backend.mockGetNamedCalls("add_node")
        self.assertEqual(2, len(calls))
        calls[0].checkArgs("04060-11", surface="10.4ha", percentage="4.71%",
                           color="red")


def test_retrieve_extension():
        assert "png" == retrieve_extension("afvoer.png")


def raise_exception(*args, **kwargs):

    raise Exception()


class SchemaBackendGraphvizTestSuite(TestCase):

    def test_a(self):
        """Test add_node adds the right node for an actual area."""
        backend = SchemaBackendGraphviz("don't care.png")
        backend.add_node("04060-11", surface="10.388ha", percentage="4.71%")

        expected_line = "\"04060-11\" [shape=record, label=\"04060-11\\n10.388ha; Ow 4.71%\"]"
        self.assertEqual(expected_line, backend._lines[-1])

    def test_aa(self):
        """Test add_node adds the node in the right color for an actual area.
        """
        backend = SchemaBackendGraphviz("don't care.png")
        backend.add_node("04060-11", surface="10.388ha", percentage="4.71%",
                         color="red")

        expected_line = "\"04060-11\" [shape=record, fillcolor=red, style=filled, color=black, label=\"04060-11\\n10.388ha; Ow 4.71%\"]"
        self.assertEqual(expected_line, backend._lines[-1])

    def test_b(self):
        """Test add_node adds the node for a connection node."""
        backend = SchemaBackendGraphviz("don't care.png")
        backend.add_node("KP_04060-01")

        expected_line = "\"KP_04060-01\" [shape=box]"
        self.assertEqual(expected_line, backend._lines[-1])

    def test_ba(self):
        """Test add_node adds a node in the right color for a connection node.
        """
        backend = SchemaBackendGraphviz("don't care.png")
        backend.add_node("KP_04060-01", color="yellow")

        expected_line = "\"KP_04060-01\" [shape=box, fillcolor=yellow, style=filled, color=black]"
        self.assertEqual(expected_line, backend._lines[-1])

    def test_c(self):
        """Test add_edge adds the right edge."""
        backend = SchemaBackendGraphviz("don't care.png")
        backend.add_edge("04060-11", "04060-12")

        expected_line = "\"04060-11\" -> \"04060-12\""
        self.assertEqual(expected_line, backend._lines[-1])

    def test_d(self):
        """
        Test store returns the right code when the DOT file cannot be written.
        """
        backend = SchemaBackendGraphviz("don't care.png")
        backend._write_lines = raise_exception
        self.assertRaises(Exception, backend.store)

    def test_e(self):
        """
        Test store returns the right code when the DOT file cannot be written.
        """
        backend = SchemaBackendGraphviz("don't care.png")
        backend._write_lines = raise_exception
        self.assertRaises(Exception, backend.store)

    def test_f(self):
        """Test store throws an exception when the PNG file cannot be created.
        """
        backend = SchemaBackendGraphviz("don't care.png")
        backend._write_lines = lambda dot_filename, png_filename: None
        backend._call_dot = raise_exception
        self.assertRaises(Exception, backend.store)
