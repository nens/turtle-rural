# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-

import unittest

from turtlebase.tests.comparer import DictlistComparer


class DictlistComparerTestCase(unittest.TestCase):
    """Note: self.assertTrue means that there's string error output.
    """

    def test_empty_fails(self):
        self.assertTrue(DictlistComparer([], []).compare())

    def test_1(self):
        comparer = DictlistComparer([{'a': 1}],
                                    [{'a': 1},
                                     {'a': 2}])
        self.assertTrue(comparer.compare())

    def test_2(self):
        comparer = DictlistComparer([{'b': 1}],
                                    [{'a': 1},
                                     {'a': 2}])
        self.assertTrue(comparer.compare())

    def test_3(self):
        comparer = DictlistComparer([{'a': 1},
                                     {'a': 2}],
                                    [{'a': 1},
                                     {'a': 2}])
        self.assertFalse(comparer.compare())

    def test_4(self):
        comparer = DictlistComparer([{'a': 1}],
                                    [{'a': 1, 'b': 1}])
        self.assertTrue(comparer.compare())

    def test_5(self):
        comparer = DictlistComparer([{'a': 1},
                                     {'a': 2}],
                                    [{'a': 1},
                                     {'a': 3}])
        self.assertTrue(comparer.compare())
