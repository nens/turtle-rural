# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-
from unittest import TestCase

from turtlebase import mainutils


class MainutilsTestCase(TestCase):

    def test_debuglogging(self):
        # Just call it and make sure it doesn't die.
        mainutils.debuglogging_about_environment()

    def test_create_geoprocessor(self):
        gp = mainutils.create_geoprocessor()
        self.assertEquals(gp.OverwriteOutput, 1)
