# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-

import logging
import sys

from turtlebase.arcgis import get_random_file_name
import nens.gp
import turtlebase.arcgis
import turtlebase.network
import turtlebase.voronoi

arcgisscripting = None
try:
    import arcgisscripting
except ImportError:
    pass

logger = logging.getLogger(__name__)


def read_ide_rec(gp, filegdb, ide_rec_field, fc_type='FeatureClasses'):
    '''
    Reads in a single line of attribute table and headers. Used to detect
    IDE_REC contents returns a dictionary as {'*LEI' : ['fc_name'],
    '*AFV':['fc_name1, 'fc_name2']} etc fc_type can be FeatureClasses or
    Tables
    '''
    output_dict = {}
    gp.Workspace = filegdb
    if fc_type == 'FeatureClasses':
        fcs = gp.ListFeatureClasses()
    else:
        fcs = gp.ListTables()
    fc = fcs.Next()

    while fc:
        logger.info("Reading in %s" % fc)
        if turtlebase.arcgis.fc_is_not_empty(
            gp, fc) == False:
            if fc_type == 'FeatureClasses':
                shapetype = gp.Describe(fc).ShapeType
                logger.debug("Reading in %s shapetype %s" % (fc, shapetype))
            else:
                shapetype = 'table'
            rows = gp.SearchCursor(fc)
            row = rows.Reset()
            # perform 1 step into the fc attribute table
            row = rows.Next()
            if turtlebase.arcgis.is_fieldname(gp, fc, ide_rec_field) == True:
                ide_rec = row.GetValue(ide_rec_field)
                ide_rec = ide_rec + "_" + shapetype
                if ide_rec not in output_dict.keys():
                    output_dict[ide_rec] = []
                output_dict[ide_rec].append(fc)

        fc = fcs.Next()
    return output_dict


def read_ide_rec_from_single_fc(gp, fc, ide_rec_field, shapetype):
    output_dict = {}
    rows = gp.SearchCursor(fc)
    row = rows.Reset()
    # perform 1 step into the fc attribute table
    row = rows.Next()
    if turtlebase.arcgis.is_fieldname(gp, fc, ide_rec_field) == True:
        ide_rec = row.GetValue(ide_rec_field)
        ide_rec = ide_rec + "_" + shapetype
        if ide_rec not in output_dict.keys():
            output_dict[ide_rec] = []
        output_dict[ide_rec].append(fc)
    return output_dict


def get_dict_with_options():
    """
    Function to generate list with sections that should be there in ini file
    of turtle urban.  It's a convenience for the programmer/scripter. The only
    location where lists of sections and optionsd need to be changed is here
    """
    dict_with_options = {
        'General': ['location_temp', 'log_file'],
        'Sufhyd': ['veld_leiding_type', 'id_knoop', 'id_knoop1', 'id_knoop2',
                   'id_gebied1', 'id_gebied2', 'ide_rec', 'aantal_inwoners',
                   'dwa_definitie', 'toe_te_voegen_velden', 'leiding_id',
                   'leiding_type', 'knoop_id'],
        'DefinitieLeidingtypes': [],
        'DWA_aankoppeling': ['dwa_aangekoppeld'],
        'VerhardOppervlakHuisDefinitie': ['verhardoppervlak_huisdefinitie'],
        'BrabantseMethode': ['brabantsemethode_type',
                             'brabantsemethode_oppervlak']}

    return dict_with_options


# turtlebase.urban
def field_availability(gp, config, table, type_of_table):
    """
    checks a table, and depending on the type checks whether all the required
    fields are available.  input is the ini file containing the specific
    fields, the table to check and the type of table to check otuput is a list
    of missing fields
    """
    missing_fields = []

    if type_of_table == 'vlakkenbestand':
        required_fields = ['field_containing_surface_type_information']
        section = 'General'
    elif type_of_table == 'inwoners':
        required_fields = ['field_with_number_of_citizens']
        section = 'General'
    elif type_of_table == 'gemeentebredekoppelkaart':
        required_fields = ['field_containing_rioolgebieden_id']
        section = 'General'
    elif type_of_table == 'input_leidingen_bestand':
        required_fields = ['veld_leiding_type', 'id_gebied1', 'id_gebied2']
        # TODO: ^^^ aanvullen
        section = 'Sufhyd'
    elif type_of_table == 'output_leidingen_bestand':
        required_fields = ['toe_te_voegen_velden', 'leiding_id',
                           'leiding_type']
        section = 'Sufhyd'
    elif type_of_table == 'output_knopen_bestand':
        required_fields = ['toe_te_voegen_velden', 'knoop_id',
                           'leiding_type']
        section = 'Sufhyd'
    else:
        logger.error("Type of table %s is not defined" % type_of_table)
    # now check whether the required fields are avaible in the table
    for required_field in required_fields:
        field_to_check = config.get(section, required_field)
        if (turtlebase.arcgis.is_fieldname(
                gp, table, field_to_check) == False):
            missing_fields.append(field_to_check)

    return missing_fields


# turtlebase.urban
def removing_not_required_fields_in_output(
    gp, logger, shape_file, list_of_fields_to_remain):
    """ loops through a list and removes the columns of which the fieldnames
    are not in the list_of_fields_to_remain
    """
    #set fields_to_remove to zero in case there are no fields to remove (when
    #tool is run twice)
    fields_to_remove = ""
    count = 1
    logger.debug(shape_file)
    fields = gp.ListFields(shape_file)
    fields.reset()
    field = fields.next()
    while field:
        fieldname = field.Name
        logger.debug(fieldname)
        fieldname_lowercase = fieldname.lower()

        if fieldname_lowercase in list_of_fields_to_remain:
            pass

        else:
            logger.debug("Removing field " + str(field.Name) + " ")
            if count == 1:
                fields_to_remove = field.Name
                count = 2
            else:
                fields_to_remove = field.Name + ";" + fields_to_remove

        field = fields.next()

    logger.debug("fields_to_remove" + str(fields_to_remove))
    if fields_to_remove != "":
        gp.DeleteField_management(shape_file, fields_to_remove)


# turtlebase.urban
def push_one_shape_file_through_another(
    gp, logger, temp_workspace,
    original_shape, shape_to_push_on_the_other, final_shape):
        """
        input zijn de gp, logger, workspace de originele shapefile, dat wil
        zeggen de shapefile waarvan je polygonen wil vervangen
        shape_to_push_on_the_other: de shapefile met polygonen die polygonen
        in de orignele shapefile moeten vervangen final_shape =
        outputshapefile
        """
        tempfiles = []
        temp_file = get_random_file_name(temp_workspace, ".shp")
        tempfiles.append(temp_file)
        logger.debug("temp_file = %s" % temp_file)

        gp.select_analysis(original_shape, temp_file)
        # 1. maak 'fake' fid kolom aan om te weten welke dubbel zijn.
        field = "fid2"
        if (turtlebase.arcgis.is_fieldname(gp, temp_file, field) == False):
            logger.info("Field %s is added to %s" % (field,
                                                                 temp_file))
            gp.AddField_management(temp_file, field, "LONG")
        else:
            logger.warning(
                "Field %s already existed and will be reset in %s",
                field, temp_file)
            gp.DeleteField_management(temp_file, field)
            gp.AddField_management(temp_file, field, "LONG")

        # set the fid2
        row = gp.UpdateCursor(temp_file)
        for item in nens.gp.gp_iterator(row):
            fid = item.getValue("FID")
            item.SetValue("fid2", fid)
            row.UpdateRow(item)

        # 2. clip de user input met de kaart uit 1.2.1.
        clip_vlakken_shape = get_random_file_name(temp_workspace, ".shp")
        tempfiles.append(clip_vlakken_shape)
        logger.debug("clip_vlakken_shape = " + str(clip_vlakken_shape))
        gp.Clip_analysis(
            temp_file, shape_to_push_on_the_other, clip_vlakken_shape)

        dubbele_ident_dic = {}
        # nu loop door het resultaat van de clip om te weten welke vlakken
        # dubbel zijn
        row = gp.SearchCursor(clip_vlakken_shape)
        for item in nens.gp.gp_iterator(row):
            ident_to_delete = item.getValue(field)
            dubbele_ident_dic[ident_to_delete] = "fidtodelete"

        # verwijder ze uit het origineel van de input (eerst een copy maken
        # dus)
        row = gp.UpdateCursor(temp_file)
        for item in nens.gp.gp_iterator(row):
            fid = item.getValue("fid")
            if fid in dubbele_ident_dic:
                row.DeleteRow(item)

        # 3. merge user input met kaart uit 1.2.1.
        # merge de resultaten samen
        gp.Merge_management(
            shape_to_push_on_the_other + ";" + temp_file, final_shape)
        gp.DeleteField_management(final_shape, field)
        logger.info("Removing tempfiles... ")
        turtlebase.arcgis.remove_tempfiles(gp, logger, tempfiles)


# turtlebase.urban
def select_lines_from_gemeentebredekoppelkaart_with_percentages(
    gp, logger, config, gemeentebredekoppelkaart,
    leidingtypes_dict_from_ini_file, leidingenshape, field_leidingtypes,
    temp_workspace, turtle_dwa_aankoppeling_dict, rekenregels):
    """
    input: gemeentebredekoppelkaart met percentages

    leidingtypes zoals die uit de inifile komen, deze zitten in een dictionary
    leidingenshape (geslotenleiding_line) ofwel de input van de main.tool als
    het percentage van het leidingtype groter als nul voor het specifieke
    gebied dan wordt deze geselecteerd returns list with file names for each
    leidingtype

    toevoegen: rekenregels als rekenregel > 0, zoek de bijbehorende
    rekenregel. wanneer deze regel niet beschikbaar is, geef dan een
    waarschuwing en begin opnieuw zonder regel.
    """
    tempfiles = []
    leidingen_output_list = {}
    field_rekenregels_fk = config.get('General', 'rekenregel_fk')
    gemeentebredekoppelkaart_dict = nens.gp.get_table(
        gp, gemeentebredekoppelkaart, no_shape=True)
    logger.debug("gemeentebredekoppelkaart_dict" + str(
            gemeentebredekoppelkaart_dict))
    logger.debug("leidingenshape" + str(leidingenshape))
    for leidingtype in leidingtypes_dict_from_ini_file.keys():
        #aparte select voor de aangekoppelde leidingen
        if leidingtype == 'dwa_aangekoppeld':
            select_line_features_eucl = get_random_file_name(temp_workspace,
                                                             ".shp")
            #tempfiles.append(select_line_features)
            logger.debug("Select_line_features_eucl = %s",
                         select_line_features_eucl)
            logger.debug("Selecteer de dwa aangekoppelde leidingen uit "
                         "de leidingen shapefile")
            turtlebase.arcgis.select_layer(
                gp, leidingenshape, field_leidingtypes,
                turtle_dwa_aankoppeling_dict, 'dwa_aangekoppeld',
                select_line_features_eucl)

            logger.debug("Assign rioolgebied code to sewer lines")
            spatialjoin_line_features = get_random_file_name(temp_workspace,
                                                             ".shp")
            tempfiles.append(spatialjoin_line_features)
            logger.debug("spatialjoin_line_features = " + str(
                    spatialjoin_line_features))
            gp.SpatialJoin_analysis(select_line_features_eucl,
                                    gemeentebredekoppelkaart,
                                    spatialjoin_line_features,
                                    "JOIN_ONE_TO_ONE")

            leidingen_output_list[leidingtype] = spatialjoin_line_features
        else:

            logger.debug("Select %s from line" % leidingtype)
            select_line_features_eucl = get_random_file_name(temp_workspace,
                                                             ".shp")
            #tempfiles.append(select_line_features)
            logger.debug("Select_line_features_eucl = %s",
                         select_line_features_eucl)
            logger.debug("Select 1 leidingtype uit de leidingen shape")

            where_clause = (
                '\"' + field_leidingtypes + '\"' + '=' + "'" +
                str(leidingtypes_dict_from_ini_file[leidingtype]) +
                "'")
            logger.debug("where_clause" + str(where_clause))

            gp.Select_analysis(leidingenshape, select_line_features_eucl,
                               where_clause)

            where_clause = '\"' + leidingtype + '\"' + '> 0'

            # wat ook kan is eerst de rekenregels inlezen, dan per leidingtype
            # in de rekenregeldict waar leidingtype > 0 return rekenregel_fk
            # in de whereclause voor de gemeentebrede koppelkaart moet die fk
            # ook terugkomen. en meegenomen voor de selectie.
            whereclause_rekenregels_dict = {}

            logger.debug("rekenregels" + str(rekenregels))

            if rekenregels != {}:
                #de kolom van de rekenregels ontbreekt in de gemeentebrede
                #koppelkaart maar er zijn wel rekenregels opgegeven
                if (field_rekenregels_fk not in
                    gemeentebredekoppelkaart_dict[0]):
                    logger.error("De kolom %s is niet aanwezig in de "
                                 "gemeentebrede koppelkaart",
                                 field_rekenregels_fk)
                    logger.error(
                        "Er is wel een tabel met rekenregels ingevoerd")
                    logger.error("Klopt de verwijzing in de ini file "
                                 "bij rekenregel_fk?")
                    sys.exit(0)

                    # loop over alle primary keys van de rekenregels
                    for rekenregel_pk in rekenregels.keys():
                        if leidingtype in rekenregels[rekenregel_pk]:
                            if rekenregels[rekenregel_pk][leidingtype] > 0:
                                #rekenregel_fk toevoegen aan whereclause

                                whereclause_rekenregels_dict[rekenregels[
                                        rekenregel_pk][field_rekenregels_fk]
                                                             ] = rekenregel_pk
                    # na de loop mooie whereclause maken
                    for rekenregel_in_where_clause in \
                            whereclause_rekenregels_dict.keys():
                        where_clause = (
                            where_clause + " OR " + '\"' +
                            field_rekenregels_fk + '\"' + '=' +
                            str(rekenregel_in_where_clause))

            else:
                # er zijn geen rekenregels opgegeven in de invoer, maar er
                # wordt wel naar verwezen in de gemeentebredekoppelkaart
                if field_rekenregels_fk in gemeentebredekoppelkaart_dict[0]:
                    logger.warning(
                        "There is not a table with calculation rules "
                        "present, however there is a column present for "
                        "this purposes in Gemeentebredekoppelkaart.")

            logger.debug("where_clause" + str(where_clause))
            select_area_from_gemeentebredekoppelkaart = get_random_file_name(
                temp_workspace, ".shp")
            #tempfiles.append(select_area_from_gemeentebredekoppelkaart)
            logger.debug("select_area_from_gemeentebredekoppelkaart = %s",
                         select_area_from_gemeentebredekoppelkaart)
            try:
                gp.Select_analysis(gemeentebredekoppelkaart,
                               select_area_from_gemeentebredekoppelkaart,
                               where_clause)
            except arcgisscripting.ExecuteError:
                logger.warning(
                    "The clause %s did not generate any results. "
                    "Seems like a redundant field in either ini file "
                    "or Gemeentebredekoppelkaart.", where_clause)
                continue
            #nu clip uitvoeren
            clip_leidingen = get_random_file_name(temp_workspace, ".shp")
            #tempfiles.append(select_line_features)
            logger.debug("clip_leidingen = " + str(clip_leidingen) + "")

            gp.clip_analysis(select_line_features_eucl,
                             select_area_from_gemeentebredekoppelkaart,
                             clip_leidingen)
            #spatial join hier toevoegen
            logger.debug("Assign rioolgebied code to sewer lines")
            spatialjoin_line_features = get_random_file_name(temp_workspace,
                                                             ".shp")
            tempfiles.append(spatialjoin_line_features)
            logger.debug("spatialjoin_line_features = %s",
                         spatialjoin_line_features)
            gp.Intersect_analysis((clip_leidingen + ";" +
                                   gemeentebredekoppelkaart),
                                  spatialjoin_line_features)
            #gp.SpatialJoin_analysis(clip_leidingen, gemeentebredekoppelkaart,
            #spatialjoin_line_features, "JOIN_ONE_TO_ONE")

            leidingen_output_list[leidingtype] = spatialjoin_line_features

    logger.debug("leidingen_output_list" + str(leidingen_output_list))
    return leidingen_output_list


# turtlebase.urban
def select_newest_polygons_according_to_beheersid(gp, shapefile, beheers_veld):
    """deze functie leest de verschillende vlakken van de polygoon in,
    schrijft ze weg naar de dictionary met de centroide van het vlak als de
    key en datum als het value veld.
    """
    duplicate_shape = {}
    float_formatter = turtlebase.arcgis.FormatFloat()
    row = gp.SearchCursor(shapefile)
    for item in nens.gp.gp_iterator(row):
        # centroide inlezen als string, afronden op 5 cijfers achter de komma
        (centroid_x,
         centroid_y) = turtlebase.network.read_coordinates_from_string(
            item.shape.centroid)
        centroid_shape = '%s %s' % (float_formatter.format(centroid_x),
                                    float_formatter.format(centroid_y))

        # stop alle velden in een dictionary
        if centroid_shape not in duplicate_shape:
            duplicate_shape[centroid_shape] = []

        beheers_veld_id = str(item.getValue(beheers_veld))

        duplicate_shape[centroid_shape].append(beheers_veld_id)

    # selecteer laatste datum veld uit de lijst.
    logger.debug(str(duplicate_shape))

    last_beheers_id_dict = {}
    for centroid in duplicate_shape.iterkeys():
        last_beheers_id = max(duplicate_shape[centroid])
        last_beheers_id_dict[centroid] = last_beheers_id

    # vergelijk de invoer in het datumveld met de maximum datum waarde in de
    # lijst en delete de row als het een oudere datum is.  naast een selectie
    # op de nieuwste datum moeten ook eventuele dubbele velden verwijderd
    # worden
    float_formatter = turtlebase.arcgis.FormatFloat()
    row = gp.UpdateCursor(shapefile)
    for item in nens.gp.gp_iterator(row):
        # centroide inlezen als string, afronden op 5 cijfers achter de komma
        (centroid_x,
         centroid_y) = turtlebase.network.read_coordinates_from_string(
            item.shape.centroid)

        centroid_shape = '%s %s' % (float_formatter.format(centroid_x),
                                    float_formatter.format(centroid_y))
        if centroid_shape in last_beheers_id_dict:
            beheers_veld_id_shape = item.getValue(beheers_veld)

            #als de datum in het veld niet de laatste datum is, verwijder dan
            #de rij
            if not beheers_veld_id_shape == last_beheers_id_dict[
                centroid_shape]:
                logger.debug("verwijder de record")
                row.DeleteRow(item)

    turtlebase.arcgis.remove_identical_centroid_locations(gp, shapefile)


def create_urban_voronoi(gp, line_fc, line_id_field, workspace_gdb,
                         clip_polygon):
    '''
    input: line feature class, containing a column with the name line_id_field
    input: clip_polygon is used to clip the total area
    output: list of filenames with polygons (voronoi)
    '''

    logger.info(" - create voronoi polygons")
    point_selection = turtlebase.voronoi.create_points(gp, line_fc,
                                                       line_id_field)

    logger.info(" - create line_voronoi")
    result_dict = turtlebase.voronoi.create_line_voronoi(point_selection)

    logger.info(" - create polygons")
    polygon_fc = turtlebase.voronoi.create_merged_polygons(result_dict,
                                                           workspace_gdb)

    logger.info(" - intersect line_voronoi polygons")
    output_clip_fc = get_random_file_name(workspace_gdb, ".shp")

    clip_polygon2 = turtlebase.arcgis.get_random_file_name(workspace_gdb,
                                                           ".shp")
    gp.Select_analysis(clip_polygon, clip_polygon2)

    list_of_files_to_intersect = [polygon_fc, clip_polygon, clip_polygon2]
    turtlebase.arcgis.intersect_from_list_of_files(gp, workspace_gdb,
                                                   list_of_files_to_intersect,
                                                   output_clip_fc)
    #gp.Intersect_analysis(polygon_fc + ";" + clip_polygon, output_clip_fc)

    return output_clip_fc


def create_unique_id(gp, shape, config, sufhyd_type,
                     write_sufhyd_type=True):
    '''
    input is a shape or feature class the function checks whether the input
    object is point or polyline. depending on the shapetype a unique id is
    composed.  in general the distinction between polygon and polyline is
    valid. however, the sufhyd-type has some exceptions. in cases where a
    ide_rec can be both point and line (as *AFV) the names for the fields of
    ide_rec and ide_geb are different.  this function should be rewritten in a
    more efficient way
    '''
    # for points there are 3 options: ide_geb, ide_knp (*KNP), ide_gb1,
    # ide_knp (*OVS) and ide_geb, ide_kn1 (*AFV)
    knoop_special_cases_geb = ['*OVS', '*UIT', '*GEM']
    knoop_special_cases_knp = ['*AFV', '*AFK']
    leidingen_special_cases_geb = ['*OVS', '*GEM', '*DRL', '*INI']

    pg_obj = gp.describe(shape)
    if pg_obj.ShapeType == "Polyline":

        if turtlebase.arcgis.is_fieldname(gp,
                                          shape,
                                          config.get('Sufhyd',
                                                     'leiding_id')) == False:
            gp.Addfield_management(shape,
                                   config.get('Sufhyd', 'leiding_id'),
                                   "TEXT", "30")
        logger.debug("Output is polyline, leiding id's will be composed")

        row = gp.UpdateCursor(shape)
        for item in nens.gp.gp_iterator(row):
            if (item.GetValue(config.get('Sufhyd', 'ide_rec')) in
                leidingen_special_cases_geb):
                geb1 = item.GetValue(config.get('Sufhyd', 'id_gebied1_ovs'))
            else:
                geb1 = item.GetValue(config.get('Sufhyd', 'id_gebied1'))
            geb2 = item.GetValue(config.get('Sufhyd', 'id_gebied2'))
            kn1 = str(item.GetValue(config.get('Sufhyd', 'id_knoop1')))
            kn2 = str(item.GetValue(config.get('Sufhyd', 'id_knoop2')))
            #soms heeft een gebied geen gebiedscode ingevuld staan, vervangen
            #met nul dan
            if geb2 == 'None' or geb2 == '' or geb2 == None:
                geb2_rep = geb1
            else:
                geb2_rep = geb2

            #kn1_strip = kn1.lstrip('0')
            #kn2_strip = kn2.lstrip('0')

            if geb2_rep == '0':
                #combinetokey = str(geb1) + "-" + str(kn1_strip) + "_" +
                #str(geb1) + "-" + str(kn2_strip)
                combinetokey = (str(geb1) + "-" + str(kn1) + "_" +
                                str(geb1) + "-" + str(kn2))
            else:
                combinetokey = (str(geb1) + "-" + str(kn1) + "_" +
                                str(geb2_rep) + "-" + str(kn2))

            item.SetValue(config.get('Sufhyd', 'leiding_id'), combinetokey)
            if write_sufhyd_type == True:
                item.SetValue(config.get('Sufhyd', 'ide_rec'), sufhyd_type)
            row.UpdateRow(item)
        del row

    if pg_obj.ShapeType == "Point":
        logger.debug("Output is point, knoop id's will be composed")

        # maybe the required_fields-list needs some update with mvd_niv etc
        # for the knopen.
        if turtlebase.arcgis.is_fieldname(
            gp,
            shape,
            config.get('Sufhyd', 'knoop_id')) == False:
            gp.Addfield_management(shape,
                                   config.get('Sufhyd', 'knoop_id'),
                                   "TEXT", "30")

        row = gp.UpdateCursor(shape)

        for item in nens.gp.gp_iterator(row):
            if (item.GetValue(config.get('Sufhyd', 'ide_rec')) in
                knoop_special_cases_geb):
                geb = item.GetValue(config.get('Sufhyd', 'id_gebied1_ovs'))
                knp = str(item.GetValue(config.get('Sufhyd', 'id_knoop1')))
            elif (item.GetValue(config.get('Sufhyd', 'ide_rec')) in
                  knoop_special_cases_knp):
                geb = item.GetValue(config.get('Sufhyd', 'id_gebied1'))
                knp = str(item.GetValue(config.get('Sufhyd', 'id_knoop1')))

            else:
                geb = item.GetValue(config.get('Sufhyd', 'id_gebied1'))
                knp = str(item.GetValue(config.get('Sufhyd', 'id_knoop')))
            #knp_strip = knp.lstrip('0')
            combinetokey = str(geb) + "-" + str(knp)  # str(knp_strip)
            item.SetValue(config.get('Sufhyd', 'knoop_id'), combinetokey)
            if write_sufhyd_type == True:
                item.SetValue(config.get('Sufhyd', 'ide_rec'), sufhyd_type)

            row.UpdateRow(item)
        del row


def find_ident(config, headers_dict, list):
    '''
    input: headers_dict : {headername2: type}
    input: list = [headername1, headername2, headername3]
    output: headername2
    '''
    for fieldname in list:
        sufhydfieldname = config.get('Sufhyd', fieldname)
        if sufhydfieldname in headers_dict.keys():
            return sufhydfieldname


def create_unique_id_field(gp, fc, config):
    '''
    creates a field with a unique ident in a table.  input is a fc with
    minimal a geb1 and knp1 column, and optional a geb2 and knp2 column output
    is the same fc with an added column in which the idents are combined to a
    unique string
    '''
    # create unique id for a table, find all required fields and put them in
    # order
    ide_geb1_list = ['id_gebied1', 'id_gebied1_ovs']
    #ide_geb2_list = ['id_gebied2']
    #ide_knp1_list = ['id_knoop', 'id_knoop1']
    #ide_knp2_list = ['id_knoop2']
    # check for each of the codes which one is occuring in the table and use
    # the ones that are there
    # to create a unique ident.
    # read headers
    headers_fc = turtlebase.arcgis.read_fieldnames(gp, fc)
    # find appropriate area and point idents
    ide_geb1 = find_ident(config, headers_fc, ide_geb1_list)
    #ide_geb2 = find_ident(config, headers_fc, ide_geb2_list)
    #ide_knp1 = find_ident(config, headers_fc, ide_knp1_list)
    #ide_knp2 = find_ident(config, headers_fc, ide_knp2_list)
    # loop through the file and add the required field
    leiding_id = config.get('Sufhyd', 'leiding_id')
    if turtlebase.arcgis.is_fieldname(gp, fc, leiding_id) == False:
        gp.Addfield_management(fc, leiding_id, "TEXT", "30")

    row = gp.UpdateCursor(fc)
    for item in nens.gp.gp_iterator(row):
        ide_geb1_name = item.getValue(ide_geb1)
        #ide_knp1_name = item.getValue(ide_knp1)
        #if ide_geb2 != "":
        #    ide_geb2_name = item.getValue(ide_geb2)
        #if ide_knp2 != "":
        #    ide_knp2_name = item.getValue(ide_knp2)
        unique_ident = '%s-%s_%s-%s' % (ide_geb1_name)
        gp.SetValue(leiding_id, unique_ident)
