import sys
import logging
log = logging.getLogger(__name__)
import nens.sobek
import collections
import os
from operator import itemgetter


def sort_cross_sections(cross_sections):
    """Sort cross sections dict (in-place, so there's no return).

    Everything below the first lowest point should be sorted from high z to
    low z, everything after the first lowest point should be sorted from low
    to high z.  (Note: 'y' means the distance from the left side of the cross
    section, 'z' is the height.

    Input: dict with key=cross section id and value a list of (y, z) tuples
    (or lists):

      >>> input = {'54': [(-2.1499999999999999, 34.0),
      ...                 (-1.0, 31.0),
      ...                 (-1.0, 22.0),
      ...                 (0.0, 17.0),
      ...                 (0.0, 5.0),
      ...                 (1.0, 31.0),
      ...                 (1.0, 22.0),
      ...                 (2.1499999999999999, 34.0)]}
      >>> sort_cross_sections(input)
      >>> for y, z in input['54']:
      ...     print y, z
      -2.15 34.0
      -1.0 31.0
      -1.0 22.0
      0.0 17.0
      0.0 5.0
      1.0 22.0
      1.0 31.0
      2.15 34.0

    """
    for id, cross_section in cross_sections.items():
        z_values = [z for (y, z) in cross_section]
        minimum = min(z_values)
        first_minimum_item_index = z_values.index(minimum)
        before = cross_section[:first_minimum_item_index]
        # ^^^ Before includes the lowest point itself.
        after = cross_section[first_minimum_item_index:]
        before.sort(key=itemgetter(1, 0), reverse=True)
        after.sort(key=itemgetter(1, 0))
        cross_sections[id] = before + after


def setPointAttributes(point, id, x, y):
    """
    add coordinates to a Point object(CreateObject)
    id should be a unique integer
    geometry should contain a list of a x and y coordinate
    """
    point.id = id
    point.x = float(x)
    point.y = float(y)
    return point


def write_cross_section_yz_table(gp, config, yz_table, output_yz_table):
    """
    input_list = [[id1, y, z], [id2, y, z]]
    sort on id, y
    """
    workspace = os.path.dirname(output_yz_table)
    table_name = os.path.basename(output_yz_table)
    gp.CreateTable_management(workspace, table_name)

    cross_sections = collections.defaultdict(list)

    for id, y, z in yz_table:
        cross_sections[id].append((y, z))

    sort_cross_sections(cross_sections)

    sorted_list = []
    ids = cross_sections.keys()
    ids.sort()
    for id in ids:
        for y, z in cross_sections[id]:
            sorted_list.append([id, y, z])

    idfield = config.get('CrossSections', 'cross_sections_def_id')
    gp.addfield(output_yz_table, idfield, "TEXT")
    y_field = config.get('CrossSections', 'y_level')
    gp.addfield(output_yz_table, y_field, "DOUBLE")
    z_field = config.get('CrossSections', 'z_level')
    gp.addfield(output_yz_table, z_field, "DOUBLE")
    sort_field = config.get('CrossSections', 'sort_field')
    gp.addfield(output_yz_table, sort_field, "SHORT")

    rows = gp.InsertCursor(output_yz_table)
    id = ""
    x = 1
    for yz in sorted_list:
        if id == yz[0]:
            x += 1
        else:
            x = 1
        id = yz[0]

        row = rows.NewRow()
        row.SetValue(idfield, yz[0])
        row.SetValue(y_field, yz[1])
        row.SetValue(z_field, yz[2])
        row.SetValue(sort_field, x)

        rows.InsertRow(row)
    del rows
    del row


def create_shapefiles(gp, config, sobek_network_dict,
                      sobek_object, output_fc, profile_dict):
    '''
    creates a shapefile from a dictionary with x and y coordinates
    '''
    cross_section_type = config.get('CrossSections', 'cross_section_type')
    idfield = config.get('CrossSections', 'cross_section_id')
    difield = config.get('CrossSections', 'cross_sections_def_id')

    workspace = os.path.dirname(output_fc)
    fc_name = os.path.basename(output_fc)

    for type_name in sobek_network_dict.categorized.keys():

        if type_name == sobek_object:
            gp.CreateFeatureClass_management(workspace, fc_name, "Point",
                                             "#", "DISABLED", "DISABLED", "#")

            gp.addfield(output_fc, idfield, "TEXT")
            gp.addfield(output_fc, difield, "TEXT")
            gp.addfield(output_fc, cross_section_type, "TEXT")

            rows = gp.InsertCursor(output_fc)
            point = gp.CreateObject("Point")

            for i, (id, x, y) in enumerate(sobek_network_dict[type_name]):
                try:
                    # adding id of profile definition, only if id is in both dicts
                    #locident = profile_dict[id][idfield]
                    proident = profile_dict[id][difield]
                    #add new point
                    row = rows.NewRow()
                    point = setPointAttributes(point, i, x, y)
                    row.shape = point
                    id = str(id)
                    row.SetValue(idfield, id)
                    row.SetValue(difield, str(proident))
                    row.SetValue(cross_section_type, str(sobek_object))
                    rows.InsertRow(row)
                except:
                    log.warning("failed to add %s" % id)
                    log.info(profile_dict[id])
            del rows
            del row


# Function below commented out by Reinout 2011-04-22: undefined names, cannot
# work :-)
# def sort_xyz_profile(gp, locations, xyz_points):
#     """
#     xyz_points = [[x1, y1, z1], [x2, y2, z2]]
#     """
#     locs = nens.gp.get_table(gp, locations, primary_key='LOCIDENT')
#     xyz = nens.gp.get_table(gp, xyz_points)
#     # [{'proident': profiel1}, {'proident': profiel2}]
#     sorted = nens.geom.sort(i['points_3d'])
#     for i in objs:
#         if i.setdefault('points_2d', []):
#             i['profile_shape'] = 3
#         if i.get('points_3d'):
#             sorted = nens.geom.sort(i['points_3d'])
#             abscissas = nens.geom.abscissa_from_midsegment(sorted)
#             i['points_2d'] = [(xx,z) for ((xx), (x,y,z)) in zip(abscissas,
#                                                                 sorted)]
#             i['profile_shape'] = 1
#             del i['points_3d']
#         if i['points_2d']:
#             i['field_level'] = min(i['points_2d'][0][1],
#                                    i['points_2d'][-1][1])


def import_cross_section_data(input_cross_section_dat,
                       locident='LOCIDENT',
                       proident='PROIDENT'):
    '''
    Leest een profile.dat bestand uit en haal hier de profiel informatie uit.
    Geeft een dictionary met per locatie:
    - de locatie id (id)
    - de profiel id (di)
    '''
    cross_section_data = nens.sobek.File(input_cross_section_dat)

    cross_section_table = {}

    # Controleer of het sobek bestand wel "CRSN"  bevat
    if 'CRSN' not in cross_section_data.keys():
        errorcode = 1
        return cross_section_table, errorcode

    # Voor elk object in het sobek bestand wordt een regel in de dictionary
    #aangemaakt
    # met de locatie_id ('id') en de profiel_id ('di')
    for cross_section in cross_section_data['CRSN']:
        if 'id' in cross_section:
            cross_id = cross_section.id
        else:
            continue

        if 'di' in cross_section:
            cross_di = cross_section['di'][0]
        else:
            cross_di = ''

        if 'rl' in cross_section:
            ref_level = cross_section['rl'][0]
        else:
            ref_level = 0
        if 'rs' in cross_section:
            surface_level = cross_section['rs'][0]
        else:
            surface_level = 2

            cross_section_table[cross_id] = {locident: cross_id,
                                             proident: cross_di,
                                             'bed_lvl': ref_level,
                                             'surface_lvl': surface_level}

    sum_locations = len(cross_section_table)
    log.info(" - cross_section_table contains: %s locations" % sum_locations)
    errorcode = 0
    return cross_section_table, errorcode


def import_cross_section_definition(input_cross_section_def, config):
    '''
    Leest een profile.def bestand uit en haal hier de profiel informatie uit.
    Leest objecten uit op basis van de profiel ident.
    Resultaat is een dictionary met alle tabulated profielen.
    '''
    #Dit bestand beschrijft alle profiel definities
    cross_section_definition = nens.sobek.File(input_cross_section_def)

    cross_section_table = {}
    yz_table = []
    # ------------------------------------------------------------------------
    # Controleer of het sobek bestand wel "CRDS"  bevat
    if "CRDS" not in cross_section_definition.keys():
        errorcode = 1
        return cross_section_table, yz_table, errorcode

    # ------------------------------------------------------------------------
    # Lees de sobek file uit met behulp van de sobek library.
    # Selecteer de tabulated profielen -> type 'ty' = 0
    no_data_value = -999
    for cross_section in cross_section_definition["CRDS"]:
        proident = cross_section.id
        if cross_section["ty"][0] == 0:
            cs_rows = cross_section['TBLE'][0].rows()
            cs_cols = cross_section['TBLE'][0].cols()
            if cs_rows == 3 and cs_cols == 3:
                # Bij een profiel met 3 niveaus (bodem/water/maaiveld)
                bottomlevel = cross_section['TBLE'][0][0, 0]
                main_bottom_width = cross_section['TBLE'][0][0, 1]
                flow_bottom_width = cross_section['TBLE'][0][0, 2]
                waterlevel = cross_section['TBLE'][0][1, 0]
                main_water_width = cross_section['TBLE'][0][1, 1]
                flow_water_width = cross_section['TBLE'][0][1, 2]
                fieldlevel = cross_section['TBLE'][0][2, 0]
                main_field_width = cross_section['TBLE'][0][2, 1]
                flow_field_width = cross_section['TBLE'][0][2, 2]

                # sla de resultaten op in een dictionary van dictionaries
                cross_section_table[proident] = {
                    config.get('CrossSections',
                               'cross_sections_def_id'): proident,
                    config.get('CrossSections',
                               'cross_section_type'): 'tabulated',
                    config.get('CrossSections',
                               'bottomlevel'): bottomlevel,
                    config.get('CrossSections',
                               'main_bottom_width'): main_bottom_width,
                    config.get('CrossSections',
                               'flow_bottom_width'): flow_bottom_width,
                    config.get('CrossSections',
                               'waterlevel'): waterlevel,
                    config.get('CrossSections',
                               'main_water_width'): main_water_width,
                    config.get('CrossSections',
                               'flow_water_width'): flow_water_width,
                    config.get('CrossSections',
                               'fieldlevel'): fieldlevel,
                    config.get('CrossSections',
                               'main_field_width'): main_field_width,
                    config.get('CrossSections',
                               'flow_field_width'): flow_field_width,
                    config.get('CrossSections',
                               'bank_slope'): no_data_value,
                    }
            elif cs_rows == 2 and cs_cols == 3:
                # Bij een profiel met 3 niveaus (bodem/water/maaiveld)
                bottomlevel = cross_section['TBLE'][0][0, 0]
                main_bottom_width = cross_section['TBLE'][0][0, 1]
                flow_bottom_width = cross_section['TBLE'][0][0, 2]
                waterlevel = cross_section['TBLE'][0][1, 0]
                main_water_width = cross_section['TBLE'][0][1, 1]
                flow_water_width = cross_section['TBLE'][0][1, 2]
                fieldlevel = (cross_section['TBLE'][0][1, 0]) + 0.01
                main_field_width = cross_section['TBLE'][0][1, 1]
                flow_field_width = cross_section['TBLE'][0][1, 2]

                # sla de resultaten op in een dictionary van dictionaries
                cross_section_table[proident] = {
                    config.get('CrossSections',
                               'cross_sections_def_id'): proident,
                    config.get('CrossSections',
                               'cross_section_type'): 'tabulated',
                    config.get('CrossSections',
                               'bottomlevel'): bottomlevel,
                    config.get('CrossSections',
                               'main_bottom_width'): main_bottom_width,
                    config.get('CrossSections',
                               'flow_bottom_width'): flow_bottom_width,
                    config.get('CrossSections',
                               'waterlevel'): waterlevel,
                    config.get('CrossSections',
                               'main_water_width'): main_water_width,
                    config.get('CrossSections',
                               'flow_water_width'): flow_water_width,
                    config.get('CrossSections',
                               'fieldlevel'): fieldlevel,
                    config.get('CrossSections',
                               'main_field_width'): main_field_width,
                    config.get('CrossSections',
                               'flow_field_width'): flow_field_width,
                    config.get('CrossSections',
                               'bank_slope'): no_data_value}
            else:
                if cs_rows == 0:
                    log.error("no data in profile table")
                if cs_cols > 2:
                    log.debug("yz profile: %", proident)
                    cross_section_table[proident] = {
                        config.get('CrossSections',
                                   'cross_sections_def_id'): proident,
                        config.get('CrossSections',
                                   'cross_section_type'): 'yz profile',
                        config.get('CrossSections',
                                   'bottomlevel'): 0,
                        config.get('CrossSections',
                                   'main_bottom_width'): no_data_value,
                        config.get('CrossSections',
                                   'flow_bottom_width'): no_data_value,
                        config.get('CrossSections',
                                   'waterlevel'): no_data_value,
                        config.get('CrossSections',
                                   'main_water_width'): no_data_value,
                        config.get('CrossSections',
                                   'flow_water_width'): no_data_value,
                        config.get('CrossSections',
                                   'fieldlevel'): no_data_value,
                        config.get('CrossSections',
                                   'main_field_width'): no_data_value,
                        config.get('CrossSections',
                                   'flow_field_width'): no_data_value,
                        config.get('CrossSections',
                                   'bank_slope'): no_data_value}

                    for row in range(cs_rows):
                        y1 = cross_section['TBLE'][0][int(row), 1] / 2
                        y2 = -y1
                        z = cross_section['TBLE'][0][int(row), 0]
                        yz_table.append([proident, y1, z])
                        yz_table.append([proident, y2, z])

        elif cross_section["ty"][0] == 1:
            bottomlevel = cross_section["bl"][0]
            bottom_width = cross_section["bw"][0]
            flow_field_width = cross_section["aw"][0]
            bank_slope = cross_section["bs"][0]

            cross_section_table[proident] = {
                config.get('CrossSections',
                           'cross_sections_def_id'): proident,
                config.get('CrossSections',
                           'cross_section_type'): 'trapezium',
                config.get('CrossSections',
                           'bottomlevel'): bottomlevel,
                config.get('CrossSections',
                           'main_bottom_width'): no_data_value,
                config.get('CrossSections',
                           'flow_bottom_width'): bottom_width,
                config.get('CrossSections',
                           'waterlevel'): no_data_value,
                config.get('CrossSections',
                           'main_water_width'): no_data_value,
                config.get('CrossSections',
                           'flow_water_width'): no_data_value,
                config.get('CrossSections',
                           'fieldlevel'): no_data_value,
                config.get('CrossSections',
                           'main_field_width'): no_data_value,
                config.get('CrossSections',
                           'flow_field_width'): flow_field_width,
                config.get('CrossSections',
                           'bank_slope'): bank_slope}

        elif cross_section["ty"][0] == 10:
            # yz profile
            cs_rows = cross_section['TBLE'][0].rows()
            cs_cols = cross_section['TBLE'][0].cols()

            if cs_cols > 2:
                log.debug("yz profile: %", proident)
                cross_section_table[proident] = {
                    config.get('CrossSections',
                               'cross_sections_def_id'): proident,
                    config.get('CrossSections',
                               'cross_section_type'): 'yz profile',
                    config.get('CrossSections',
                               'bottomlevel'): 0,
                    config.get('CrossSections',
                               'main_bottom_width'): no_data_value,
                    config.get('CrossSections',
                               'flow_bottom_width'): no_data_value,
                    config.get('CrossSections',
                               'waterlevel'): no_data_value,
                    config.get('CrossSections',
                               'main_water_width'): no_data_value,
                    config.get('CrossSections',
                               'flow_water_width'): no_data_value,
                    config.get('CrossSections',
                               'fieldlevel'): no_data_value,
                    config.get('CrossSections',
                               'main_field_width'): no_data_value,
                    config.get('CrossSections',
                               'flow_field_width'): no_data_value,
                    config.get('CrossSections',
                           'bank_slope'): no_data_value}

                for row in range(cs_rows):
                    y = cross_section['TBLE'][0][int(row), 0]
                    z = cross_section['TBLE'][0][int(row), 1]
                    yz_table.append([proident, y, z])

        else:
            log.info(" - cross section %s is not a yz, \
            trapezioid or tabulated", proident)

    log.info(" - cross section table contains: %s \
    tabulated profiles", len(cross_section_table))
    errorcode = 0
    return cross_section_table, yz_table, errorcode


def missingKeys(dictionary, expected_keys):
    """file validation: are all necessary fields present?

    input: dictionary of dictionaries (cannot be empty), expected_keys (a list)
    output: list of all missing values (empty means OK)
    """
    return [k for k in expected_keys if k not in dictionary.values()[0]]


def calculateCrossSection(cross_section_dict, vergroten_verkleinen,
                          stroomvoerend_bergend, procent_breedte,
                          change_value, ini):
    """vergroot of verkleind tabulated dwarsprofielen
    input: dictionary met profielgegevens,
    output: dictionary met nieuwe profielgegevens
    """

    if not cross_section_dict:
        log.error("no values found in cross section definition")
        sys.exit()

    cross_section_new_dict = {}

    field_bottem_level = ini['bottomlevel'].lower()
    field_bottom_width_sv = ini['flow_bottom_width'].lower()
    field_bottom_width_max = ini['main_bottom_width'].lower()
    field_water_level = ini['waterlevel'].lower()
    field_water_width_sv = ini['flow_field_width'].lower()
    field_water_width_max = ini['main_field_width'].lower()
    field_surface_level = ini['fieldlevel'].lower()
    field_surface_width_sv = ini['flow_water_width'].lower()
    field_surface_width_max = ini['main_water_width'].lower()
    field_cross_section_def_id = ini['cross_sections_def_id'].lower()
    field_type = ini['cross_section_type'].lower()
    field_comment = ini['comment'].lower()
    field_date_time = ini['date_time'].lower()
    field_add_width = ini['add_width'].lower()

    checkfields = [field_bottem_level, field_bottom_width_sv,
                   field_bottom_width_max, field_water_level,
                   field_water_width_sv, field_water_width_max,
                   field_surface_level, field_surface_width_sv,
                   field_surface_width_max, field_cross_section_def_id,
                   field_type]

    checkDict = missingKeys(cross_section_dict, checkfields)
    if len(checkDict) > 1:
        log.error('missing keys in cross section \
        definition table: %s' % checkDict)
        sys.exit(1)

    import time
    date_str = time.strftime('%x') + " " + time.strftime('%X')
    # format DD/MM/YYYY HH:MM:SS

    if vergroten_verkleinen == ini['vergroten']:
        log.info("Dwarsprofiel wordt vergroot:")
        if stroomvoerend_bergend == ini['stroomvoerend']:
            if procent_breedte == ini['procent']:
                log.info(" - stroomvoerende breedte wordt \
                procentueel vergroot...")

                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (
                            float(row[field_bottom_width_sv]) *
                            (1 + ((float(change_value)) / 100)))
                        # 2 change waterwidth
                        water_width = (
                            float(row[field_water_width_sv]) *
                            (1 + ((float(change_value)) / 100)))
                        # 3 change surface width
                        surface_width = (
                            float(row[field_surface_width_sv]) *
                            (1 + ((float(change_value)) / 100)))
                        # 4 check if BERG < SV, then BERG = SV
                        if bottom_width > float(row[field_bottom_width_max]):
                            bottom_width_max = bottom_width
                        else:
                            bottom_width_max = float(
                                row[field_bottom_width_max])

                        if water_width > float(row[field_water_width_max]):
                            water_width_max = water_width
                        else:
                            water_width_max = float(row[field_water_width_max])

                        if surface_width > float(row[field_surface_width_max]):
                            surface_width_max = surface_width
                        else:
                            surface_width_max = float(
                                row[field_surface_width_max])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                                        float(row[field_surface_width_sv]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(
                                row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width,
                            field_bottom_width_max: bottom_width_max,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width,
                            field_water_width_max: water_width_max,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width,
                            field_surface_width_max: surface_width_max,
                            field_type: row[field_type],
                            field_comment: "stroomvoerend profiel met \
                            %s procent verbreed" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

            elif procent_breedte == ini['breedte']:
                log.info(" - stroomvoerende breedte wordt in meters aangepast")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (
                            float(row[field_bottom_width_sv]) +
                            float(change_value))
                        # 2 change waterwidth
                        water_width = (
                            float(row[field_water_width_sv]) +
                            float(change_value))
                        # 3 change surface width
                        surface_width = (
                            float(row[field_surface_width_sv]) +
                            float(change_value))
                        # 4 check if BERG < SV, then BERG = SV
                        if bottom_width > float(row[field_bottom_width_max]):
                            bottom_width_max = bottom_width
                        else:
                            bottom_width_max = float(
                                row[field_bottom_width_max])

                        if water_width > float(row[field_water_width_max]):
                            water_width_max = water_width
                        else:
                            water_width_max = float(row[field_water_width_max])

                        if surface_width > float(row[field_surface_width_max]):
                            surface_width_max = surface_width
                        else:
                            surface_width_max = float(
                                row[field_surface_width_max])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                                        float(row[field_surface_width_sv]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width,
                            field_bottom_width_max: bottom_width_max,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width,
                            field_water_width_max: water_width_max,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width,
                            field_surface_width_max: surface_width_max,
                            field_type: row[field_type],
                            field_comment: "stroomvoerend profiel met \
                            %s meter verbreed" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                         found for %s" % id)

        elif stroomvoerend_bergend == ini['bergend']:
            if procent_breedte == ini['procent']:
                log.info(" - bergende breedte wordt procentueel aangepast...")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (float(row[field_bottom_width_max]) *
                                        (1 + ((float(change_value)) / 100)))
                        # 2 change waterwidth
                        water_width = (float(row[field_water_width_max]) *
                                       (1 + ((float(change_value)) / 100)))
                        # 3 change surface width
                        surface_width = (float(row[field_surface_width_max]) *
                                         (1 + ((float(change_value)) / 100)))

                        bottom_width_sv = float(row[field_bottom_width_sv])
                        water_width_sv = float(row[field_water_width_sv])
                        surface_width_sv = float(row[field_surface_width_sv])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                            float(row[field_surface_width_max]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width_sv,
                            field_bottom_width_max: bottom_width,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width_sv,
                            field_water_width_max: water_width,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width_sv,
                            field_surface_width_max: surface_width,
                            field_type: row[field_type],
                            field_comment: "bergend profiel met \
                            %s procent verbreed" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

            elif procent_breedte == ini['breedte']:
                log.info(" - bergende breedte wordt in meters aangepast")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (float(row[field_bottom_width_max]) +
                                        float(change_value))
                        # 2 change waterwidth
                        water_width = (float(row[field_water_width_max]) +
                                       float(change_value))
                        # 3 change surface width
                        surface_width = (float(row[field_surface_width_max]) +
                                         float(change_value))

                        bottom_width_sv = float(row[field_bottom_width_sv])
                        water_width_sv = float(row[field_water_width_sv])
                        surface_width_sv = float(row[field_surface_width_sv])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                                        float(row[field_surface_width_max]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width_sv,
                            field_bottom_width_max: bottom_width,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width_sv,
                            field_water_width_max: water_width,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width_sv,
                            field_surface_width_max: surface_width,
                            field_type: row[field_type],
                            field_comment: "bergend profiel met %s \
                            meter verbreed" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

    elif vergroten_verkleinen == ini['verkleinen']:
        log.info("Dwarsprofiel wordt verkleind")
        if stroomvoerend_bergend == ini['stroomvoerend']:
            if procent_breedte == ini['procent']:
                log.info(" - stroomvoerende breedte wordt \
                procentueel aangepast...")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (float(row[field_bottom_width_sv]) *
                                        (1 - ((float(change_value)) / 100)))
                        if bottom_width < float(ini['minimum_bottom_width']):
                            bottom_width = float(ini['minimum_bottom_width'])
                        # 2 change waterwidth
                        water_width = (float(row[field_water_width_sv]) *
                                       (1 - ((float(change_value)) / 100)))
                        if water_width < float(ini['minimum_main_width']):
                            water_width = float(ini['minimum_main_width'])
                        # 3 change surface width
                        surface_width = (float(row[field_surface_width_sv]) *
                                         (1 - ((float(change_value)) / 100)))
                        if surface_width < float(ini['minimum_main_width']):
                            surface_width = float(ini['minimum_main_width'])

                        bottom_width_max = float(row[field_bottom_width_max])
                        water_width_max = float(row[field_water_width_max])
                        surface_width_max = float(row[field_surface_width_max])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                                        float(row[field_surface_width_sv]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width,
                            field_bottom_width_max: bottom_width_max,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width,
                            field_water_width_max: water_width_max,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width,
                            field_surface_width_max: surface_width_max,
                            field_type: row[field_type],
                            field_comment: "stroomvoerend profiel met \
                            %s procent versmald" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

            elif procent_breedte == ini['breedte']:
                log.info(" - stroomvoerende breedte wordt in \
                meters aangepast...")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (float(row[field_bottom_width_sv]) -
                                        (float(change_value)))
                        if bottom_width < float(ini['minimum_bottom_width']):
                            bottom_width = float(ini['minimum_bottom_width'])
                        # 2 change waterwidth
                        water_width = (float(row[field_water_width_sv]) -
                                       (float(change_value)))
                        if water_width < float(ini['minimum_main_width']):
                            water_width = float(ini['minimum_main_width'])
                        # 3 change surface width
                        surface_width = (float(row[field_surface_width_sv]) -
                                         (float(change_value)))
                        if surface_width < float(ini['minimum_main_width']):
                            surface_width = float(ini['minimum_main_width'])

                        bottom_width_max = float(row[field_bottom_width_max])
                        water_width_max = float(row[field_water_width_max])
                        surface_width_max = float(row[field_surface_width_max])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                                        float(row[field_surface_width_sv]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width,
                            field_bottom_width_max: bottom_width_max,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width,
                            field_water_width_max: water_width_max,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width,
                            field_surface_width_max: surface_width_max,
                            field_type: row[field_type],
                            field_comment: "stroomvoerend profiel met \
                            %s meter versmald" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

        elif stroomvoerend_bergend == ini['bergend']:
            if procent_breedte == ini['procent']:
                log.info(" - bergende breedte wordt procentueel aangepast")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (float(row[field_bottom_width_max]) *
                                        (1 - ((float(change_value)) / 100)))
                        if bottom_width < float(ini['minimum_bottom_width']):
                            bottom_width = float(ini['minimum_bottom_width'])
                        # 2 change waterwidth
                        water_width = (float(row[field_water_width_max]) *
                                       (1 - ((float(change_value)) / 100)))
                        if water_width < float(ini['minimum_flow_width']):
                            water_width = float(ini['minimum_flow_width'])
                        # 3 change surface width
                        surface_width = (float(row[field_surface_width_max]) *
                                         (1 - ((float(change_value)) / 100)))
                        if surface_width < float(ini['minimum_flow_width']):
                            surface_width = float(ini['minimum_flow_width'])

                        # 4 check if SV > BERG, then SV = BERG
                        if float(row[field_bottom_width_sv]) > bottom_width:
                            bottom_width_sv = bottom_width
                        else:
                            bottom_width_sv = float(row[field_bottom_width_sv])

                        if float(row[field_water_width_sv]) > water_width:
                            water_width_sv = water_width
                        else:
                            water_width_sv = float(row[field_water_width_sv])

                        if float(row[field_surface_width_sv]) > surface_width:
                            surface_width_sv = surface_width
                        else:
                            surface_width_sv = float(
                                row[field_surface_width_sv])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (surface_width -
                                        float(row[field_surface_width_max]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width_sv,
                            field_bottom_width_max: bottom_width,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width_sv,
                            field_water_width_max: water_width,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width_sv,
                            field_surface_width_max: surface_width,
                            field_type: row[field_type],
                            field_comment: "bergend profiel met \
                            %s procent versmald" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

            elif procent_breedte == ini['breedte']:
                log.info(" - bergende breedte wordt in meters aangepast...")
                for id, row in cross_section_dict.items():
                    try:
                        # 1 change bottomwidth
                        bottom_width = (float(row[field_bottom_width_max]) -
                                        (float(change_value)))
                        if bottom_width < float(ini['minimum_bottom_width']):
                            bottom_width = float(ini['minimum_bottom_width'])
                        # 2 change waterwidth
                        water_width = (float(row[field_water_width_max]) -
                                       (float(change_value)))
                        if water_width < float(ini['minimum_flow_width']):
                            water_width = float(ini['minimum_flow_width'])
                        # 3 change surface width
                        surface_width = (float(row[field_surface_width_max]) -
                                         (float(change_value)))
                        if surface_width < float(ini['minimum_flow_width']):
                            surface_width = float(ini['minimum_flow_width'])

                        # 4 check if SV > BERG, then SV = BERG
                        if float(row[field_bottom_width_sv]) > bottom_width:
                            bottom_width_sv = bottom_width
                        else:
                            bottom_width_sv = float(row[field_bottom_width_sv])

                        if float(row[field_water_width_sv]) > water_width:
                            water_width_sv = water_width
                        else:
                            water_width_sv = float(row[field_water_width_sv])

                        if float(row[field_surface_width_sv]) > surface_width:
                            surface_width_sv = surface_width
                        else:
                            surface_width_sv = float(
                                row[field_surface_width_sv])

                        try:
                            change_width = float(row[field_add_width])
                        except:
                            change_width = 0
                        add_width = float(change_width) + (
                            surface_width - float(
                                row[field_surface_width_max]))

                        cross_section_new_dict[id] = {
                            field_bottem_level: float(row[field_bottem_level]),
                            field_bottom_width_sv: bottom_width_sv,
                            field_bottom_width_max: bottom_width,
                            field_water_level: float(row[field_water_level]),
                            field_water_width_sv: water_width_sv,
                            field_water_width_max: water_width,
                            field_surface_level: float(
                                row[field_surface_level]),
                            field_surface_width_sv: surface_width_sv,
                            field_surface_width_max: surface_width,
                            field_type: row[field_type],
                            field_comment: "bergend profiel met \
                            %s meter versmald" % change_value,
                            field_date_time: date_str,
                            field_add_width: float(add_width)}
                    except:
                        log.warning("no tabulated profile definition \
                        found for %s" % id)

    return cross_section_new_dict


def readHIS(file_input_his):
    """Reads a Sobek HIS file and extracts the max waterlevel \
    for each calculation point
    input: sobek HIS file
    output: dictionary with:
        key: location_id
        value: maximum waterlevel
    """
    result_dict = {}
    file = open(file_input_his, 'rb')
    sf = nens.sobek.SobekHIS(file.read())
    if 'Waterlevel max. (m A' in sf.parameter_names:
        for location in sf.location_names:
            result_dict[location] = max(sf.get_timeseries(location,
                'Waterlevel max. (m A'))
        errorcode = 0
    elif 'Waterlevel mean (m A' in sf.parameter_names:
        for location in sf.location_names:
            result_dict[location] = max(sf.get_timeseries(location,
                'Waterlevel mean (m A'))
        errorcode = 0
    elif 'Waterlevel min. (m A' in sf.parameter_names:
        for location in sf.location_names:
            result_dict[location] = max(sf.get_timeseries(location,
                'Waterlevel min. (m A'))
        errorcode = 0
    else:
        errorcode = 1

    return result_dict, errorcode


def calculate_weightfactor(diff_value):
    '''Berekenen Weegfactor (fw) om robuustheidsindex te bepalen
    als critical_value - waterlevel =
    <= 0.4: fw = 1
    > 0.3 AND <= 0.4: fw = 2
    > 0.2 AND <= 0.3: fw = 5
    > 0.1 AND <= 0.2: fw = 25
    > 0 AND <= 0.1: fw = 250
    '''
    if diff_value <= 0.10:
        fw = 250
    elif diff_value > 0.1 and diff_value <= 0.2:
        fw = 25
    elif diff_value > 0.20 and diff_value <= 0.3:
        fw = 5
    elif diff_value > 0.3 and diff_value <= 0.4:
        fw = 2
    else:
        fw = 1
    return fw
