# (c) Nelen & Schuurmans. GPL licensed, see LICENSE.txt
# -*- coding: utf-8 -*-
"""Goal: make logging setup for turtle quick and simple.

Logging of debug and higher should go to a file, info and higher to arcgis.

Arcgis keeps modules loaded in memory, so we can't count on modules being
fresh. This means that logging's ``relativeCreated`` probably means "relative
to the moment arcgis read in the logging module for the first time" instead of
"relative to the moment I thought my script just imported logging".  And
adding handlers might mean that handlers show up multiple times.

So clean-up is important!

Usage::

    import logging
    from turtlebase.logutils import LoggingConfig

    logger = logging.getLogger(__name__)

    def main():
        gp = ...
        # Parse config, grab logfile name.
        logging_config = LoggingConfig(gp, logfile=logfile)
        ...
        # At the end, clean up.
        logging_config.cleanup()

If you want arcgis logging before you've read in the config file for a
logfile::

    def main():
        gp = ...
        logging_config = LoggingConfig(gp)
        # Do some more, grab logfile name.
        logging_config.add_file_logging(logfile)

If you need logging at a lower level than DEBUG, use this in your code::

    from turtlebase.logutils import BLABLA
    def blabla(msg, *args, **kwargs):
        logger.log(BLABLA, msg, *args, **kwargs)
        # Or 'log.log' if your logger is called 'log'.

and use it like this::

    blabla("I'm doing something.")

To really see the BLABLA level logging, call LoggingConfig with an additional
``blabla`` parameter::

    logging_config = LoggingConfig(gp, logfile=logfile, blabla=True)


"""

import logging
import logging.handlers
import time

logger = logging.getLogger(__name__)

BLABLA = 5  # Bla bla log level.
ARCGIS_FORMAT = '%(message)s ... %(seconds)s'
FILE_FORMAT = '%(asctime)s %(levelname)s %(name)s %(message)s'


class ArcgisHandler(logging.Handler):
    """Handler that displays messages in the ArcGIS window.

    Note: copied from ``nens.gp``, but toned down to just provide the actual
    handling.  ``nens.gp.GpHandler`` also sets up formatting.

    """

    def __init__(self, gp=None, *args, **kwargs):
        self.gp = gp
        logging.Handler.__init__(self, *args, **kwargs)

    def emit(self, record):
        try:
            message = self.format(record)
            if record.levelno >= logging.ERROR:
                self.gp.AddError(message)
            elif record.levelno >= logging.WARNING:
                self.gp.AddWarning(message)
            else:
                self.gp.AddMessage(message)
        except:
            self.handleError(record)


class SecondsFormatter(logging.Formatter):
    """Formatter that provides %(seconds)s.

    This formatter provides an extra ``.seconds`` attribute for the formatter
    string that shows the seconds that passed since the logging started:

        >>> from mock import Mock
        >>> from mock import patch
        >>> record = Mock()
        >>> record.relativeCreated = 1500
        >>> with patch.object(logging.Formatter, 'format',
        ...     new=lambda x, y: y.seconds):
        ...     SecondsFormatter().format(record)
        '2 seconds'
        >>> record.relativeCreated = 1400
        >>> with patch.object(logging.Formatter, 'format',
        ...     new=lambda x, y: y.seconds):
        ...     SecondsFormatter().format(record)
        '1 second'

    """
    def format(self, record):
        seconds = round(record.relativeCreated / 1000.0)
        seconds_string = 'seconds'
        if seconds == 1:
            seconds_string = 'second'
        record.seconds = '%d %s' % (seconds, seconds_string)
        return logging.Formatter.format(self, record)


class LoggingConfig(object):
    """Object that keeps track of the logging and that can clean up handlers.
    """

    def __init__(self, gp, logfile=None, blabla=False):
        """Initialize object *and* re-set the logging module's start time."""
        self.gp = gp
        self.blabla = blabla
        self.root_logger = logging.getLogger()
        self.root_logger.setLevel(logging.DEBUG)
        self.cleanup()
        # logging._startTime is the time used for the SecondsFormatter.
        logging._startTime = time.time()
        if logfile:
            self.add_file_logging(logfile)
        # Always add the arcgis logging.
        self.add_arcgis_logging()

    def cleanup(self):
        """Remove all handlers from the root logger: prevent duplicate lines.

        Flush first, afterwards remove the handler.

        """
        for handler in self.root_logger.handlers:
            try:
                handler.flush()
            except ValueError:
                # File associated with the handler is already closed.
                pass
            self.root_logger.removeHandler(handler)

    def add_arcgis_logging(self):
        """Set up logging to arcgis' window."""
        arcgis_handler = ArcgisHandler(self.gp)
        arcgis_handler.setLevel(logging.INFO)
        seconds_formatter = SecondsFormatter(ARCGIS_FORMAT)
        arcgis_handler.setFormatter(seconds_formatter)
        self.root_logger.addHandler(arcgis_handler)

    def add_file_logging(self, logfile):
        """Add (regular, non-rotating) file logging

        We used to restrict logfiles to grow to a megabyte in size and keep 5
        old ones.  See
        http://docs.python.org/library/logging.html#rotatingfilehandler . But
        that wasn't too reliable, somehow, on windows. So we use a regular
        filehandler and accept that the logfile can get HUGE.

        """
        handler = logging.FileHandler(logfile)
        if self.blabla:
            handler.setLevel(logging.BLABLA)
        else:
            handler.setLevel(logging.DEBUG)
        formatter = SecondsFormatter(FILE_FORMAT)
        handler.setFormatter(formatter)
        self.root_logger.addHandler(handler)


if __name__ == '__main__':
    # temp debug
    from nens import mock
    gp = mock.GpDispatch()
    logging_config = LoggingConfig(gp, logfile="test.log")
    logger.info("Info logging")
